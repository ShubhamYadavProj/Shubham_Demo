﻿using IdentityServer4.Models;
using IdentityServer4.Services;
using IdentityServer4.Stores;
using Microsoft.AspNetCore.Mvc;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Security.Cryptography.Xml;

namespace Web.eCommerce.Identity.Services
{
    public class AccessToken : IAccessToken
    {
        private readonly IClientStore _clientStore;
        private readonly ITokenService _tokenService;
        private readonly IRefreshTokenService _refreshTokenService;
        private readonly IResourceStore _resourceStore;

        public AccessToken(IClientStore clientStore, IResourceStore resourceStore, IRefreshTokenService refrestTokenService, ITokenService tokenService)
        {
            _tokenService = tokenService;
            _clientStore = clientStore;
            _resourceStore = resourceStore;
            _refreshTokenService = refrestTokenService;
        }

        public async Task<JsonResult> GenerateAccessTokenAsyn(string subjectId, string clientId, ICollection<string> scopes)
        {
            var client = await _clientStore.FindClientByIdAsync(clientId);

            var resources = await _resourceStore.FindApiResourcesByScopeNameAsync(scopes);

            var claims = new List<Claim>
            {
                new Claim("sub", subjectId),
                new Claim("amr", "pwd"),
                new Claim("idp", "local"),
                new Claim("auth_time", "1710087236}")
            };

            var claimsPrincipal = new ClaimsPrincipal(new ClaimsIdentity(claims));

            var tokenCreationRequest = new TokenCreationRequest
            {

            };

            var token = await _tokenService.CreateAccessTokenAsync(tokenCreationRequest);

            var accessToken = await _tokenService.CreateSecurityTokenAsync(token);

            var refreshToken = await _refreshTokenService.CreateRefreshTokenAsync(claimsPrincipal, token, client);

            var result = new
            {
                access_token = accessToken,
                expires_in = client.AccessTokenLifetime,
                token_type = "Bearer",
                refresh_token = refreshToken,
                scope = client.AllowedScopes
            };

            return new JsonResult(result);
        }
    }
}
