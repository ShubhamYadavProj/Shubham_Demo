﻿using IdentityServer4.Models;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Identity;
using System.Net.WebSockets;
using System.Security.Claims;
using System.Security.Cryptography.Xml;
using Web.eCommerce.Core.Entities;
using Web.eCommerce.Infrastructure.Authorization.CustomClaims;

namespace Web.eCommerce.Identity.Services
{
    public class ProfileService : IProfileService
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IPermissionService _permissionService;

        public ProfileService(UserManager<ApplicationUser> userManager, IPermissionService permissionService)
        {
            _userManager = userManager;
            _permissionService = permissionService;
        }
        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            var user = await _userManager.GetUserAsync(context.Subject);
            var claims = new List<Claim>();

            if (user != null)
            {
                var roles = await _userManager.GetRolesAsync(user);
                var permissions = await _permissionService.GetPermissionsAsync(user.Id);
                foreach(var role in  roles)
                {
                    claims.Add(new Claim("roles", role));
                }
                foreach(var permission in permissions)
                {
                    claims.Add(new Claim(CustomClaims.CustomClaimType, permission));
                }
            }

            context.IssuedClaims.AddRange(claims);
        }

        public Task IsActiveAsync(IsActiveContext context)
        {
            return Task.CompletedTask;
        }
    }
}
