﻿namespace Web.eCommerce.Identity.Services
{
    public interface IPermissionService
    {
        public Task<HashSet<string>> GetPermissionsAsync(Guid userid);
    }
}
