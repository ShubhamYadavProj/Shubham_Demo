﻿using Microsoft.AspNetCore.Mvc;

namespace Web.eCommerce.Identity.Services
{
    public interface IAccessToken
    {
        public Task<JsonResult> GenerateAccessTokenAsyn(string subjectId, string clientId, ICollection<string> scopes);
    }
}
