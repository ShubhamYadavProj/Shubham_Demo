﻿
using Microsoft.EntityFrameworkCore;
using Web.eCommerce.Core.Context;

namespace Web.eCommerce.Identity.Services
{
    public class PermissionService : IPermissionService
    {
        private readonly ApplicationDbContext _context;

        public PermissionService(ApplicationDbContext context)
        {
            _context = context;
        }

        public Task<HashSet<string>> GetPermissionsAsync(Guid userid)
        {
            var permissions = new HashSet<string>();

            var userPermissions = _context.Users.Include(x => x.Permissions)
                                                .Where(x => x.Id == userid)
                                                .SelectMany(x => x.Permissions)
                                                .Select(x => x.Value)
                                                .ToHashSet();

            foreach(var userPermission in userPermissions)
            {
                permissions.Add(userPermission);
            }

            var userRoles = _context.Users.Include(x => x.Roles)
                                          .ThenInclude(x => x.Permissions)
                                          .Where(x => x.Id == userid)
                                          .Select(x => x.Roles)
                                          .ToList();

            var rolePermissions = userRoles.SelectMany(x => x)
                                           .SelectMany(x => x.Permissions)
                                           .Select(x => x.Value)
                                           .ToHashSet();

            foreach(var rolePermission in rolePermissions)
            {
                permissions.Add(rolePermission);
            }

            return Task.FromResult(permissions);
        }
    }
}
