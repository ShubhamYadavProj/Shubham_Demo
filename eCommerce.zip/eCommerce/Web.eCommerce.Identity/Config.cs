﻿using IdentityServer4.Models;

namespace Web.eCommerce.Identity
{
    public static class Config
    {
        public static List<IdentityResource> identityResources = new List<IdentityResource>()
        {
            new IdentityResources.OpenId(),
            new IdentityResources.Profile()
        };

        public static List<ApiResource> apiResources = new List<ApiResource>()
        {
            new ApiResource("api", "eCommerceApi")
            {
                Scopes = { "eCommerce", "profile", "openid", "offline_access" }
            }
        };

        public static List<ApiScope> scopes = new List<ApiScope>
        {
            new ApiScope("eCommerce", "ECommerce")
        };

        public static List<Client> clients = new List<Client>()
        {
            new Client()
            {
                ClientId = "apiClient",
                ClientSecrets = new List<Secret>
                {
                    new Secret("eCommerceSecre".Sha256())
                },
                AllowedGrantTypes = new List<string>
                {
                    GrantType.ResourceOwnerPassword
                },
                AllowedScopes = new List<string>
                {
                   "eCommerce", "profile", "openid", "offline_access"
                },
                AllowOfflineAccess = true
            }
        };
    }
}
