﻿namespace Web.eCommerce.Identity.Features
{
    public class SendOTPRepresentationModel
    {
        public string Phone {  get; set; }
    }
}
