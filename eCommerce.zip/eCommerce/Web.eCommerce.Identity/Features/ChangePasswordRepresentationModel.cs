﻿namespace Web.eCommerce.Identity.Features
{
    public class ChangePasswordRepresentationModel
    {
        public string UserName { get; set; }
        public string OldPassword { get; set; }
        public string NewPassword { get; set; }

    }
}
