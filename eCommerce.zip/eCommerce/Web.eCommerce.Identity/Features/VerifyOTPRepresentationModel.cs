﻿namespace Web.eCommerce.Identity.Features
{
    public class VerifyOTPRepresentationModel
    {
        public string OTP { get; set; }
        public string Phone { get; set; }
    }
}
