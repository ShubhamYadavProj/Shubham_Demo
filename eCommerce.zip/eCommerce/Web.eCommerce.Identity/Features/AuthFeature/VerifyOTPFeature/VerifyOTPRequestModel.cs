﻿using MediatR;

namespace Web.eCommerce.Identity.Features.AuthFeature.VerifyOTPFeature
{
    public class VerifyOTPRequestModel : IRequest<VerifyOTPResponseModel>
    {
        public VerifyOTPRepresentationModel VerifyOTP { get; set; }
    }
}
