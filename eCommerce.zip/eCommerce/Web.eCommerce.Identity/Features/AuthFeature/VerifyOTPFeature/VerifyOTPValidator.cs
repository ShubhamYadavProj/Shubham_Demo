﻿using FluentValidation;
using Microsoft.AspNetCore.Identity;
using System.Text.RegularExpressions;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Identity.Features.AuthFeature.VerifyOTPFeature
{
    public class VerifyOTPValidator : AbstractValidator<VerifyOTPRequestModel>
    {
        public VerifyOTPValidator(UserManager<ApplicationUser> _userManager)
        {
            RuleFor(x => x.VerifyOTP)
                .Custom((req, con) =>
                {
                    var user = _userManager.Users;

                    if (!user.Any(x => x.PhoneNumber == req.Phone))
                    {
                        con.AddFailure("Invalid phone no!");
                        return;
                    }

                    if (string.IsNullOrEmpty(req.Phone) || string.IsNullOrWhiteSpace(req.Phone))
                    {
                        con.AddFailure("Please enter phone no!");
                        return;
                    }

                    if (!Regex.IsMatch(req.Phone, @"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$"))
                    {
                        con.AddFailure("Please enter phone number along with country code!");
                        return;
                    }
                });
        }
    }
}
