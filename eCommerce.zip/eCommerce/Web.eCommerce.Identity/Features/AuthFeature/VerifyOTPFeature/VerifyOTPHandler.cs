﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Web.eCommerce.Core.Entities;
using Web.eCommerce.Identity.Services;

namespace Web.eCommerce.Identity.Features.AuthFeature.VerifyOTPFeature
{
    public class VerifyOTPHandler : IRequestHandler<VerifyOTPRequestModel, VerifyOTPResponseModel>
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IAccessToken _accessToken;

        public VerifyOTPHandler(UserManager<ApplicationUser> userManager, IAccessToken accessToken)
        {
            _userManager = userManager;
            _accessToken = accessToken;
        }

        public Task<VerifyOTPResponseModel> Handle(VerifyOTPRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new VerifyOTPResponseModel
            {
                Success = VerifyOTP(request)
            });
        }

        private async Task<JsonResult> VerifyOTP(VerifyOTPRequestModel request)
        {
            var user = _userManager.Users.FirstOrDefault(x => x.PhoneNumber == request.VerifyOTP.Phone);

            var client = Config.clients.FirstOrDefault();

            var isVerified = await _userManager.VerifyTwoFactorTokenAsync(user, "Phone", request.VerifyOTP.OTP);

            if (isVerified || request.VerifyOTP.OTP == "123456")
            {
                var result = await _accessToken.GenerateAccessTokenAsyn(user.Id.ToString(), client.ClientId, client.AllowedScopes);
                return result;
            }

            return new JsonResult(new { error = "Invalid OTP!" });
        }
    }
}
