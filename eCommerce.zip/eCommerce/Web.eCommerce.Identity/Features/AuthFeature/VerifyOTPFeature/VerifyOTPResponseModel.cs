﻿using Microsoft.AspNetCore.Mvc;

namespace Web.eCommerce.Identity.Features.AuthFeature.VerifyOTPFeature
{
    public class VerifyOTPResponseModel
    {
        public Task<JsonResult> Success { get; set; }
    }
}
