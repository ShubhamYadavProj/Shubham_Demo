﻿namespace Web.eCommerce.Identity.Features.AuthFeature.SendOTPFeature
{
    public class SendOTPResponseModel
    {
        public Task<string> Message { get; set; }
    }
}
