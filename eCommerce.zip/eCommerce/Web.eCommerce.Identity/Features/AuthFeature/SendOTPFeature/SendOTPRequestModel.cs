﻿using MediatR;

namespace Web.eCommerce.Identity.Features.AuthFeature.SendOTPFeature
{
    public class SendOTPRequestModel : IRequest<SendOTPResponseModel>
    {
        public SendOTPRepresentationModel otpToSend { get; set; }
    }
}
