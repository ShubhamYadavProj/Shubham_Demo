﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Identity.Features.AuthFeature.SendOTPFeature
{
    public class SendOTPHandler : IRequestHandler<SendOTPRequestModel, SendOTPResponseModel>
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public SendOTPHandler(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;            
        }

        public Task<SendOTPResponseModel> Handle(SendOTPRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new SendOTPResponseModel
            {
                Message = SendOTP(request)
            });
        }

        private async Task<string> SendOTP(SendOTPRequestModel request)
        {
            var user = _userManager.Users.FirstOrDefault(x => x.PhoneNumber == request.otpToSend.Phone);

            if(user != null)
            {
                var result = await _userManager.GenerateTwoFactorTokenAsync(user, "Phone");
                if(!string.IsNullOrEmpty(result) || !string.IsNullOrWhiteSpace(result))
                {
                    return "OTP sent to registered phone no!";
                }
            }
            return "Please enter registered phone no!";
        }
    }
}
