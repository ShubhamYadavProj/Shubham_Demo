﻿using FluentValidation;
using System.Text.RegularExpressions;

namespace Web.eCommerce.Identity.Features.AuthFeature.SendOTPFeature
{
    public class SendOTPValidator : AbstractValidator<SendOTPRequestModel>
    {
        public SendOTPValidator()
        {
            RuleFor(x => x.otpToSend)
                .Custom((req, con) =>
                {
                    if (!Regex.IsMatch(req.Phone, @"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$"))
                    {
                        con.AddFailure("Please enter phone number along with country code!");
                        return;
                    }

                    if (string.IsNullOrEmpty(req.Phone) || string.IsNullOrWhiteSpace(req.Phone))
                    {
                        con.AddFailure("Please enter phone no!");
                        return;
                    }
                });
        }
    }
}
