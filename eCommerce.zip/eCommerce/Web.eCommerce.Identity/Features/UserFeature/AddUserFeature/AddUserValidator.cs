﻿using FluentValidation;
using Microsoft.AspNetCore.Identity;
using System.Text.RegularExpressions;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Identity.Features.UserFeature.AddUserFeature
{
    public class AddUserValidator : AbstractValidator<AddUserRequestModel>
    {
        public AddUserValidator(UserManager<ApplicationUser> _userManager)
        {
            RuleFor(x => x.SignIn)
                .Custom((req, con) =>
                {
                    var users = _userManager.Users;

                    if(users.Any(x => x.UserName == req.Username))
                    {
                        con.AddFailure("Username already registered!");
                        return;
                    }
                    
                    if(users.Any(x => x.PhoneNumber == req.Phone))
                    {
                        con.AddFailure("Username already registered!");
                        return;
                    }
                    
                    if(users.Any(x => x.Email == req.Email))
                    {
                        con.AddFailure("Username already registered!");
                        return;
                    }

                    if(string.IsNullOrEmpty(req.Email) || string.IsNullOrWhiteSpace(req.Email))
                    {
                        con.AddFailure("Please enter email!");
                        return;
                    }

                    if(string.IsNullOrEmpty(req.Phone) || string.IsNullOrWhiteSpace(req.Phone))
                    {
                        con.AddFailure("Please enter phone no!");
                        return;
                    }

                    if(string.IsNullOrEmpty(req.Username) || string.IsNullOrWhiteSpace(req.Username))
                    {
                        con.AddFailure("Please enter username!");
                        return;
                    }

                    if(string.IsNullOrEmpty(req.Email) || string.IsNullOrWhiteSpace(req.Email))
                    {
                        con.AddFailure("Please enter email!");
                        return;
                    }
                    
                    if(!Regex.IsMatch(req.Email, @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$"))
                    {
                        con.AddFailure("Please enter valid email!");
                        return;
                    }

                    if (!Regex.IsMatch(req.Phone, @"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$"))
                    {
                        con.AddFailure("Please enter phone number along with country code!");
                        return;
                    }
                });
        }
    }
}
