﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Identity.Features.UserFeature.AddUserFeature
{
    public class AddUserHandler : IRequestHandler<AddUserRequestModel, AddUserResponseModel>
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public AddUserHandler(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        public Task<AddUserResponseModel> Handle(AddUserRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddUserResponseModel
            {
                IsSuccess = AddUser(request)
            });
        }

        private async Task<JsonResult> AddUser(AddUserRequestModel request)
        {
            var user = new ApplicationUser
            {
                UserName = request.SignIn.Username,
                Email = request.SignIn.Email,
                PhoneNumber = request.SignIn.Phone
            };

            var addedUser = await _userManager.CreateAsync(user, request.SignIn.Password);

            if (addedUser.Succeeded)
            {
                var token = await _userManager.GenerateTwoFactorTokenAsync(user, "Phone");
                if (!string.IsNullOrEmpty(token))
                {
                    {
                        // SMS code done here
                    }
                    return new JsonResult(new { message = "OTP sent on registered phone no!" });
                }
            }
            return new JsonResult(new { message = "Unable to add user!" });
        }
    }
}
