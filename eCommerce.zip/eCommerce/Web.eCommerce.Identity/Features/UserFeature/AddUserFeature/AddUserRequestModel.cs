﻿using MediatR;

namespace Web.eCommerce.Identity.Features.UserFeature.AddUserFeature
{
    public class AddUserRequestModel : IRequest<AddUserResponseModel>
    {
        public SignInRepresentationModel SignIn { get; set; }
    }
}
