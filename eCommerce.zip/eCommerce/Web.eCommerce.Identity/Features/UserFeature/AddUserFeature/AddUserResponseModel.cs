﻿using Microsoft.AspNetCore.Mvc;

namespace Web.eCommerce.Identity.Features.UserFeature.AddUserFeature
{
    public class AddUserResponseModel
    {
        public Task<JsonResult> IsSuccess { get; set; }
    }
}
