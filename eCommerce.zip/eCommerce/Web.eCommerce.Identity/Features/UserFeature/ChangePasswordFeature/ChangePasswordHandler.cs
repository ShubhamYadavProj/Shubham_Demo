﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Identity.Features.UserFeature.UpdatePasswordFeature
{
    public class ChangePasswordHandler : IRequestHandler<ChangePasswordRequestModel, ChangePasswordResponseModel>
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public ChangePasswordHandler(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        public Task<ChangePasswordResponseModel> Handle(ChangePasswordRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new ChangePasswordResponseModel
            {
                Success = ChangePassword(request)
            });
        }

        private async Task<bool> ChangePassword(ChangePasswordRequestModel request)
        {
            var user = await _userManager.FindByNameAsync(request.PasswordToChange.UserName);

            var result = await _userManager.ChangePasswordAsync(user, request.PasswordToChange.OldPassword, request.PasswordToChange.NewPassword);

            return result.Succeeded;
        }
    }
}
