﻿using MediatR;

namespace Web.eCommerce.Identity.Features.UserFeature.UpdatePasswordFeature
{
    public class ChangePasswordRequestModel : IRequest<ChangePasswordResponseModel>
    {
        public ChangePasswordRepresentationModel PasswordToChange {  get; set; }
    }
}
