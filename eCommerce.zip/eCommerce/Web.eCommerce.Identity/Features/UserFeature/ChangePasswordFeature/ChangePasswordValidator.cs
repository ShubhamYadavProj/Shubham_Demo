﻿using FluentValidation;
using Microsoft.AspNetCore.Identity;
using Web.eCommerce.Core.Entities;
using Web.eCommerce.Identity.Features.UserFeature.UpdatePasswordFeature;

namespace Web.eCommerce.Identity.Features.UserFeature.ChangePasswordFeature
{
    public class ChangePasswordValidator : AbstractValidator<ChangePasswordRequestModel>
    {
        public ChangePasswordValidator(UserManager<ApplicationUser> _userManager)
        {
            RuleFor(x => x.PasswordToChange)
                .Custom((req, con) =>
                {
                    if(string.IsNullOrWhiteSpace(req.UserName) || string.IsNullOrEmpty(req.UserName))
                    {
                        con.AddFailure("Username cannot be empty!");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(req.NewPassword) || string.IsNullOrEmpty(req.NewPassword))
                    {
                        con.AddFailure("New Password cannot be empty!");
                        return;
                    }

                    if (string.IsNullOrWhiteSpace(req.OldPassword) || string.IsNullOrEmpty(req.OldPassword))
                    {
                        con.AddFailure("Old Password cannot be empty!");
                        return;
                    }

                    if (!req.OldPassword.Equals(req.NewPassword))
                    {
                        con.AddFailure("Password do not match!");
                        return;
                    }

                    var users = _userManager.Users;

                    if(!users.Any(x => x.UserName == req.UserName))
                    {
                        con.AddFailure("User does not exists!");
                        return;
                    }
                });
        }
    }
}
