﻿namespace Web.eCommerce.Identity.Features.UserFeature.UpdatePasswordFeature
{
    public class ChangePasswordResponseModel
    {
        public Task<bool> Success { get; set; }
    }
}
