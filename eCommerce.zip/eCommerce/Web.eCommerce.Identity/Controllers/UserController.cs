using MediatR;
using Microsoft.AspNetCore.Mvc;
using Web.eCommerce.Identity.Features.UserFeature.AddUserFeature;
using Web.eCommerce.Identity.Features.UserFeature.UpdatePasswordFeature;

namespace Web.eCommerce.Identity.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;

        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("signin")]
        public async Task<AddUserResponseModel> SignIn([FromBody] AddUserRequestModel model)
        {
            return await _mediator.Send(model);
        }

        [HttpPut("change/password")]
        public async Task<ChangePasswordResponseModel> ChangePassword([FromBody] ChangePasswordRequestModel model)
        {
            return await _mediator.Send(model); 
        }
    }
}
