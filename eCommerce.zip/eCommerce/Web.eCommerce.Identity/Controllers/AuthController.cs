﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Web.eCommerce.Identity.Features.AuthFeature.SendOTPFeature;
using Web.eCommerce.Identity.Features.AuthFeature.VerifyOTPFeature;

namespace Web.eCommerce.Identity.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AuthController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost("send/otp")]
        public async Task<SendOTPResponseModel> SendOTP([FromBody]  SendOTPRequestModel model)
        {
            return await _mediator.Send(model);
        }

        [HttpPost("verify/otp")]
        public async Task<VerifyOTPResponseModel> VerifyOTP([FromBody] VerifyOTPRequestModel model)
        {
            return await _mediator.Send(model);
        }
    }
}
