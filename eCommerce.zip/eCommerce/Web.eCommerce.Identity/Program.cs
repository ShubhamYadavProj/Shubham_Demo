
using FluentValidation.AspNetCore;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Web.eCommerce.Core.Context;
using Web.eCommerce.Core.Entities;
using Web.eCommerce.Identity.Services;
using Web.eCommerce.Infrastructure.Repositories;
using Web.eCommerce.Infrastructure.UnitOfWork;
using Web.eCommerce.Utility.Services;

namespace Web.eCommerce.Identity
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("connection")));

            builder.Services.AddIdentity<ApplicationUser, Role>(config =>
            {
                config.SignIn.RequireConfirmedPhoneNumber = true;
            })
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddDefaultTokenProviders();

            builder.Services.AddIdentityServer()
                            .AddInMemoryApiResources(Config.apiResources)
                            .AddInMemoryIdentityResources(Config.identityResources)
                            .AddInMemoryApiScopes(Config.scopes)
                            .AddInMemoryClients(Config.clients)
                            .AddAspNetIdentity<ApplicationUser>()
                            .AddDeveloperSigningCredential();

            builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

            builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

            builder.Services.AddScoped<IPermissionService, PermissionService>();

            builder.Services.AddAutoMapper(typeof(Program).Assembly);

            builder.Services.AddFluentValidation(config => config.RegisterValidatorsFromAssembly(typeof(Program).Assembly));

            builder.Services.AddMediatR(typeof(Program).Assembly);

            builder.Services.AddScoped<ISMSService, SMSService>();

            builder.Services.AddScoped<IAccessToken, AccessToken>();

            builder.Services.AddControllers();

            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();

            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            if (app.Environment.IsProduction())
            {
                builder.Services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("connection")));
            }

            app.UseSwagger();

            app.UseSwaggerUI();

            app.UseHttpsRedirection();

            app.UseIdentityServer();

            app.UseAuthorization();

            app.MapControllers();

            app.Run();
        }
    }
}
