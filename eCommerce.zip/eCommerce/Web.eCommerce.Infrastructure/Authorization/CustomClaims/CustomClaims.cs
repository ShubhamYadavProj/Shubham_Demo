﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Infrastructure.Authorization.CustomClaims
{
    public static class CustomClaims
    {
        public const string CustomClaimType = "permissions";
    }
}
