﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Infrastructure.Repositories
{
    public interface IRepository<T> where T : class
    {
        public List<T> GetAll();

        public Task<List<T>> GetAllAsync();

        public T GetById(Guid id);

        public Task<T> GetByIdAsync(Guid id);

        public IQueryable<T> Query();

        public Task<T> AddAsync(T entity);

        public T Add(T entity);

        public Task<T> UpdateAsync(T entity);

        public T Update(T entity);

        public T Delete(T entity);

        public IEnumerable<T> AddRange(IEnumerable<T> entities);
        public IEnumerable<T> UpdateRange(IEnumerable<T> entities);
    }
}
