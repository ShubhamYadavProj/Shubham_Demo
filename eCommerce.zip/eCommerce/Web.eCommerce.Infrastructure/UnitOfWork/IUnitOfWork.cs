﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Infrastructure.UnitOfWork
{
    public interface IUnitOfWork
    {
        public Task<int> CommitAsync();

        public int Commit();

        public Task RollBackAsync();

        public void RollBack();
    }
}
