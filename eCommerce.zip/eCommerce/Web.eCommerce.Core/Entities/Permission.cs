﻿using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Core.Entities
{
    public class Permission
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public ICollection<Role> Roles { get; set; }
        public ICollection<ApplicationUser> Users { get; set; }
    }
}
