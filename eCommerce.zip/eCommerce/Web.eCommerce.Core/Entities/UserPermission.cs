﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Core.Entities
{
    public class UserPermission
    {
        [ForeignKey("UserId")]
        public Guid UserId { get; set; }
        public virtual ApplicationUser User { get; set; }

        [ForeignKey("PermissionId")]
        public Guid PermissionId { get; set; }
        public virtual Permission Permission { get; set; }
    }
}
