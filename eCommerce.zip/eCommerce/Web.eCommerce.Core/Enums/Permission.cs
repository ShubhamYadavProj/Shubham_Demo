﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web.eCommerce.Core.Enums
{
    public enum Permission
    {
        PRODCUT_GET = 100,
        PRODUCT_ADD = 101,
        PRODUCT_UPDATE = 102,
        PRODUCT_DELETE = 103,

        CATEGORY_GET = 200,
        CATEGORY_ADD = 201,
        CATEGORY_UPDATE = 202,
        CATEGORY_DELETE = 203
    }
}
