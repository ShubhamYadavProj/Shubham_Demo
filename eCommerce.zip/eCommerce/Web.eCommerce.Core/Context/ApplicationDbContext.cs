﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web.eCommerce.Core.Entities;

namespace Web.eCommerce.Core.Context
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser, Role, Guid, IdentityUserClaim<Guid>, UserRole, IdentityUserLogin<Guid>, IdentityRoleClaim<Guid>, IdentityUserToken<Guid>>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<ApplicationUser>(u =>
            {
                u.HasKey(x => x.Id);

                u.HasMany(x => x.Roles)
                 .WithMany(x => x.Users)
                 .UsingEntity<UserRole>();

                u.HasMany(x => x.Permissions)
                 .WithMany(x => x.Users)
                 .UsingEntity<UserPermission>();
            });

            builder.Entity<Role>(r =>
            {
                r.HasKey(x => x.Id);

                r.HasMany(x => x.Users)
                 .WithMany(x => x.Roles)
                 .UsingEntity<UserRole>();

                r.HasMany(x => x.Permissions)
                 .WithMany(x => x.Roles)
                 .UsingEntity<RolePermission>();
            });

            builder.Entity<Permission>(p =>
            {
                p.HasKey(x => x.Id);

                p.HasMany(x => x.Users)
                 .WithMany(x => x.Permissions)
                 .UsingEntity<UserPermission>();

                p.HasMany(x => x.Roles)
                 .WithMany(x => x.Permissions)
                 .UsingEntity<RolePermission>();
            });

            builder.Entity<UserRole>(ur =>
            {
                ur.HasKey(x => new { x.UserId, x.RoleId });
            });

            builder.Entity<UserPermission>(up =>
            {
                up.HasKey(x => new { x.UserId, x.PermissionId });
            });

            builder.Entity<RolePermission>(rp =>
            {
                rp.HasKey(x => new { x.RoleId, x.PermissionId });
            });

            builder.Entity<IdentityUserClaim<Guid>>().HasKey(x => x.Id);

            builder.Entity<IdentityUserLogin<Guid>>().HasKey(x => new { x.UserId });

            builder.Entity<IdentityRoleClaim<Guid>>().HasKey(x => x.Id);

            builder.Entity<IdentityUserToken<Guid>>().HasKey(x => new { x.UserId });
        }

        public DbSet<ApplicationUser> Users { get; set; }

        public DbSet<Role> Roles { get; set; }

        public DbSet<Permission> Permissions { get; set; }

        public DbSet<UserRole> UserRoles { get; set; }

        public DbSet<UserPermission> UserPermissions { get; set; }

        public DbSet<RolePermission> RolePermissions { get; set; }
    }
}
