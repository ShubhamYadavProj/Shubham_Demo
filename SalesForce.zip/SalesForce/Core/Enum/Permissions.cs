﻿
namespace Core.Enum
{
    public enum Permissions
    {
    }
}
