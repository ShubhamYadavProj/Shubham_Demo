﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Enum
{
    public enum UnitOfMeasure
    {
        kg=1,
        mg=2,
        lt=3,
        gm=4

    }
}
