﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Employee : MetaFields
    {
        [Key]
        public int employee_id { get; set; }

        [Required]
        public string employee_name { get;set; }

        [Required]
        public string employee_email { get; set; }

        [Required]
        public string employee_phone { get; set; }

        public int? manager_id { get; set; }

        [ForeignKey("manager_id")]
        public Employee employee { get; set; }

        [Required]
        public EmployeeType employeeType { get; set; }

        public EntityStatus status { get; set; }

    }
}
