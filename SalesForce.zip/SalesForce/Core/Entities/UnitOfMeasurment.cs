﻿using Core.Base;
using Core.Enum;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class UnitOfMeasurment : MetaFields
    {
        [Key]
        public int unit_of_measurment_id { get; set; } 

        public string name { get; set; }    

        public EntityStatus status { get; set; }
    }
}
