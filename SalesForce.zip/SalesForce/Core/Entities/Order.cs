﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Order : MetaFields
    {
        [Key]
        public int order_id { get; set; }

        [Required]
        public string order_name { get; set;}

        public string total { get; set;}

        [ForeignKey("distributor_id")]
        public Distributor distributor { get; set; }

        [Required]
        public int distributor_id { get; set; }

        [ForeignKey("retailer_id")]
        public Retailer retailer { get; set; }

        [Required]
        public int retailer_id { get; set; }

        public EntityStatus status { get; set; }

        public List<Order_deatils> deatils { get; set; }
        
    }
}
