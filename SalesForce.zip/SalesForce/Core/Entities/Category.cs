﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Category : MetaFields
    {
        [Key]
        public int category_id { get; set; }

        public string category_name { get; set; }

        public EntityStatus status { get; set; }
    }
}
