﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Order_deatils : MetaFields
    {
        [Key]
        public int order_deatils_id { get; set; }

        public int quantity { get; set; }   

        public DateTime order_date { get; set; }

        [ForeignKey("order_id")]
        public Order order { get; set; }

        public int order_id { get; set; }   


        public int sku_id { get; set; }
        [ForeignKey("sku_id")]
        public SKU sku { get; set; }

        public EntityStatus status { get; set; }
        
    }
}
