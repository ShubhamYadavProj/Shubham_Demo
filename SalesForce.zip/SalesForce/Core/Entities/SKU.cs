﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public  class SKU : MetaFields
    {
        [Key] 
        public int sku_id { get; set; } 

        public string sku_name { get; set; }    

        public float sku_price { get; set; }    

        //public UnitOfMeasurment unitOfMeasure { get; set; }

        public int category_id { get; set; }


        [ForeignKey("category_id")]
        public Category category { get; set; }

        public EntityStatus status { get; set; }

        public int unit_of_measurment_id { get; set; }


        [ForeignKey("unit_of_measurment_id")]
        public  UnitOfMeasurment unitofmeasurment { get; set; }





    }
}
