﻿using Core.Base;
using Core.Enum;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Employeebeatmap
    {
        [Key]
        public int employeebeatmap_id { get; set; }
        public int employee_id { get; set; }

        [ForeignKey("employee_id")]
        public Employee employee { get; set; }

        public int beat_id { get; set; }    

        [ForeignKey("beat_id")]
        public Beat beat { get; set; }
        public EntityStatus status { get; set; }
    }
}
