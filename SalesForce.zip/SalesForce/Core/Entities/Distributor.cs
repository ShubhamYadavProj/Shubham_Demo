﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Distributor : MetaFields
    {
        [Key]
        public int distributor_id { get; set; }

        [Required]
        public string distributor_name { get;set; }

        [ForeignKey("city_id")]
        public City city { get; set; }

        [Required]
        public int city_id { get; set; }


        [ForeignKey("manager_id")]
        public Employee employee { get; set; }

        public int manager_id { get; set; }


        public EntityStatus status { get; set; }    

    }
}

