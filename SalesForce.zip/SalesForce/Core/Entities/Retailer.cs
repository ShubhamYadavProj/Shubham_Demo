﻿using Core.Base;
using Core.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Entities
{
    public class Retailer : MetaFields
    {
        [Key]
        public int retailer_id { get; set; }

        public string retailer_name { get;set; }

        [ForeignKey("beat_id")]
        public Beat beat { get; set; }

        public int beat_id { get; set; }


        [ForeignKey("city_id")]
        public City city { get; set; }

        public int city_id { get; set;}

        public int dsr_id { get; set; }
        [ForeignKey("dsr_id")]
        public Dsr_Beat_Map Dsr_Beat_Map { get; set; }

        public EntityStatus status { get; set; }    

    }
}
