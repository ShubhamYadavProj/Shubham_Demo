﻿using MediatR;

namespace IdentityService.Features.UserFeatures.CreateUser
{
    public class CreateUserRequestModel:IRequest<CreateUserResponseModel>
    {
       public CreateUserRepresentationModel User { get; set; }
    }
}
