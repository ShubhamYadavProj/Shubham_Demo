﻿using FluentValidation;
using System.Linq;
using Core.Entities;
using Infastructure.Repository.Base;
using FluentValidation.Validators;

namespace IdentityService.Features.UserFeatures.CreateUser
{
    public class CreateUserValidator : AbstractValidator<CreateUserRequestModel>
    {
        public CreateUserValidator(IRepository<User> userManager)
        {
            RuleFor(t => t.User.Email)
                  .NotEmpty()
                  .WithMessage("Email can not be Empty or Blank");

            RuleFor(t => t.User.UserName)
                 .NotEmpty()
                 .WithMessage("UserName can not be Empty or Blank");

            RuleFor(t => t)
                .Custom((req, context) =>
                {
                    /*
                    bool ExistUser = userManager.GetAllQuery()
                                            .Where(a => a.UserName == req.User.UserName || a.Email == req.User.Email)
                                            .Any();
                    if (ExistUser)
                    {
                        context.AddFailure($"User Name {req.User.UserName} or Email {req.User.Email} already exist");

                    }

                    /*
                    if (email.CheckMail(req.User.Email) == false)
                    {
                        context.AddFailure($"Not a valid {req.User.Email} Email");
                    }

                    */

                });
        }
    }
}
