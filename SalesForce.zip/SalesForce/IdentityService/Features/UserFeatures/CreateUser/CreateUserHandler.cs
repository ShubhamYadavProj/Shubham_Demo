﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.WebUtilities;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Core.Entities;

namespace IdentityService.Features.UserFeatures.CreateUser
{
    public class CreateUserHandler : IRequestHandler<CreateUserRequestModel, CreateUserResponseModel>
    {
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<Role> _roleManager;
       // private readonly IHttpContextAccessor _accessor;
       // private readonly IConfiguration _configuration;
      //  private IMapper _mapper;
        
        public CreateUserHandler(UserManager<User> userManager, RoleManager<Role> roleManager) 
        {
            _userManager = userManager;
            _roleManager = roleManager;
          //  _configuration = configuration;
           // _accessor = accessor;
           // _mapper = mapper;
        }

        public Task<CreateUserResponseModel> Handle(CreateUserRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(AddUser(request));

        }

        public CreateUserResponseModel AddUser(CreateUserRequestModel request)
        {
            var user = new User { UserName = request.User.UserName, Email = request.User.Email };

            var result = _userManager.CreateAsync(user, request.User.Password).ConfigureAwait(false).GetAwaiter().GetResult();

            if (result.Succeeded)
            {
               // string FirstName = NewContact.FirstName;

              //  SendMailForNewPassword(request.User.Email, FirstName);

                Role role = _roleManager.FindByNameAsync("System Admin").ConfigureAwait(false).GetAwaiter().GetResult();

                if (role != null)
                {
                    _userManager.AddToRoleAsync(user, role.Name).ConfigureAwait(false).GetAwaiter().GetResult();
                }

            }

            return new CreateUserResponseModel()
            {
                Id = user.Id,
                Email = user.Email,
                UserName = user.UserName
            };
        }


        /*
        public void SendMailForNewPassword(string Email, string FirstName)
        {
            var CurrentUser = _userManager.FindByEmailAsync(Email).ConfigureAwait(false).GetAwaiter().GetResult();

            // var emailToken = _userManager.GenerateEmailConfirmationTokenAsync(CurrentUser).ConfigureAwait(false).GetAwaiter().GetResult();

            //  var passwordToken = _userManager.GeneratePasswordResetTokenAsync(CurrentUser).ConfigureAwait(false).GetAwaiter().GetResult();

            var NewPasswordUrl = _configuration.GetSection("NewPasswordUrl").Value;


            string data = CurrentUser.Id + ":" + Email;

            string token = CreateMD5.MD5(data.ToLower());


            var QueryParams = new Dictionary<string, string>()
                {
                    { "emailToken",token },
                    { "userId",CurrentUser.Id},
                    {"passwordToken",token }
                };

            var Url = QueryHelpers.AddQueryString(NewPasswordUrl, QueryParams);

            var Htmltemplate = $@"<pre> Hi {FirstName},</pre>

<pre>

There was a request for you to change your password.

Please ignore this email if you did not request it.

Otherwise, you can change your password by clicking the link below.

<a href={Url} >Reset password</a>

</pre>

<pre>

Yours,


</pre>";
            _EmailService.SendMail("WorkBeanch", "User Password", "test@workbenchgenie.com", "kanaiya.bhanushali@aureatetech.com", Htmltemplate);

        }
        */
    }

}
