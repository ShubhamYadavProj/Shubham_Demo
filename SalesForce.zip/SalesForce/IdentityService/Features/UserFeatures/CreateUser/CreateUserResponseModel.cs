﻿
namespace IdentityService.Features.UserFeatures.CreateUser
{
    public class CreateUserResponseModel
    {
        public string Id { get; set; }

        public string UserName { get; set; }

        public string Email { get; set; }

    }
}
