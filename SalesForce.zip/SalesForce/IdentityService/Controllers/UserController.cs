﻿using IdentityService.Features.UserFeatures.CreateUser;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace IdentityService.Controllers
{
    [Route("user")]
    [ApiController]

    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;

        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("add")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [AllowAnonymous]

        public async Task<CreateUserResponseModel> AddUser([FromBody] CreateUserRequestModel request)
        {
            var result = await _mediator.Send(request);

            return result;
        }

    }
}
