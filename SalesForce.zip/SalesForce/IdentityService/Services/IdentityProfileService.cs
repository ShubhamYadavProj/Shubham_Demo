﻿using System.Security.Claims;
using Core.Entities;
using IdentityServer4.Extensions;
using IdentityServer4.Models;
using IdentityServer4.Services;
using Microsoft.AspNetCore.Identity;

namespace IdentityService.Services
{
    public class IdentityProfileService : IProfileService
    {
        private readonly IUserClaimsPrincipalFactory<User> _userClaimsPrincipalFactory;
        private readonly UserManager<User> _userMgr;
        //private readonly RoleManager<Role> _roleMgr;

        public IdentityProfileService(IUserClaimsPrincipalFactory<User> userClaimsPrincipalFactory
            , UserManager<User> userMgr)
        {
            _userClaimsPrincipalFactory = userClaimsPrincipalFactory;
            _userMgr = userMgr;
          //  _roleMgr = roleMgr;

        }

        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
        {
            //Get user SubjectId / UserId
            string sub = context.Subject.GetSubjectId(); //IdentityServer4.Extensions 

            //Find the user by its Id
            User user = await _userMgr.FindByIdAsync(sub);

            //Get claims infor for the user
            ClaimsPrincipal userClaims = await _userClaimsPrincipalFactory.CreateAsync(user);

            List<Claim> claims = userClaims.Claims.ToList();

            context.IssuedClaims = claims;
        }

        public async Task IsActiveAsync(IsActiveContext context)
        {
            //Get user SubjectId / UserId
            string sub = context.Subject.GetSubjectId(); //IdentityServer4.Extensions 

            //Find the user by its Id
            User user = await _userMgr.FindByIdAsync(sub);

            context.IsActive = user != null;
        }
    }
}
