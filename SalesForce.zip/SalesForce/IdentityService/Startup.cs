﻿using Core.Entities;
using IdentityServer4.Services;
using IdentityService.Features.UserFeatures.CreateUser;
using IdentityService.Services;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.OpenApi.Models;
using System.Security.Cryptography.X509Certificates;
using System.Reflection;
using Core.Entities;
using Infastructure.Repository.Base;
using Infastructure.Data;
using Microsoft.AspNetCore.HttpOverrides;
using System.IdentityModel.Tokens.Jwt;
using Infrastructure;
using Util.Middleware;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace IdentityService
{
    public class Startup
    {
        public IWebHostEnvironment Environment { get; }
        public IConfiguration Configuration { get; }

        public X509Certificate2 _signingCertificate;

        public Startup(IWebHostEnvironment environment, IConfiguration configuration)
        {
            Environment = environment;
            Configuration = configuration;

        }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "IdentityService", Version = "v1" });
            });


            services.AddCors(p => p.AddPolicy("corsapp", builder =>
            {
                builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader().AllowAnyOrigin();
            }));

            services.Configure<ForwardedHeadersOptions>(options =>
            {
                options.ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto;
            });

            services.AddMyCustomMediatR<CreateUserHandler>();

            services.AddAutoMapper(typeof(CreateUserHandler).Assembly);

            services.AddMyCustomValidator<CreateUserHandler>();

            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            //services.AddControllersWithViews();

            string connectionString;

            if (!Environment.IsDevelopment())
            {
                connectionString = Configuration.GetConnectionString("connection");
            }
            else
            {
                connectionString = Configuration.GetConnectionString("connection");
            }

            var migrationsAssembly = typeof(Startup).GetTypeInfo().Assembly.GetName().Name;

            services.AddDbContext<DataContext>(builder =>
                builder.UseSqlServer(connectionString, sqlOptions => sqlOptions.MigrationsAssembly(migrationsAssembly)));

            services.AddIdentity<User, Role>(opt =>
            {
                // opt.SignIn.RequireConfirmedEmail = true;

            })
              .AddEntityFrameworkStores<DataContext>();
            // .AddDefaultTokenProviders();

            var builder = services.AddIdentityServer(options =>
            {
                options.Events.RaiseErrorEvents = true;
                options.Events.RaiseInformationEvents = true;
                options.Events.RaiseFailureEvents = true;
                options.Events.RaiseSuccessEvents = true;

                // see https://identityserver4.readthedocs.io/en/latest/topics/resources.html
                options.EmitStaticAudienceClaim = true;
            })
                .AddAspNetIdentity<User>()
    .AddInMemoryApiScopes(Config.ApiScopes)
    .AddInMemoryIdentityResources(Config.IdentityResources)
    .AddInMemoryClients(Config.Clients)
    .AddInMemoryApiResources(Config.GetAllApiResources())
    .AddDeveloperSigningCredential();

          //  builder.AddSigningCredential(CreateSigningCredential());

            services.AddControllersWithViews();


            //Add  AuthorizeFilter to Action Method
            services.AddControllers(config =>
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();

                config.Filters.Add(new AuthorizeFilter(policy));
            });

            builder.Services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;


            })
          .AddCookie()
          .AddIdentityServerAuthentication(options =>
          {
              // base-address of your identityserver
              if (!Environment.IsDevelopment())
              {
                  options.Authority = Configuration.GetConnectionString("IdentityServerDevUrl");

              }
              else
              {
                  options.Authority = Configuration.GetConnectionString("IdentityServerLocalUrl");
              }

              // options.RequireHttpsMetadata = false;

              // name of the API resource
              options.ApiName = Configuration.GetConnectionString("APIResource");
          });

            //Inject service for IdentityServer4 to fetch user roles and add role claim
            services.AddScoped<IProfileService, IdentityProfileService>();


            // AuthorizationPolicy in Claim
            services.AddSingleton<IAuthorizationPolicyProvider, CustomPolicyProvider>();

        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseSwagger();

            app.UseSwaggerUI(c =>
            {
                if (Environment.IsDevelopment())
                {
                    c.SwaggerEndpoint("/swagger/v1/swagger.json", "IdentityService v1");
                }
            });

            if (Environment.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStaticFiles();
            app.UseCookiePolicy(new CookiePolicyOptions { MinimumSameSitePolicy = SameSiteMode.Lax });

            app.UseRouting();

            app.UseCors("corsapp");

            app.UseIdentityServer();

            app.UseAuthorization();

            app.UseErrorHandlingMiddleware();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapDefaultControllerRoute();
            });
        }

        public X509Certificate2 CreateSigningCredential()
        {
            if (_signingCertificate != null)
                return _signingCertificate;

            var certBytes = Configuration.GetValue<string>("Auth:Certificate");
            if (string.IsNullOrEmpty(certBytes))
            {
                return null;
            }

            var password = Configuration.GetValue<string>("Auth:CertificatePassword");
            if (string.IsNullOrEmpty(password))
            {
                return null;
            }

            var certificate = Convert.FromBase64String(certBytes);
            _signingCertificate = new X509Certificate2(certificate, password);

            return _signingCertificate;
        }

    }
}