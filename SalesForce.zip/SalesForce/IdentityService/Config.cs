﻿// Copyright (c) Brock Allen & Dominick Baier. All rights reserved.
// Licensed under the Apache License, Version 2.0. See LICENSE in the project root for license information.


using IdentityModel;
using IdentityServer4;
using IdentityServer4.Models;
using IdentityServer4.Test;
using System.Collections.Generic;
using System.Security.Claims;

namespace IdentityService
{
    public static class Config
    {
        public static IEnumerable<IdentityResource> IdentityResources =>
                   new IdentityResource[]
                   {
                        new IdentityResources.OpenId(),
                        new IdentityResources.Profile(),
                   };

        public static IEnumerable<ApiScope> ApiScopes =>
            new ApiScope[]
            {
                new ApiScope("scope1"),
                new ApiScope("scope2"),
                new ApiScope("bankOfDotNetAPI"),
                 new ApiScope("ProgramApi", "Customer ApiScope"),
                new ApiScope("API")
            };

        public static IEnumerable<Client> Clients =>
            new Client[]
            {
                // m2m client credentials flow client
                new Client
                {
                    ClientId = "m2m.client",
                    ClientName = "Client Credentials Client",

                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    ClientSecrets = { new Secret("511536EF-F270-4058-80CA-1C89C192F69A".Sha256()) },

                    AllowedScopes = { "scope1" ,"API" }
                },

                // interactive client using code flow + pkce
                new Client
                {
                    ClientId = "interactive",
                    ClientSecrets = { new Secret("49C1A7E1-0C79-4A89-A3D6-A37998FB86B0".Sha256()) },

                    AllowedGrantTypes = GrantTypes.Code,

                    RedirectUris = { "https://localhost:44300/signin-oidc" },
                    FrontChannelLogoutUri = "https://localhost:44300/signout-oidc",
                    PostLogoutRedirectUris = { "https://localhost:44300/signout-callback-oidc" },

                    AllowOfflineAccess = true,
                    AllowedScopes = { "openid", "profile", "scope2", "API", }
                },
                new Client
                {
                    ClientId = "oidcClient",
                    ClientName = "Example Client Application",
                    ClientSecrets = new List<Secret> {new Secret("SuperSecretPassword".Sha256())}, // change me!
                    
                    AllowedGrantTypes = {
                        GrantType.Implicit,
                        GrantType.ResourceOwnerPassword,
                    },

                    RedirectUris = new List<string> {"https://localhost:5003/signin-oidc"},
                    AllowedScopes = {
                        IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        "ProgramApi",
                        "bankOfDotNetAPI",
                        "API",
                    },

                    RequirePkce = true,
                    AllowPlainTextPkce = false,

                    AllowAccessTokensViaBrowser = true,
                    RequireConsent = false,
                     //This feature refresh token
                    AllowOfflineAccess = true,
                    //Access token life time is 7200 seconds (2 hour)
                    AccessTokenLifetime = 7200,
                    //Identity token life time is 7200 seconds (2 hour)
                    IdentityTokenLifetime = 7200
                },

                new Client
                {
                    ClientId = "apiclient",
                    ClientName = "WB Client for API Application",
                    ClientSecrets = new List<Secret> {new Secret("SuperSecretPassword".Sha256())}, // change me!
                    AllowedGrantTypes = GrantTypes.ResourceOwnerPassword,
                    AllowedScopes = {
                          IdentityServerConstants.StandardScopes.OpenId,
                        IdentityServerConstants.StandardScopes.Profile,
                        "API"
                    },
                    AllowOfflineAccess = true,
                     //Access token life time is 7200 seconds (2 hour)
                    AccessTokenLifetime = 7200,
                    //Identity token life time is 7200 seconds (2 hour)
                    IdentityTokenLifetime = 7200
                },
            };

        internal static List<TestUser> GetTestUsers()
        {

            return new List<TestUser>
            {
                new TestUser
                {
                    SubjectId = "5BE86359-073C-434B-AD2D-A3932222DABE",
                    Username = "scott",
                    Password = "Password123!",
                    Claims = new List<Claim>
                    {
                        new Claim(JwtClaimTypes.Email, "scott@scottbrady91.com"),
                        new Claim(JwtClaimTypes.Role, "admin"),
                        new Claim(JwtClaimTypes.Name, "Scott Smith"),
                        new Claim(JwtClaimTypes.GivenName, "Scott"),
                        new Claim(JwtClaimTypes.FamilyName, "Smith"),
                        new Claim(JwtClaimTypes.WebSite, "http://alice.com"),
                    }
                },
                 new TestUser
                {
                    SubjectId = "1",
                    Username = "Kanaiya",
                    Password = "Password123!",
                    Claims = new List<Claim>
                    {
                        new Claim(JwtClaimTypes.Email, "katarmal.kanaiya@gmail.com"),
                        new Claim(JwtClaimTypes.Role, "user"),
                        new Claim(JwtClaimTypes.Name, "Kanaiya Katarmal"),
                        new Claim(JwtClaimTypes.GivenName, "Kanaiya"),
                        new Claim(JwtClaimTypes.FamilyName, "Katarmal"),
                        new Claim(JwtClaimTypes.WebSite, "http://domain.in"),
                    }
                }
            };
        }

        internal static IEnumerable<ApiResource> GetAllApiResources()
        {
            return new List<ApiResource>
              {
                  new ApiResource("API", "Bank API")
                    {
                        Scopes = { "scope1", "scope2", "bankOfDotNetAPI", "ProgramApi","API" }
                    }

              };


        }
    }
}