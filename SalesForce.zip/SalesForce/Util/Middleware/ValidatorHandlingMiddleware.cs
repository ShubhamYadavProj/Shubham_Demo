﻿
namespace Util.Middleware
{
    using FluentValidation.AspNetCore;
    using MediatR;
    using Microsoft.Extensions.DependencyInjection;
    using System.Reflection;

    public static class ValidatorHandlingMiddleware
    {
        public static IServiceCollection AddMyCustomValidator<T>(this IServiceCollection services)
        {
            services.AddFluentValidation(fv =>
            {
                fv.DisableDataAnnotationsValidation = true;
                fv.RegisterValidatorsFromAssembly(typeof(T).GetTypeInfo().Assembly);
            });

            return services;
        }

        public static IServiceCollection AddMyCustomMediatR<T>(this IServiceCollection services)
        {
            services.AddMediatR(typeof(T).GetTypeInfo().Assembly);

            return services;
        }

    }
}
