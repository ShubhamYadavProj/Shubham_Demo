﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;

namespace Util.Middleware
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;

        public ErrorHandlingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext, ILogger<ErrorHandlingMiddleware> logger)
        {
            try
            {
                await _next(httpContext);
            }
            catch (SqlException ex)
            {
               // await _emailService.SendSqlException(ex);
                await HandleSqlExceptionAsync(httpContext, ex);
            }
            catch (Exception ex)
            {
              //  await _emailService.SendException(ex);
                await HandleExceptionAsync(httpContext, ex, logger);
            }
        }

        public static string GetInnerException(Exception ex)
        {
            if (ex.InnerException != null)
            {
                return string.Format("{0} > {1} ", ex.InnerException.Message, GetInnerException(ex.InnerException));
            }
            return string.Empty;
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception ex, ILogger<ErrorHandlingMiddleware> logger)
        {
            logger.LogError($"{ex.Message}");

            var result = JsonConvert.SerializeObject(new
            {
                Type = "General Exception",
                Exception = new
                {
                    Message = ex.Message,
                    //Inner = ex.InnerException
                    Inner = GetInnerException(ex)
                }
            },
            Newtonsoft.Json.Formatting.Indented,
            new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = 500;
            return context.Response.WriteAsync(result);
        }

        private static Task HandleSqlExceptionAsync(HttpContext context, SqlException ex)
        {
            var errorList = new List<Object>();

            for (int i = 0; i < ex.Errors.Count; i++)
            {
                errorList.Add(new
                {

                    Message = ex.Errors[i].Message,
                    Procedure = ex.Errors[i].Procedure,
                    LineNumber = ex.Errors[i].LineNumber,
                    Source = ex.Errors[i].Source,
                    Server = ex.Errors[i].Server
                });
            }

            var result = JsonConvert.SerializeObject(new
            {
                Type = "SQL Exception",
                Exceptions = errorList
            });

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = 500;
            return context.Response.WriteAsync(result);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class ErrorHandlingMiddlewareExtensions
    {
        public static IApplicationBuilder UseErrorHandlingMiddleware(this IApplicationBuilder builder)
        {
            // var serviceCollection = new Microsoft.Extensions.DependencyInjection.ServiceCollection();

            return builder.UseMiddleware<ErrorHandlingMiddleware>();
        }
    }
}
