﻿namespace Util
{
    public class Class1
    {

    }
}