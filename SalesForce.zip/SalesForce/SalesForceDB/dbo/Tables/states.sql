﻿CREATE TABLE [dbo].[states] (
    [state_id]     INT            IDENTITY (1, 1) NOT NULL,
    [state_name]   NVARCHAR (MAX) NOT NULL,
    [created_by]   VARCHAR (50)   NULL,
    [updated_by]   VARCHAR (50)   NULL,
    [created_date] DATETIME       NULL,
    [updated_date] DATETIME       NULL,
    CONSTRAINT [PK_state] PRIMARY KEY CLUSTERED ([state_id] ASC)
);

