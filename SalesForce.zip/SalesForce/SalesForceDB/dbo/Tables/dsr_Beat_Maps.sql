﻿CREATE TABLE [dbo].[dsr_Beat_Maps] (
    [dsr_id]       INT          IDENTITY (1, 1) NOT NULL,
    [employee_id]  INT          NOT NULL,
    [beat_id]      INT          NOT NULL,
    [created_by]   VARCHAR (50) NULL,
    [updated_by]   VARCHAR (50) NULL,
    [created_date] DATETIME     NULL,
    [updated_date] DATETIME     NULL,
    [status]       INT          NULL,
    CONSTRAINT [PK_dsr_Beat_Maps] PRIMARY KEY CLUSTERED ([dsr_id] ASC),
    FOREIGN KEY ([employee_id]) REFERENCES [dbo].[employees] ([employee_id]),
    CONSTRAINT [FK_dsr_Beat_Maps_beats_beat_id] FOREIGN KEY ([beat_id]) REFERENCES [dbo].[beats] ([beat_id]) ON DELETE CASCADE
);




GO



GO
CREATE NONCLUSTERED INDEX [IX_dsr_Beat_Maps_beat_id]
    ON [dbo].[dsr_Beat_Maps]([beat_id] ASC);

