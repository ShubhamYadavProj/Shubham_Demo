﻿CREATE TABLE [dbo].[distributors] (
    [distributor_id]   INT            IDENTITY (1, 1) NOT NULL,
    [distributor_name] NVARCHAR (MAX) NOT NULL,
    [city_id]          INT            NOT NULL,
    [manager_id]       INT            NULL,
    [status]           INT            NULL,
    [created_by]       VARCHAR (50)   NULL,
    [updated_by]       VARCHAR (50)   NULL,
    [created_date]     DATETIME       NULL,
    [updated_date]     DATETIME       NULL,
    CONSTRAINT [PK_distributors] PRIMARY KEY CLUSTERED ([distributor_id] ASC),
    FOREIGN KEY ([manager_id]) REFERENCES [dbo].[employees] ([employee_id]),
    CONSTRAINT [FK_distributors_city_city_id] FOREIGN KEY ([city_id]) REFERENCES [dbo].[cities] ([city_id]) ON DELETE CASCADE
);




GO
CREATE NONCLUSTERED INDEX [IX_distributors_city_id]
    ON [dbo].[distributors]([city_id] ASC);

