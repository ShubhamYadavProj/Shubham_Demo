﻿CREATE TABLE [dbo].[retailers] (
    [retailer_id]   INT            IDENTITY (1, 1) NOT NULL,
    [retailer_name] NVARCHAR (MAX) NOT NULL,
    [beat_id]       INT            NOT NULL,
    [city_id]       INT            NOT NULL,
    [status]        INT            NOT NULL,
    [created_by]    VARCHAR (50)   NULL,
    [updated_by]    VARCHAR (50)   NULL,
    [created_date]  DATETIME       NULL,
    [updated_date]  DATETIME       NULL,
    [dsr_id]        INT            NULL,
    CONSTRAINT [PK_retailers] PRIMARY KEY CLUSTERED ([retailer_id] ASC),
    CONSTRAINT [FK_retailers_beats_beat_id] FOREIGN KEY ([beat_id]) REFERENCES [dbo].[beats] ([beat_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_retailers_city_city_id] FOREIGN KEY ([city_id]) REFERENCES [dbo].[cities] ([city_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_retailers_dsr_Beat_Maps] FOREIGN KEY ([dsr_id]) REFERENCES [dbo].[dsr_Beat_Maps] ([dsr_id])
);






GO
CREATE NONCLUSTERED INDEX [IX_retailers_city_id]
    ON [dbo].[retailers]([city_id] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_retailers_beat_id]
    ON [dbo].[retailers]([beat_id] ASC);

