﻿CREATE TABLE [dbo].[employeebeatmap] (
    [employeebeatmap_id] INT IDENTITY (1, 1) NOT NULL,
    [employee_id]        INT NULL,
    [beat_id]            INT NULL,
    [status]             INT NULL,
    PRIMARY KEY CLUSTERED ([employeebeatmap_id] ASC),
    FOREIGN KEY ([beat_id]) REFERENCES [dbo].[beats] ([beat_id]),
    FOREIGN KEY ([employee_id]) REFERENCES [dbo].[employees] ([employee_id])
);

