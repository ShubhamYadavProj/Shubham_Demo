﻿CREATE TABLE [dbo].[beats] (
    [beat_id]      INT            IDENTITY (1, 1) NOT NULL,
    [beat_name]    NVARCHAR (MAX) NOT NULL,
    [STATUS]       INT            NULL,
    [created_by]   VARCHAR (50)   NULL,
    [updated_by]   VARCHAR (50)   NULL,
    [created_date] DATETIME       NULL,
    [updated_date] DATETIME       NULL,
    CONSTRAINT [PK_beats] PRIMARY KEY CLUSTERED ([beat_id] ASC)
);

