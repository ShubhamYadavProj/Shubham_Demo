﻿CREATE TABLE [dbo].[Retails] (
    [retail_id]   INT            IDENTITY (1, 1) NOT NULL,
    [retail_name] NVARCHAR (MAX) NOT NULL,
    [status]      INT            NULL,
    CONSTRAINT [PK_Retails] PRIMARY KEY CLUSTERED ([retail_id] ASC)
);

