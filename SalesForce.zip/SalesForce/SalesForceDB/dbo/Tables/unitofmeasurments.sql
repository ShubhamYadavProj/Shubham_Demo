﻿CREATE TABLE [dbo].[unitofmeasurments] (
    [unit_of_measurment_id] INT            IDENTITY (1, 1) NOT NULL,
    [name]                  NVARCHAR (MAX) NULL,
    [status]                INT            NULL,
    [created_by]            VARCHAR (50)   NULL,
    [updated_by]            VARCHAR (50)   NULL,
    [created_date]          DATETIME       NULL,
    [updated_date]          DATETIME       NULL,
    CONSTRAINT [PK_unitofmeasurments] PRIMARY KEY CLUSTERED ([unit_of_measurment_id] ASC)
);

