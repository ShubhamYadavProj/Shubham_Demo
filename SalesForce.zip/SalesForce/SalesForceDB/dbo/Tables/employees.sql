﻿CREATE TABLE [dbo].[employees] (
    [employee_id]    INT            IDENTITY (1, 1) NOT NULL,
    [employee_name]  NVARCHAR (MAX) NOT NULL,
    [employee_email] NVARCHAR (MAX) NOT NULL,
    [employee_phone] NVARCHAR (MAX) NOT NULL,
    [employeeType]   INT            NOT NULL,
    [manager_id]     INT            NULL,
    [status]         INT            NULL,
    [created_by]     VARCHAR (50)   NULL,
    [updated_by]     VARCHAR (50)   NULL,
    [created_date]   DATETIME       NULL,
    [updated_date]   DATETIME       NULL,
    CONSTRAINT [PK_employees] PRIMARY KEY CLUSTERED ([employee_id] ASC),
    CONSTRAINT [FK_Employee_Manager] FOREIGN KEY ([manager_id]) REFERENCES [dbo].[employees] ([employee_id])
);

