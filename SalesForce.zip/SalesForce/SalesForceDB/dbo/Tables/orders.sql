﻿CREATE TABLE [dbo].[orders] (
    [order_id]       INT            IDENTITY (1, 1) NOT NULL,
    [order_name]     NVARCHAR (MAX) NOT NULL,
    [total]          NVARCHAR (MAX) NOT NULL,
    [distributor_id] INT            NOT NULL,
    [status]         INT            NULL,
    [retailer_id]    INT            NULL,
    [created_by]     VARCHAR (50)   NULL,
    [updated_by]     VARCHAR (50)   NULL,
    [created_date]   DATETIME       NULL,
    [updated_date]   DATETIME       NULL,
    CONSTRAINT [PK_orders] PRIMARY KEY CLUSTERED ([order_id] ASC),
    FOREIGN KEY ([distributor_id]) REFERENCES [dbo].[distributors] ([distributor_id]),
    CONSTRAINT [FK_orders_distributors_distributor_id] FOREIGN KEY ([distributor_id]) REFERENCES [dbo].[distributors] ([distributor_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_orders_retailers_retailer_id] FOREIGN KEY ([retailer_id]) REFERENCES [dbo].[retailers] ([retailer_id])
);




GO
CREATE NONCLUSTERED INDEX [IX_orders_distributor_id]
    ON [dbo].[orders]([distributor_id] ASC);

