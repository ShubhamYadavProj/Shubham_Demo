﻿CREATE TABLE [dbo].[order_details] (
    [order_deatils_id] INT           IDENTITY (1, 1) NOT NULL,
    [quantity]         INT           NOT NULL,
    [order_date]       DATETIME2 (7) NOT NULL,
    [order_id]         INT           NOT NULL,
    [sku_id]           INT           NOT NULL,
    [status]           INT           NULL,
    [created_by]       VARCHAR (50)  NULL,
    [updated_by]       VARCHAR (50)  NULL,
    [created_date]     DATETIME      NULL,
    [updated_date]     DATETIME      NULL,
    CONSTRAINT [PK_order_details] PRIMARY KEY CLUSTERED ([order_deatils_id] ASC),
    CONSTRAINT [FK_order_details_orders_order_id] FOREIGN KEY ([order_id]) REFERENCES [dbo].[orders] ([order_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_order_details_sku_sku_id] FOREIGN KEY ([sku_id]) REFERENCES [dbo].[sku] ([sku_id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_order_details_sku_id]
    ON [dbo].[order_details]([sku_id] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_order_details_order_id]
    ON [dbo].[order_details]([order_id] ASC);

