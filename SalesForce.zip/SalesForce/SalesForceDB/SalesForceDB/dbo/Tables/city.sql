﻿CREATE TABLE [dbo].[city] (
    [city_id]      INT            IDENTITY (1, 1) NOT NULL,
    [city_name]    NVARCHAR (MAX) NOT NULL,
    [state_id]     INT            NOT NULL,
    [created_by]   VARCHAR (50)   NULL,
    [updated_by]   VARCHAR (50)   NULL,
    [created_date] DATETIME       NULL,
    [updated_date] DATETIME       NULL,
    CONSTRAINT [PK_city] PRIMARY KEY CLUSTERED ([city_id] ASC),
    CONSTRAINT [FK_city_state_state_id] FOREIGN KEY ([state_id]) REFERENCES [dbo].[state] ([state_id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_city_state_id]
    ON [dbo].[city]([state_id] ASC);

