﻿CREATE TABLE [dbo].[sku] (
    [sku_id]                INT            IDENTITY (1, 1) NOT NULL,
    [sku_name]              NVARCHAR (MAX) NOT NULL,
    [sku_price]             REAL           NOT NULL,
    [category_id]           INT            NOT NULL,
    [status]                INT            NULL,
    [unit_of_measurment_id] INT            NULL,
    [created_by]            VARCHAR (50)   NULL,
    [updated_by]            VARCHAR (50)   NULL,
    [created_date]          DATETIME       NULL,
    [updated_date]          DATETIME       NULL,
    CONSTRAINT [PK_sku] PRIMARY KEY CLUSTERED ([sku_id] ASC),
    CONSTRAINT [FK_sku_catageroy_category_id] FOREIGN KEY ([category_id]) REFERENCES [dbo].[catageroy] ([category_id]) ON DELETE CASCADE,
    CONSTRAINT [fk_sku_id] FOREIGN KEY ([unit_of_measurment_id]) REFERENCES [dbo].[unitofmeasurments] ([unit_of_measurment_id])
);


GO
CREATE NONCLUSTERED INDEX [IX_sku_category_id]
    ON [dbo].[sku]([category_id] ASC);

