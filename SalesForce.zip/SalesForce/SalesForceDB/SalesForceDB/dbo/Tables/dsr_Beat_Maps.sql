﻿CREATE TABLE [dbo].[dsr_Beat_Maps] (
    [Id]           INT          IDENTITY (1, 1) NOT NULL,
    [emplyee_id]   INT          NOT NULL,
    [employee_id]  INT          NOT NULL,
    [beat_id]      INT          NOT NULL,
    [created_by]   VARCHAR (50) NULL,
    [updated_by]   VARCHAR (50) NULL,
    [created_date] DATETIME     NULL,
    [updated_date] DATETIME     NULL,
    CONSTRAINT [PK_dsr_Beat_Maps] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_dsr_Beat_Maps_beats_beat_id] FOREIGN KEY ([beat_id]) REFERENCES [dbo].[beats] ([beat_id]) ON DELETE CASCADE,
    CONSTRAINT [FK_dsr_Beat_Maps_employees_emplyee_id] FOREIGN KEY ([emplyee_id]) REFERENCES [dbo].[employees] ([employee_id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_dsr_Beat_Maps_emplyee_id]
    ON [dbo].[dsr_Beat_Maps]([emplyee_id] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_dsr_Beat_Maps_beat_id]
    ON [dbo].[dsr_Beat_Maps]([beat_id] ASC);

