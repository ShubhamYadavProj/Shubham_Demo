﻿CREATE TABLE [dbo].[catageroy] (
    [category_id]   INT            IDENTITY (1, 1) NOT NULL,
    [category_name] NVARCHAR (MAX) NOT NULL,
    [status]        INT            NOT NULL,
    [created_by]    VARCHAR (50)   NULL,
    [updated_by]    VARCHAR (50)   NULL,
    [created_date]  DATETIME       NULL,
    [updated_date]  DATETIME       NULL,
    CONSTRAINT [PK_catageroy] PRIMARY KEY CLUSTERED ([category_id] ASC)
);



