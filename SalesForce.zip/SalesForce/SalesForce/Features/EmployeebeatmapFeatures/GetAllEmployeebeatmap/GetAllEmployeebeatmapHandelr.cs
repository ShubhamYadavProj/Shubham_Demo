﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using SalesForce.Features.DistributorFeatures;
using System.Data.Entity.Infrastructure.Design;

namespace SalesForce.Features.EmployeebeatmapFeatures.GetAllEmployeebeatmap
{
    public class GetAllEmployeebeatmapHandelr:IRequestHandler<GetAllEmployeebeatmapRequestModel, GetAllEmployeebeatmapResponseModel>
    {
        private readonly IRepository<Employeebeatmap> _Employeebeatmaprepository;
        private readonly IMapper _Mapper;
        private readonly IUnitOfWork _UnitOfWork;

        public GetAllEmployeebeatmapHandelr(IRepository<Employeebeatmap> employeebeatmaprepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Employeebeatmaprepository = employeebeatmaprepository;
            _Mapper = mapper;
            _UnitOfWork = unitOfWork;
        }

        public Task<GetAllEmployeebeatmapResponseModel> Handle(GetAllEmployeebeatmapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllEmployeebeatmapResponseModel()
            {
                empbeat = GetAllEmployeebeatmap()
            });
        }

        private List<EmployeebeatmapReprsentaionModel> GetAllEmployeebeatmap()
        {
            return _Employeebeatmaprepository.GetAllQuery()
                                             .Where(s => s.status == Core.Enum.EntityStatus.Active)
                                             .ProjectTo<EmployeebeatmapReprsentaionModel>(_Mapper.ConfigurationProvider)
                                             .ToList();

        }
    }
}
