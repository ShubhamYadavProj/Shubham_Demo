﻿using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.GetAllEmployeebeatmap
{
    public class GetAllEmployeebeatmapRequestModel:IRequest<GetAllEmployeebeatmapResponseModel>
    {
    }
}
