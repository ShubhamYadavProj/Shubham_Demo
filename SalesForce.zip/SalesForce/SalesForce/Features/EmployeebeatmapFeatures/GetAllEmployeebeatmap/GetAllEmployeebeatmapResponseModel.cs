﻿namespace SalesForce.Features.EmployeebeatmapFeatures.GetAllEmployeebeatmap
{
    public class GetAllEmployeebeatmapResponseModel
    {
        public List<EmployeebeatmapReprsentaionModel> empbeat {get; set;}
    }
}
