﻿using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.AddEmployeebeatmap
{
    public class AddEmployeebeatmapRequestModel:IRequest<AddEmployeebeatmapResponseModel>
    {
        public EmployeebeatmapReprsentaionModel add { get; set; }
    }
}
