﻿namespace SalesForce.Features.EmployeebeatmapFeatures.AddEmployeebeatmap
{
    public class AddEmployeebeatmapResponseModel
    {
        public EmployeebeatmapReprsentaionModel add { get; set; }
    }
}
