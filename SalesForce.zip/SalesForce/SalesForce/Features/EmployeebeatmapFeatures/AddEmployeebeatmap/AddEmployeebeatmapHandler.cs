﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;

namespace SalesForce.Features.EmployeebeatmapFeatures.AddEmployeebeatmap
{
    public class AddEmployeebeatmapHandler : IRequestHandler<AddEmployeebeatmapRequestModel, AddEmployeebeatmapResponseModel>
    {
        private readonly IRepository<Employeebeatmap> _Employeebeatmaprepository;
        private readonly IMapper _mapper; 
        private readonly IUnitOfWork _unitOfWork;
        public AddEmployeebeatmapHandler(IRepository<Employeebeatmap> employeebeatmaprepository, IMapper mapper,IUnitOfWork unitOfWork)
        {
            _Employeebeatmaprepository = employeebeatmaprepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

       

        Task<AddEmployeebeatmapResponseModel> IRequestHandler<AddEmployeebeatmapRequestModel, AddEmployeebeatmapResponseModel>.Handle(AddEmployeebeatmapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddEmployeebeatmapResponseModel() 
            { 
            add = added(request)
        });
        }

        private EmployeebeatmapReprsentaionModel added(AddEmployeebeatmapRequestModel request)
        {

            
            var Ebm= _mapper.Map<Employeebeatmap>(request.add);
            Ebm.status = Core.Enum.EntityStatus.Active;
            _Employeebeatmaprepository.AddAsync(Ebm).ConfigureAwait(false).GetAwaiter().GetResult();
            _unitOfWork.Commit();
            return _mapper.Map<EmployeebeatmapReprsentaionModel>(request.add);
        }
    }
}
