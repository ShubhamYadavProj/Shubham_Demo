﻿using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.UpdateEmployeebeatmap
{
    public class UpdateEmployeebeatmapRequestModel:IRequest<UpdateEmployeebeatmapResponseModel>
    {
        public EmployeebeatmapReprsentaionModel empbetmap { get; set; }
    }
}
