﻿namespace SalesForce.Features.EmployeebeatmapFeatures.UpdateEmployeebeatmap
{
    public class UpdateEmployeebeatmapResponseModel
    {
        public EmployeebeatmapReprsentaionModel empbetmap { get; set; }
    }
}
