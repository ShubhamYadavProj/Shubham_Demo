﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.UpdateEmployeebeatmap
{
    public class UpdateEmployeebeatmapHendler:IRequestHandler<UpdateEmployeebeatmapRequestModel,UpdateEmployeebeatmapResponseModel>
    {
        private readonly IRepository<Employeebeatmap> _Employeebeatmaprepository;
        private readonly IMapper _Mapper;
        private readonly IUnitOfWork _unitOfWork;

       public UpdateEmployeebeatmapHendler(IRepository<Employeebeatmap> employeebeatmaprepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Employeebeatmaprepository = employeebeatmaprepository;
            _Mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<UpdateEmployeebeatmapResponseModel> Handle(UpdateEmployeebeatmapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateEmployeebeatmapResponseModel()
            {
                empbetmap= UpdateEmployeebeatmap(request)
            });
        }

        private EmployeebeatmapReprsentaionModel UpdateEmployeebeatmap(UpdateEmployeebeatmapRequestModel request)
        {
            var currentempbm = _Employeebeatmaprepository.GetAllQuery()
                                                         .Where(m => m.employeebeatmap_id == request.empbetmap.employeebeatmap_id)
                                                         .FirstOrDefault();
            if (currentempbm != null)
            {
                //currentempbm.employeebeatmap_id = request.empbetmap.employeebeatmap_id;
                currentempbm.employee_id=request.empbetmap.employee_id;
                currentempbm.beat_id=request.empbetmap.beat_id;

                _Employeebeatmaprepository.UpdateAsync(currentempbm).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();

            }
            return request.empbetmap;
        }
    }
}
