﻿using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.DeleteEmployeebeatmap
{
    public class DeleteEmployeebeatmapRequestModel:IRequest<DeleteEmployeebeatmapResponseModel>
    {
        public int id { get; set; }
    }
}
