﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeebeatmapFeatures.DeleteEmployeebeatmap
{
    public class DeleteEmployeebeatmapHendler:IRequestHandler<DeleteEmployeebeatmapRequestModel,DeleteEmployeebeatmapResponseModel>
    {

        private readonly IRepository<Employeebeatmap> _EmployeebeatmapRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;
        public DeleteEmployeebeatmapHendler(IRepository<Employeebeatmap> EmployeebeatmapRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _EmployeebeatmapRepository = EmployeebeatmapRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteEmployeebeatmapResponseModel> Handle(DeleteEmployeebeatmapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteEmployeebeatmapResponseModel()
            {
                IsDelete = DeleteEmployeebeatmap(request)
            });
        }

        private bool DeleteEmployeebeatmap(DeleteEmployeebeatmapRequestModel request)
        {
            var currentEbm=_EmployeebeatmapRepository.GetAllQuery().Where(m=> m.employeebeatmap_id==request.id).FirstOrDefault();
            if (currentEbm != null)
            {
                currentEbm.status = Core.Enum.EntityStatus.Inactive;
                _EmployeebeatmapRepository.UpdateAsync(currentEbm).ConfigureAwait(false).GetAwaiter().GetResult();
            }
            return _unitOfWork.Commit() > 0;
        }
    }
}
