﻿namespace SalesForce.Features.EmployeebeatmapFeatures.DeleteEmployeebeatmap
{
    public class DeleteEmployeebeatmapResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
