﻿using Core.Base;
using Core.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesForce.Features.EmployeebeatmapFeatures
{
    public class EmployeebeatmapReprsentaionModel
    {
        public int employeebeatmap_id { get; set; }

        
        public int employee_id { get; set; }

        public int beat_id { get; set; }
    }
}
