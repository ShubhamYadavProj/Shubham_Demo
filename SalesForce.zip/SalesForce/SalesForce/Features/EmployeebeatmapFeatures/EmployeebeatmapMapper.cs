﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.EmployeebeatmapFeatures
{
    public class EmployeebeatmapMapper : Profile
    {
        public EmployeebeatmapMapper()
        {
            CreateMap<Employeebeatmap, EmployeebeatmapReprsentaionModel>()
            .ForMember(des => des.employeebeatmap_id, opt => opt.MapFrom(src => src.employeebeatmap_id))
            .ForMember(des => des.employee_id, opt => opt.MapFrom(src => src.employee_id))
            .ForMember(des => des.beat_id, opt => opt.MapFrom(src => src.beat_id));

            CreateMap<EmployeebeatmapReprsentaionModel, Employeebeatmap>()
                .ForMember(des => des.employeebeatmap_id, opt => opt.MapFrom(src => src.employeebeatmap_id))
                .ForMember(des => des.employee_id, opt => opt.MapFrom(src => src.employee_id))
                .ForMember(des => des.beat_id, opt => opt.MapFrom(src => src.beat_id));



        }
    }
}
