﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.OrderFeatures.GetAllOrders
{
    public class GetAllOrdersHandler : IRequestHandler<GetAllOrdersRequestModel, GetAllOrdersResponseModel>
    {
        private readonly IRepository<Order> _orderRepository;
        private readonly IMapper _mapper;

        public GetAllOrdersHandler(IRepository<Order> orderRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _mapper = mapper;
        }

        public Task<GetAllOrdersResponseModel> Handle(GetAllOrdersRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllOrdersResponseModel()
            {
                Order=GetAllOrders()
            });
        }

        private List<OrderRepresentationModel> GetAllOrders()
        {
            return _orderRepository.GetAllQuery().Where(s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<OrderRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
