﻿using MediatR;

namespace SalesForce.Features.OrderFeatures.GetAllOrders
{
    public class GetAllOrdersRequestModel:IRequest<GetAllOrdersResponseModel>
    {

    }
}
