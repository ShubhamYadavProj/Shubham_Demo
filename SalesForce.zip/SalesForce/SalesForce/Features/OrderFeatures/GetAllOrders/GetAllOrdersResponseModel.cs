﻿namespace SalesForce.Features.OrderFeatures.GetAllOrders
{
    public class GetAllOrdersResponseModel
    {
        public List<OrderRepresentationModel> Order { get; set; }
    }
}
