﻿using Core.Entities;
using Core.Enum;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesForce.Features.OrderFeatures
{
    public class OrderRepresentationModel
    {

        public int order_id { get; set; }

        public string order_name { get; set; }

        public string total { get; set; }

        public int distributor_id { get; set; }

        public int retailer_id { get; set; }

     //   public IList<Order_deatils> deatils { get; set; }


    }
}
