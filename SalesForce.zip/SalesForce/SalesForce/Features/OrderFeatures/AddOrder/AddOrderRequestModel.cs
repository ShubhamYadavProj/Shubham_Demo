﻿using MediatR;

namespace SalesForce.Features.OrderFeatures.AddOrder
{
    public class AddOrderRequestModel:IRequest<AddOrderResponseModel>
    {
        public OrderRepresentationModel Order { get; set; }
    }
}
