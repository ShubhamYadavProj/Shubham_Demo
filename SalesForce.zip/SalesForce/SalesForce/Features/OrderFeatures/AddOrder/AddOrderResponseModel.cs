﻿namespace SalesForce.Features.OrderFeatures.AddOrder
{
    public class AddOrderResponseModel
    {
        public OrderRepresentationModel Order { get; set; }
    }
}
