﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;

namespace SalesForce.Features.OrderFeatures.AddOrder
{
    public class AddOrderValidation:AbstractValidator<AddOrderRequestModel>
    {
        public AddOrderValidation(IRepository<Order> _repository)
        {

            RuleFor(req => req.Order.order_name)
              .NotNull()
              .WithMessage("order name can not be null!")
              .NotEmpty()
              .WithMessage("order name can not be empty!");


            RuleFor(req => req.Order.retailer_id)
             .NotNull()
             .WithMessage("retailer can not be null!")
             .NotEmpty()
             .WithMessage("retailer can not be empty!");


            RuleFor(req => req.Order.distributor_id)
           .NotNull()
           .WithMessage("distributor can not be null!")
           .NotEmpty()
           .WithMessage("distributor can not be empty!");
        }

    }
}
