﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.OrderFeatures.AddOrder
{
    public class AddOrderHandler : IRequestHandler<AddOrderRequestModel, AddOrderResponseModel>
    {
        private readonly IRepository<Order> _orderRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public AddOrderHandler(IMapper mapper,IRepository<Order> repository,IUnitOfWork unitOfWork)
        {
                _mapper= mapper;
            _unitOfWork= unitOfWork;
            _orderRepository= repository;   
        }
        public Task<AddOrderResponseModel> Handle(AddOrderRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddOrderResponseModel()
            {
                Order = AddOrder(request)
            }) ;
            
        }

        private OrderRepresentationModel AddOrder(AddOrderRequestModel request)
        {
            var newOrder=_mapper.Map<Order>(request.Order);

            newOrder.status = Core.Enum.EntityStatus.Active;

            _orderRepository.AddAsync(newOrder).ConfigureAwait(false).GetAwaiter().GetResult();

            _unitOfWork.Commit();

            return _mapper.Map<OrderRepresentationModel>(newOrder);
        }
    }
}
