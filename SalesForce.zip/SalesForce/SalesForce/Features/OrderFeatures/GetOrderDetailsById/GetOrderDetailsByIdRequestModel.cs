﻿using MediatR;
using System.Security.Cryptography.X509Certificates;

namespace SalesForce.Features.OrderFeatures.GetOrderDetailsById
{
    public class GetOrderDetailsByIdRequestModel:IRequest<GetOrderDetailsByIdResponseModel>
    {
        public int orderId { get; set; }

    }
}
