﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.OrderFeatures.GetOrderDetailsById
{
    public class GetOrderDetailsByIdHandler : IRequestHandler<GetOrderDetailsByIdRequestModel, GetOrderDetailsByIdResponseModel>
    {
        private readonly IRepository<Order> _repository;
        private readonly IRepository<Order_deatils> _deatilsRepository;
        private readonly IMapper _mapper;

        public GetOrderDetailsByIdHandler(IRepository<Order> repository,IMapper mapper,IRepository<Order_deatils> repository1)
        {

            _repository = repository;
            _mapper = mapper;
            _deatilsRepository = repository1;
        }


        public Task<GetOrderDetailsByIdResponseModel> Handle(GetOrderDetailsByIdRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetOrderDetailsByIdResponseModel()
            {
                order = GetOrderDetailsById(request)
            });
        }

        private OrderRepresentationModel GetOrderDetailsById(GetOrderDetailsByIdRequestModel request)
        {
            // var currentOrder= _repository.GetAllQuery()
            //                   .Where(s=>s.order_id == request.orderId )
            //                   .ProjectTo<OrderRepresentationModel>(_mapper.ConfigurationProvider)
            //                   .FirstOrDefault();
            //var currentOrder_Deatil = _deatilsRepository.GetAllQuery().Where(s => s.order_id == request.orderId).ProjectTo<Order_deatils>(_mapper.ConfigurationProvider).ToList();

            //currentOrder.deatils = currentOrder_Deatil;

            //return currentOrder;

            return _deatilsRepository.GetAllQuery().Where(s => s.order_deatils_id == request.orderId).ProjectTo<OrderRepresentationModel>(_mapper.ConfigurationProvider).FirstOrDefault();



        }
    }
}
