﻿namespace SalesForce.Features.OrderFeatures.GetOrderDetailsById
{
    public class GetOrderDetailsByIdResponseModel
    {
        public OrderRepresentationModel order { get; set; }
    }
}
