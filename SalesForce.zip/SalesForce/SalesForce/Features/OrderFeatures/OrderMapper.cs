﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.OrderFeatures
{
    public class OrderMapper:Profile
    {

        public OrderMapper()
        {
            CreateMap<Order, OrderRepresentationModel>()
                .ForMember(dest => dest.order_id, opt => opt.MapFrom(src => src.order_id))
                 .ForMember(dest => dest.order_name, opt => opt.MapFrom(src => src.order_name))
                  .ForMember(dest => dest.total, opt => opt.MapFrom(src => src.total))
                   .ForMember(dest => dest.distributor_id, opt => opt.MapFrom(src => src.distributor_id))
                    .ForMember(dest => dest.retailer_id, opt => opt.MapFrom(src => src.retailer_id));
                  //  .ForMember(dest => dest.deatils, opt => opt.Ignore());

            CreateMap< OrderRepresentationModel,Order>()
               .ForMember(dest => dest.order_id, opt => opt.MapFrom(src => src.order_id))
                .ForMember(dest => dest.order_name, opt => opt.MapFrom(src => src.order_name))
                 .ForMember(dest => dest.total, opt => opt.MapFrom(src => src.total))
                  .ForMember(dest => dest.distributor_id, opt => opt.MapFrom(src => src.distributor_id))
                   .ForMember(dest => dest.retailer_id, opt => opt.MapFrom(src => src.retailer_id));
        }

    }
}
