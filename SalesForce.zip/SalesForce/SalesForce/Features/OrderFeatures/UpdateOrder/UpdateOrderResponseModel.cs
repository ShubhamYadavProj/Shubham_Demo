﻿namespace SalesForce.Features.OrderFeatures.UpdateOrder
{
    public class UpdateOrderResponseModel
    {
        public OrderRepresentationModel order { get; set; }
    }
}
