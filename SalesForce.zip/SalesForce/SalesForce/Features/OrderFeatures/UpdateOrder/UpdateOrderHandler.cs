﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.OrderFeatures.UpdateOrder
{
    public class UpdateOrderHandler : IRequestHandler<UpdateOrderRequestModel, UpdateOrderResponseModel>
    {
        private readonly IRepository<Order> _orderRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public UpdateOrderHandler(IMapper mapper, IRepository<Order> repository, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _orderRepository = repository;
        }
        public Task<UpdateOrderResponseModel> Handle(UpdateOrderRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateOrderResponseModel()
            {
                order = UpdateOrder(request)
            }) ;
        }

        private OrderRepresentationModel UpdateOrder(UpdateOrderRequestModel request)
        {
            var currentOrder=_orderRepository.GetAllQuery().Where(s=>s.order_id==request.order.order_id).FirstOrDefault();

            if (currentOrder!=null)
            {
                currentOrder.order_name = request.order.order_name;
                currentOrder.retailer_id=request.order.retailer_id;
                currentOrder.distributor_id=request.order.distributor_id;
                currentOrder.total=request.order.total;

                _orderRepository.UpdateAsync(currentOrder).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
            }

            return request.order;
        }
    }
}
