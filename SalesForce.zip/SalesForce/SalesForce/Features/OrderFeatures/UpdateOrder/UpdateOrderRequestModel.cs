﻿using MediatR;

namespace SalesForce.Features.OrderFeatures.UpdateOrder
{
    public class UpdateOrderRequestModel:IRequest<UpdateOrderResponseModel>
    {
        public OrderRepresentationModel order { get; set; }
    }
}
