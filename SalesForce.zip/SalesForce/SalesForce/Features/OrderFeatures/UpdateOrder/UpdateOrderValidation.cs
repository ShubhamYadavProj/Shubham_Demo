﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;

namespace SalesForce.Features.OrderFeatures.UpdateOrder
{
    public class UpdateOrderValidation:AbstractValidator<UpdateOrderRequestModel>
    {
        public UpdateOrderValidation(IRepository<Order> _repository)
        {

            RuleFor(req => req.order.order_name)
              .NotNull()
              .WithMessage("order name can not be null!")
              .NotEmpty()
              .WithMessage("order name can not be empty!");


            RuleFor(req => req.order.retailer_id)
             .NotNull()
             .WithMessage("retailer can not be null!")
             .NotEmpty()
             .WithMessage("retailer can not be empty!");


            RuleFor(req => req.order.distributor_id)
           .NotNull()
           .WithMessage("distributor can not be null!")
           .NotEmpty()
           .WithMessage("distributor can not be empty!");
        }
    }
}
