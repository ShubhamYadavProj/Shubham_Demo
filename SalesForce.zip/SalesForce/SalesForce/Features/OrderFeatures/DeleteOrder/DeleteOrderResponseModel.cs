﻿namespace SalesForce.Features.OrderFeatures.DeleteOrder
{
    public class DeleteOrderResponseModel
    {
        public bool IsDeleted { get; set; }
    }
}
