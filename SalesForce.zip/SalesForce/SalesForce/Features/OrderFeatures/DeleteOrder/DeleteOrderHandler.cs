﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.OrderFeatures.DeleteOrder
{
    public class DeleteOrderHandler : IRequestHandler<DeleteOrderRequestModel, DeleteOrderResponseModel>
    {
        private readonly IRepository<Order> _orderRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public DeleteOrderHandler(IMapper mapper, IRepository<Order> repository, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _unitOfWork = unitOfWork;
            _orderRepository = repository;
        }


        public Task<DeleteOrderResponseModel> Handle(DeleteOrderRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteOrderResponseModel()
            {
                IsDeleted = DeleteOrder(request)
            }) ;
        }

        private bool DeleteOrder(DeleteOrderRequestModel request)
        {

            var currentOrder=_orderRepository.GetAllQuery().Where(s=>s.order_id==request.orderId).FirstOrDefault();

            if (currentOrder!=null)
            {
                currentOrder.status = Core.Enum.EntityStatus.Inactive;

                _orderRepository.UpdateAsync(currentOrder).ConfigureAwait(false).GetAwaiter().GetResult();
            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
