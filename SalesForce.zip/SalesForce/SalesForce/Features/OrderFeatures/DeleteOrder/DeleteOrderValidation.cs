﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;

namespace SalesForce.Features.OrderFeatures.DeleteOrder
{
    public class DeleteOrderValidation:AbstractValidator<DeleteOrderRequestModel>
    {
        public DeleteOrderValidation(IRepository<Employee> _repository)
        {
            RuleFor(req => req.orderId)
               .NotNull()
               .WithMessage("order id can not be null!")
               .NotEmpty()
               .WithMessage("order id can not be empty!");


            RuleFor(req => req)
                .Custom((req, context) =>
                {
                    var orderExist = _repository.GetAllQuery()
                                                     .Where(id => id.employee_id == req.orderId)
                                                     .Where(s => s.status == Core.Enum.EntityStatus.Active)
                                                     .Any();
                    if (!orderExist)
                    {
                        context.AddFailure("Order does not exist");
                    }
                });
        }
    }
}
