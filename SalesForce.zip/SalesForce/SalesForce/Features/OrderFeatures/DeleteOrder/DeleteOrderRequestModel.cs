﻿using MediatR;

namespace SalesForce.Features.OrderFeatures.DeleteOrder
{
    public class DeleteOrderRequestModel:IRequest<DeleteOrderResponseModel>
    {
        public int orderId { get; set; }
    }
}
