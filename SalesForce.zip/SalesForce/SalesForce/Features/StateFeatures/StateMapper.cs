﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.StateFeatures
{
    public class StateMapper:Profile
    {
        public StateMapper()
        {
            CreateMap<State,StateRepresentationModel>()
                .ForMember(dest=>dest.State_id,opt=>opt.MapFrom(src=>src.state_id))
                 .ForMember(dest => dest.State_name, opt => opt.MapFrom(src => src.state_name));


            CreateMap<StateRepresentationModel,State>()
              .ForMember(dest => dest.state_id, opt => opt.MapFrom(src => src.State_id))
               .ForMember(dest => dest.state_name, opt => opt.MapFrom(src => src.State_name));

        }
    }
}
