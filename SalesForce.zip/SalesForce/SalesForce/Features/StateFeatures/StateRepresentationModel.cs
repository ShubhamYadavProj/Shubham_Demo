﻿namespace SalesForce.Features.StateFeatures
{
    public class StateRepresentationModel
    {
        public int State_id { get; set; }

        public string State_name { get; set; }
    }
}
