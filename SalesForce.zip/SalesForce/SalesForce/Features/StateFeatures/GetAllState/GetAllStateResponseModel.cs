﻿namespace SalesForce.Features.StateFeatures.GetAllState
{
    public class GetAllStateResponseModel
    {
        public List<StateRepresentationModel> State { get; set; }
    }
}
