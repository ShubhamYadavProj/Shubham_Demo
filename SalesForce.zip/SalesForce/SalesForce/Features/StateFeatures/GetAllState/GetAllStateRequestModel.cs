﻿using MediatR;

namespace SalesForce.Features.StateFeatures.GetAllState
{
    public class GetAllStateRequestModel:IRequest<GetAllStateResponseModel>
    {
    }
}
