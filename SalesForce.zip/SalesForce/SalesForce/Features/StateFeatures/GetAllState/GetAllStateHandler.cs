﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using System.Data.Entity;

namespace SalesForce.Features.StateFeatures.GetAllState
{
    public class GetAllStateHandler : IRequestHandler<GetAllStateRequestModel, GetAllStateResponseModel>
    {
        private readonly IRepository<State> _Staterepository;
        private readonly IMapper _mapper;

        public GetAllStateHandler(IRepository<State> staterepository, IMapper mapper)
        {
            _Staterepository = staterepository;
            _mapper = mapper;
        }

        public Task<GetAllStateResponseModel> Handle(GetAllStateRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllStateResponseModel()
            {
                State = GetAllState()
            }); 
        }

        private List<StateRepresentationModel> GetAllState()
        {
            return _Staterepository.GetAllQuery()
                                   .AsNoTracking()
                                   .ProjectTo<StateRepresentationModel>(_mapper.ConfigurationProvider)
                                   .ToList();
        }
    }
}
