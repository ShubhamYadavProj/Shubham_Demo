﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.CityFeatures
{
    public class CityMapper:Profile
    {

        public CityMapper()
        {
            CreateMap<City, CityRepresentaionModel>()
            .ForMember(des => des.City_id, opt => opt.MapFrom(src => src.city_id))
            .ForMember(des => des.City_name, opt => opt.MapFrom(src => src.city_name));
            //  .ForMember(des=>des.StateId,opt=>opt.MapFrom(src=>src.state_id));


            CreateMap<CityRepresentaionModel, City>()
               .ForMember(des => des.city_id, opt => opt.MapFrom(src => src.City_id))
               .ForMember(des => des.city_name, opt => opt.MapFrom(src => src.City_name));
               // .ForMember(des => des.state_id, opt => opt.MapFrom(src => src.StateId)); ;
        }
    }
}
