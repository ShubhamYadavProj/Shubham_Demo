﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using System.Data.Entity;

namespace SalesForce.Features.CityFeatures.GetAllCity
{
    public class GetAllCityHandler : IRequestHandler<GetAllCityRequestModel, GetAllCityResponseModel>
    {
        private readonly IRepository<City> _Cityrepository;
        private readonly IMapper _mapper;


        public GetAllCityHandler(IRepository<City> Cityrepository,IMapper mapper)
        {
            _mapper= mapper;
            _Cityrepository= Cityrepository;
        }
     

        public Task<GetAllCityResponseModel> Handle(GetAllCityRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllCityResponseModel()
            {
                City = GetAllCity(request)
            }); 
        }

        private List<CityRepresentaionModel> GetAllCity(GetAllCityRequestModel request)
        {
            return _Cityrepository.GetAllQuery()
                                  .Where(s=>s.state_id==request.StateID)
                                  .AsNoTracking()
                                  .ProjectTo<CityRepresentaionModel>(_mapper.ConfigurationProvider)
                                  .ToList(); 
        }
    }
}
