﻿namespace SalesForce.Features.CityFeatures.GetAllCity
{
    public class GetAllCityResponseModel
    {
        public List<CityRepresentaionModel> City { get; set; }
    }
}
