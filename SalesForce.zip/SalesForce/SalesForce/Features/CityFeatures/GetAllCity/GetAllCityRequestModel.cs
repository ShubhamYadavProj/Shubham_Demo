﻿using MediatR;

namespace SalesForce.Features.CityFeatures.GetAllCity
{
    public class GetAllCityRequestModel:IRequest<GetAllCityResponseModel>
    {
        public int StateID { get; set; }
    }
}
