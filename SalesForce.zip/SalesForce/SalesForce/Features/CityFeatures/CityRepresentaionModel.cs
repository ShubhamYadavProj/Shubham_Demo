﻿using Core.Entities;

namespace SalesForce.Features.CityFeatures
{
    public class CityRepresentaionModel
    {
        public int City_id { get; set; }
        public string City_name { get; set; }

      //  public int StateId { get; set; }

      //  public string StateName { get; set; }

       


    }
}
