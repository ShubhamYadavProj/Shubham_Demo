﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using Microsoft.EntityFrameworkCore.SqlServer.Query.Internal;

namespace SalesForce.Features.RetailerFeatures.UpdateRetailer
{
    public class UpdateRetailerHandler : IRequestHandler<UpdateRetailerRequestModel, UpdateRetailerResponseModel>
    {
        private readonly IRepository<Retailer> _retailerRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateRetailerHandler(IRepository<Retailer> retailerRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            this._retailerRepository = retailerRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<UpdateRetailerResponseModel> Handle(UpdateRetailerRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateRetailerResponseModel()
            {
                Retailer = UpdateRetailer(request)
            });
        }

        private RetailerRepresentationModel UpdateRetailer(UpdateRetailerRequestModel request)
        {
            var currentRetailer = _retailerRepository.GetAllQuery().Where(s => s.retailer_id == request.Retailer.retailer_id).FirstOrDefault();

            if (currentRetailer != null)
            {
                currentRetailer.retailer_name = request.Retailer.retailer_name;
                currentRetailer.beat_id = request.Retailer.beat_id;
                currentRetailer.city_id= request.Retailer.city_id;  
                _retailerRepository.UpdateAsync(currentRetailer).ConfigureAwait(false).GetAwaiter().GetResult();

                _unitOfWork.Commit();
            }

            return request.Retailer;
        }
    }
}
