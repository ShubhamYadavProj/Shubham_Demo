﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.UpdateRetailer
{
    public class UpdateRetailerRequestModel:IRequest<UpdateRetailerResponseModel>
    {
        public RetailerRepresentationModel Retailer { get; set; }
    }
}
