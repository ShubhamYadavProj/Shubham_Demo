﻿namespace SalesForce.Features.RetailerFeatures.UpdateRetailer
{
    public class UpdateRetailerResponseModel
    {
        public RetailerRepresentationModel Retailer { get; set; }
    }
}
