﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailers
{
    public class GetAllRetailersHandler : IRequestHandler<GetAllRetailersRequestModel, GetAllRetailersResponseModel>
    {
        private readonly IRepository<Retailer> _retailerRepository;
        private readonly IMapper _mapper;

        public GetAllRetailersHandler(IRepository<Retailer> retailerRepository, IMapper mapper)
        {
            _retailerRepository = retailerRepository;
            _mapper = mapper;
        }

        public Task<GetAllRetailersResponseModel> Handle(GetAllRetailersRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllRetailersResponseModel()
            {
                Retailers = GetAllRetailers()
            });
        }

        private List<RetailerRepresentationModel> GetAllRetailers()
        {
            return _retailerRepository.GetAllQuery().Where   (s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<RetailerRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }   
    }
}
