﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailers
{
    public class GetAllRetailersRequestModel:IRequest<GetAllRetailersResponseModel>
    {

    }
}
