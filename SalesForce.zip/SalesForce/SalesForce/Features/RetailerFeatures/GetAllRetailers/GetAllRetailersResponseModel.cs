﻿namespace SalesForce.Features.RetailerFeatures.GetAllRetailers
{
    public class GetAllRetailersResponseModel
    {
        public List<RetailerRepresentationModel> Retailers { get; set; }
    }
}
