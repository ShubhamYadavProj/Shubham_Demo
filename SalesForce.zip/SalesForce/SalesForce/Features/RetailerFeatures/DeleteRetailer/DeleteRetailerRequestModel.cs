﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.DeleteRetailer
{
    public class DeleteRetailerRequestModel:IRequest<DeleteRetailerResponseModel>
    {
        public int retailerId { get; set; } 
    }
}
