﻿namespace SalesForce.Features.RetailerFeatures.DeleteRetailer
{
    public class DeleteRetailerResponseModel
    {
        public bool IsDeleted { get; set; }
    }
}
