﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.RetailerFeatures.DeleteRetailer
{
    public class DeleteRetailerHandler : IRequestHandler<DeleteRetailerRequestModel, DeleteRetailerResponseModel>
    {
        private readonly IRepository<Retailer> _Retailerrepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteRetailerHandler(IRepository<Retailer> retailerrepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Retailerrepository = retailerrepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteRetailerResponseModel> Handle(DeleteRetailerRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteRetailerResponseModel()
            {
                IsDeleted = DeleteRetailer(request)
            }) ;
        }

        private bool DeleteRetailer(DeleteRetailerRequestModel request)
        {
            var currentRetailer=_Retailerrepository.GetAllQuery().Where(s=>s.retailer_id==request.retailerId).FirstOrDefault();

            if (currentRetailer!=null)
            {
                currentRetailer.status = Core.Enum.EntityStatus.Inactive;
                _Retailerrepository.UpdateAsync(currentRetailer).ConfigureAwait(false).GetAwaiter().GetResult();

            }
            return _unitOfWork.Commit() > 0;
        }
    }
}
