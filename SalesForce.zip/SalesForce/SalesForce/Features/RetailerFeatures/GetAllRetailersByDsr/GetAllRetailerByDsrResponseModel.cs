﻿namespace SalesForce.Features.RetailerFeatures.GetAllRetailersByDsr
{
    public class GetAllRetailerByDsrResponseModel
    {
        public List<RetailerRepresentationModel> rtailers { get; set; }
    }
}
