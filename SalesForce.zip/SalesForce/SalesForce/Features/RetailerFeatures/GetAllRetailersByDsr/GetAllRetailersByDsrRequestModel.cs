﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailersByDsr
{
    public class GetAllRetailersByDsrRequestModel:IRequest<GetAllRetailerByDsrResponseModel>
    {
        public int id { get; set; }
    }
}
