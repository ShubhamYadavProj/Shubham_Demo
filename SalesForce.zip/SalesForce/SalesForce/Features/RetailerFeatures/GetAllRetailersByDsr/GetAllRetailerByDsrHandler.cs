﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailersByDsr
{
    public class GetAllRetailerByDsrHandler:IRequestHandler<GetAllRetailersByDsrRequestModel, GetAllRetailerByDsrResponseModel>
    {
        private readonly IRepository<Retailer> _retailerrepository;
        private readonly IMapper _mapper;
        public GetAllRetailerByDsrHandler(IRepository<Retailer> retailerrepository, IMapper mapper)
        {
            _retailerrepository = retailerrepository;
            _mapper = mapper;
        }

        public Task<GetAllRetailerByDsrResponseModel> Handle(GetAllRetailersByDsrRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllRetailerByDsrResponseModel()
            {
                 rtailers= Retailer(request)
            });
        }

        private List<RetailerRepresentationModel> Retailer(GetAllRetailersByDsrRequestModel request)
        {
            return _retailerrepository.GetAllQuery().Where(s => s.dsr_id == request.id).ProjectTo<RetailerRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
