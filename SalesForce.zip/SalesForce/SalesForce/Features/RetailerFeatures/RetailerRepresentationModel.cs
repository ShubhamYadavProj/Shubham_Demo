﻿using Core.Entities;
using Core.Enum;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesForce.Features.RetailerFeatures
{
    public class RetailerRepresentationModel
    {

        public int retailer_id { get; set; }

        public string retailer_name { get; set; }

        public int beat_id { get; set; }

        public int city_id { get; set; }

        public int dsr_id { get; set; }

    }
}
