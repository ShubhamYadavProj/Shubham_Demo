﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.RetailerFeatures
{
    public class RetailerMapper:Profile
    {
        public RetailerMapper()
        {
            CreateMap<Retailer, RetailerRepresentationModel>()
                .ForMember(dest=>dest.retailer_id,opt=>opt.MapFrom(src=>src.retailer_id))
                .ForMember(dest=>dest.retailer_name,opt=>opt.MapFrom(src=>src.retailer_name))
                .ForMember(dest=>dest.beat_id,opt=>opt.MapFrom(src=>src.beat_id))
                .ForMember(dest=>dest.city_id,opt=>opt.MapFrom(src=>src.city_id));

            CreateMap<RetailerRepresentationModel, Retailer>()
               .ForMember(dest => dest.retailer_id, opt => opt.MapFrom(src => src.retailer_id))
               .ForMember(dest => dest.retailer_name, opt => opt.MapFrom(src => src.retailer_name))
               .ForMember(dest => dest.beat_id, opt => opt.MapFrom(src => src.beat_id))
               .ForMember(dest => dest.city_id, opt => opt.MapFrom(src => src.city_id));


        }
    }
}
