﻿namespace SalesForce.Features.RetailerFeatures.AddRetailer
{
    public class AddRetailerResponseModel
    {
        public RetailerRepresentationModel Retailer { get; set; }
    }
}
