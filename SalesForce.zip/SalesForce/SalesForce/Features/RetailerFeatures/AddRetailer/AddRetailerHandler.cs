﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.RetailerFeatures.AddRetailer
{
    public class AddRetailerHandler : IRequestHandler<AddRetailerRequestModel, AddRetailerResponseModel>
    {
        private readonly IRepository<Retailer> _retailerRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public AddRetailerHandler(IRepository<Retailer> retailerRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _retailerRepository = retailerRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddRetailerResponseModel> Handle(AddRetailerRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddRetailerResponseModel()
            {
                Retailer=AddRetailer(request)
            });
        }


        private RetailerRepresentationModel AddRetailer(AddRetailerRequestModel request)
        {
            var newRetailer=_mapper.Map<Retailer>(request.Retailer);

            newRetailer.status = Core.Enum.EntityStatus.Active;

            _retailerRepository.AddAsync(newRetailer).ConfigureAwait(false).GetAwaiter().GetResult();
            _unitOfWork.Commit();

            return _mapper.Map<RetailerRepresentationModel>(newRetailer);   

        }
    }
}
