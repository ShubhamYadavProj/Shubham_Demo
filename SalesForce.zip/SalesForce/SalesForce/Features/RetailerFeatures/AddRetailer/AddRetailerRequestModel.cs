﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.AddRetailer
{
    public class AddRetailerRequestModel:IRequest<AddRetailerResponseModel>
    {
        public RetailerRepresentationModel Retailer { get; set; }
    }
}
