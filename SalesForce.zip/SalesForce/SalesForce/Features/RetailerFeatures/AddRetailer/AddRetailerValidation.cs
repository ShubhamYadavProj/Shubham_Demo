﻿using FluentValidation;

namespace SalesForce.Features.RetailerFeatures.AddRetailer
{
    public class AddRetailerValidation:AbstractValidator<AddRetailerRequestModel>
    {

        public AddRetailerValidation()
        {
            RuleFor(req => req.Retailer.retailer_name)
             .NotNull()
             .WithMessage("Retailer Name can not be null!")
             .NotEmpty()
             .WithMessage("Retailer Name can not be empty!");

            RuleFor(req => req.Retailer.beat_id)
            .NotNull()
            .WithMessage(" BeatID can not be null!")
            .NotEmpty()
            .WithMessage("BeatID Name can not be empty!");


            RuleFor(req => req.Retailer.city_id)
           .NotNull()
           .WithMessage(" cityId can not be null!")
           .NotEmpty()
           .WithMessage("cityId Name can not be empty!");

        }
    }
}
