﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailerByBeatId
{
    public class GetAllRetailerBYBeatIdHandler:IRequestHandler<GetAllRetailerByBeatIdRequsetModel,GetAllRetailerByBeatIdResponseModel>
    {
        private readonly IRepository<Retailer> _retailerRepository;
        private readonly IMapper _mapper;
        public GetAllRetailerBYBeatIdHandler(IRepository<Retailer> retailerRepository, IMapper mapper)
        {
            _retailerRepository = retailerRepository;
            _mapper = mapper;
        }

        public Task<GetAllRetailerByBeatIdResponseModel> Handle(GetAllRetailerByBeatIdRequsetModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllRetailerByBeatIdResponseModel()
            {
               retailer=rtailer(request)
            });
        }

        private List<RetailerRepresentationModel> rtailer(GetAllRetailerByBeatIdRequsetModel request)
        {
            return _retailerRepository.GetAllQuery().Where(s=> s.beat_id==request.id).ProjectTo<RetailerRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
