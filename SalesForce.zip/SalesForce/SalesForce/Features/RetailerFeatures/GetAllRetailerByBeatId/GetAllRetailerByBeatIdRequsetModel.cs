﻿using MediatR;

namespace SalesForce.Features.RetailerFeatures.GetAllRetailerByBeatId
{
    public class GetAllRetailerByBeatIdRequsetModel:IRequest<GetAllRetailerByBeatIdResponseModel>
    {
        public int id { get; set; }
    }
}
