﻿namespace SalesForce.Features.RetailerFeatures.GetAllRetailerByBeatId
{
    public class GetAllRetailerByBeatIdResponseModel
    {
        public List <RetailerRepresentationModel> retailer { get; set; }
    }
}
