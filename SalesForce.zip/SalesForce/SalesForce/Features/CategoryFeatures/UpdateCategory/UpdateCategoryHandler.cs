﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.CategoryFeatures.UpdateCategory
{
    public class UpdateCategoryHandler : IRequestHandler<UpdateCategoryRequestModel, UpdateCategoryResponseModel>
    {
        private readonly IRepository<Category> _Categoryrepository;
        private readonly IMapper _Mapper;
        private readonly IUnitOfWork _UnitOfWork;


        public UpdateCategoryHandler(IRepository<Category> categoryrepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Categoryrepository = categoryrepository;
            _Mapper = mapper;
            _UnitOfWork = unitOfWork;
        }

        public Task<UpdateCategoryResponseModel> Handle(UpdateCategoryRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateCategoryResponseModel()
            {
                category = UpdateCategory(request)
            }); ;
        }

        private CategoryReprsentaionModel UpdateCategory(UpdateCategoryRequestModel request)
        {

            var currentCategory=_Categoryrepository.GetAllQuery().Where(s=>s.category_id==request.category.Category_Id).FirstOrDefault();

            if (currentCategory!=null)
            {
                currentCategory.category_name= request.category.Category_name;   

                _Categoryrepository.UpdateAsync(currentCategory).ConfigureAwait(false).GetAwaiter().GetResult();

                _UnitOfWork.Commit();

              
            }
            return request.category;
        }
    }
}
