﻿namespace SalesForce.Features.CategoryFeatures.UpdateCategory
{
    public class UpdateCategoryResponseModel
    {

        public CategoryReprsentaionModel category { get; set; }
    }
}
