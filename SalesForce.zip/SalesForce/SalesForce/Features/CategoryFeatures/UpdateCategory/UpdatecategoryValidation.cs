﻿using FluentValidation;

namespace SalesForce.Features.CategoryFeatures.UpdateCategory
{
    public class UpdatecategoryValidation:AbstractValidator<UpdateCategoryRequestModel>
    {
        public UpdatecategoryValidation()
        {
            RuleFor(req => req.category.Category_name)
             .NotNull()
             .WithMessage("Category Name can not be null!")
             .NotEmpty()
             .WithMessage("Category Name can not be empty!");

        }
    }
}
