﻿using MediatR;
using System.Security.Policy;

namespace SalesForce.Features.CategoryFeatures.UpdateCategory
{
    public class UpdateCategoryRequestModel:IRequest<UpdateCategoryResponseModel>
    {
        public CategoryReprsentaionModel category { get; set; }
    }
}
