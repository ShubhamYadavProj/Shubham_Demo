﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.CategoryFeatures
{
    public class CategoryMapper:Profile
    {
        public CategoryMapper()
        {
            CreateMap<Category,CategoryReprsentaionModel>()
                .ForMember(dest=>dest.Category_Id,opt=>opt.MapFrom(src=>src.category_id))
                .ForMember(dest=>dest.Category_name,opt=>opt.MapFrom(src=>src.category_name));


            CreateMap<CategoryReprsentaionModel, Category>()
                .ForMember(dest => dest.category_id, opt => opt.MapFrom(src => src.Category_Id))
                .ForMember(dest => dest.category_name, opt => opt.MapFrom(src => src.Category_name));

        }
    }
}
