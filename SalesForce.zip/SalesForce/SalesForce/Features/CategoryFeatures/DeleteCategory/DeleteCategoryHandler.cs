﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.CategoryFeatures.DeleteCategory
{
    public class DeleteCategoryHandler : IRequestHandler<DeleteCategoryRequestModel, DeleteCategoryResponseModel>
    {

       private readonly IRepository<Category> _categoryRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteCategoryHandler(IRepository<Category> categoryRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _categoryRepository = categoryRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteCategoryResponseModel> Handle(DeleteCategoryRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteCategoryResponseModel()
            {

                IsDelete = DeleteCategory(request)
            }); 
        }

        private bool DeleteCategory(DeleteCategoryRequestModel request)
        {
            var CurrentCategory=_categoryRepository.GetAllQuery().Where(s=>s.category_id==request.CategoryId).FirstOrDefault();

            if (CurrentCategory!=null)
            {
                CurrentCategory.status = Core.Enum.EntityStatus.Inactive;
                _categoryRepository.UpdateAsync(CurrentCategory).ConfigureAwait(false).GetAwaiter().GetResult();
               
            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
