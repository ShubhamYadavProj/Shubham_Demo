﻿namespace SalesForce.Features.CategoryFeatures.DeleteCategory
{
    public class DeleteCategoryResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
