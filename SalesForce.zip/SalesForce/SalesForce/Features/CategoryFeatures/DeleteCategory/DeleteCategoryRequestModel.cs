﻿using MediatR;

namespace SalesForce.Features.CategoryFeatures.DeleteCategory
{
    public class DeleteCategoryRequestModel:IRequest<DeleteCategoryResponseModel>
    {
       public int CategoryId { get; set; }
    }
}
