﻿namespace SalesForce.Features.CategoryFeatures.AddCategory
{
    public class AddCategoryResponseModel
    {
        public CategoryReprsentaionModel Category { get; set; }
    }
}
