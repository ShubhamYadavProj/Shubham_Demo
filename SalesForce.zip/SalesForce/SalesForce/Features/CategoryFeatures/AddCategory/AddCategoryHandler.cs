﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.CategoryFeatures.AddCategory
{
    public class AddCategoryHandler : IRequestHandler<AddCategoryRequestModel, AddCategoryResponseModel>
    {
        private readonly IMapper _mapper;
        private readonly IRepository<Category> _Categoryrepository;
        private readonly IUnitOfWork _unitOfWork;

        public AddCategoryHandler(IMapper mapper, IRepository<Category> categoryrepository, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _Categoryrepository = categoryrepository;
            _unitOfWork = unitOfWork;
        }

        public Task<AddCategoryResponseModel> Handle(AddCategoryRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddCategoryResponseModel()
            {
                Category = AddCategory(request)
            }); 
        }

        private CategoryReprsentaionModel AddCategory(AddCategoryRequestModel request)
        {
            var newCategory = _mapper.Map<Category>(request.Category);

            newCategory.status = Core.Enum.EntityStatus.Active;

            _Categoryrepository.AddAsync(newCategory).ConfigureAwait(false).GetAwaiter().GetResult();
            _unitOfWork.Commit();

            return _mapper.Map<CategoryReprsentaionModel>(newCategory); 
        }
    }
}
