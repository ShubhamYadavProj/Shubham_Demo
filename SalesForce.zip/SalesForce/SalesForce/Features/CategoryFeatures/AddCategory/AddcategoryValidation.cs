﻿using FluentValidation;

namespace SalesForce.Features.CategoryFeatures.AddCategory
{
    public class AddcategoryValidation:AbstractValidator<AddCategoryRequestModel>
    {
        public AddcategoryValidation()
        {
            RuleFor(req => req.Category.Category_name)
             .NotNull()
             .WithMessage("Category Name can not be null!")
             .NotEmpty()
             .WithMessage("Category Name can not be empty!");

        }
    }
}
