﻿using MediatR;

namespace SalesForce.Features.CategoryFeatures.AddCategory
{
    public class AddCategoryRequestModel:IRequest<AddCategoryResponseModel>
    {
        public CategoryReprsentaionModel Category { get; set; }
    }
}
