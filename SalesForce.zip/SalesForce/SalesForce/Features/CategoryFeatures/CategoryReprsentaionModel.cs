﻿namespace SalesForce.Features.CategoryFeatures
{
    public class CategoryReprsentaionModel
    {
        public int Category_Id { get; set; }

        public string Category_name { get; set; }


    }
}
