﻿namespace SalesForce.Features.CategoryFeatures.GetAllCategory
{
    public class GetAllCategoryResponseModel
    {
        public List<CategoryReprsentaionModel> category { get; set; }
    }
}
