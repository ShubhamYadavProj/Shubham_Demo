﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using System.Data.Entity;

namespace SalesForce.Features.CategoryFeatures.GetAllCategory
{
    public class GetAllCategoryHandler : IRequestHandler<GetAllCategoryRequestModel, GetAllCategoryResponseModel>
    {
        private readonly IRepository<Category> _categoryRepository;

        private readonly IMapper _mapper;

        public GetAllCategoryHandler(IRepository<Category> categoryRepository, IMapper mapper)
        {
            _categoryRepository = categoryRepository;
            _mapper = mapper;
        }

        public Task<GetAllCategoryResponseModel> Handle(GetAllCategoryRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllCategoryResponseModel()
            {
                category = GetAllCategory()
            }) ;
        }

        private List<CategoryReprsentaionModel> GetAllCategory()
        {

            return _categoryRepository.GetAllQuery()
                                      .Where(s=>s.status==Core.Enum.EntityStatus.Active)
                                      .AsNoTracking()
                                      .ProjectTo<CategoryReprsentaionModel>(_mapper.ConfigurationProvider)
                                      .ToList();
        }
    }
}
