﻿using MediatR;

namespace SalesForce.Features.CategoryFeatures.GetAllCategory
{
    public class GetAllCategoryRequestModel:IRequest<GetAllCategoryResponseModel>
    {
       
    }
}
