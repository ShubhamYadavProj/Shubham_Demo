﻿using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.GetAllOrder_details
{
    public class GetAllOrder_deatilsRequestModel:IRequest<GetAllOrder_detailsResponseModel>
    {

    }
}
