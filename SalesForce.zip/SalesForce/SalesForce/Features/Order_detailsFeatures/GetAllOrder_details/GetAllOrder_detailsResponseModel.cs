﻿namespace SalesForce.Features.Order_detailsFeatures.GetAllOrder_details
{
    public class GetAllOrder_detailsResponseModel
    {
        public List<Order_DetailsRepresentationModel> order_details { get; set; }
    }
}
