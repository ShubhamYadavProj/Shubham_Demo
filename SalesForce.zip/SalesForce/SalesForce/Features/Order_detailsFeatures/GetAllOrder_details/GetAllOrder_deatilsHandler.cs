﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.GetAllOrder_details
{
    public class GetAllOrder_deatilsHandler : IRequestHandler<GetAllOrder_deatilsRequestModel, GetAllOrder_detailsResponseModel>
    {
        private readonly IRepository<Order_deatils> _order_detailsRepository;
        private readonly IMapper _mapper;

        public GetAllOrder_deatilsHandler(IRepository<Order_deatils> order_detailsRepository, IMapper mapper)
        {
            _order_detailsRepository = order_detailsRepository;
            _mapper = mapper;
        }

        public Task<GetAllOrder_detailsResponseModel> Handle(GetAllOrder_deatilsRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllOrder_detailsResponseModel()
            {
                order_details = GetAllOrder_details()
            }) ;
        }

        private List<Order_DetailsRepresentationModel> GetAllOrder_details()
        {
            return _order_detailsRepository.GetAllQuery().Where(s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<Order_DetailsRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
