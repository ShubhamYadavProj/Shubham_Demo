﻿using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.DeleteOrder_details
{
    public class DeleteOrder_detailRequestModel:IRequest<DeleteOrder_detailResponseModel>
    {
        public int order_detailsId { get; set; }    
    }
}
