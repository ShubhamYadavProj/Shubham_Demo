﻿namespace SalesForce.Features.Order_detailsFeatures.DeleteOrder_details
{
    public class DeleteOrder_detailResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
