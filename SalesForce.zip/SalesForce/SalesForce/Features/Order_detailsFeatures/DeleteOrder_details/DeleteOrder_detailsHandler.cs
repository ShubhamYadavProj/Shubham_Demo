﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.DeleteOrder_details
{
    public class DeleteOrder_detailsHandler : IRequestHandler<DeleteOrder_detailRequestModel, DeleteOrder_detailResponseModel>
    {
        private readonly IRepository<Order_deatils> _order_detailsRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public DeleteOrder_detailsHandler(IRepository<Order_deatils> order_detailsRepository, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _order_detailsRepository = order_detailsRepository;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        public Task<DeleteOrder_detailResponseModel> Handle(DeleteOrder_detailRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteOrder_detailResponseModel()
            {
                IsDelete = DeleteOrder_details(request)
            });
        }

        private bool DeleteOrder_details (DeleteOrder_detailRequestModel request)
        {
            var currentData = _order_detailsRepository.GetAllQuery().Where(s => s.order_deatils_id == request.order_detailsId).FirstOrDefault();

            if (currentData != null)
            {
                currentData.status = Core.Enum.EntityStatus.Inactive;

                _order_detailsRepository.UpdateAsync(currentData).ConfigureAwait(false).GetAwaiter().GetResult();

            }

           

            return _unitOfWork.Commit() > 0;
        }
    }
}
