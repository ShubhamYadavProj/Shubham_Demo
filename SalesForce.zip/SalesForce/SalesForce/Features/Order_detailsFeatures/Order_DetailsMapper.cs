﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.Order_detailsFeatures
{
    public class Order_detailsMapper:Profile
    {

        public Order_detailsMapper()
        {
            CreateMap<Order_deatils,Order_DetailsRepresentationModel>()
                .ForMember(dest=>dest.order_deatils_id,opt=>opt.MapFrom(src=>src.order_deatils_id))
                .ForMember(dest => dest.quantity, opt => opt.MapFrom(src => src.quantity))
                .ForMember(dest => dest.order_date, opt => opt.MapFrom(src => src.order_date))
                .ForMember(dest => dest.order_id, opt => opt.MapFrom(src => src.order_id))
                .ForMember(dest => dest.sku_id, opt => opt.MapFrom(src => src.sku_id));

            CreateMap< Order_DetailsRepresentationModel, Order_deatils>()
              .ForMember(dest => dest.order_deatils_id, opt => opt.MapFrom(src => src.order_deatils_id))
              .ForMember(dest => dest.quantity, opt => opt.MapFrom(src => src.quantity))
              .ForMember(dest => dest.order_date, opt => opt.MapFrom(src => src.order_date))
              .ForMember(dest => dest.order_id, opt => opt.MapFrom(src => src.order_id))
              .ForMember(dest => dest.sku_id, opt => opt.MapFrom(src => src.sku_id));
        }
    }
}
