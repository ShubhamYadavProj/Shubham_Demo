﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.UpdateOrder_details
{
    public class UpdateOrder_detailsHandler : IRequestHandler<UpdateOrder_DetailsRequestModel, UpdateOrder_detailsResponseModel>
    {
        private readonly IRepository<Order_deatils> _order_detailsRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public UpdateOrder_detailsHandler(IRepository<Order_deatils> order_detailsRepository, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _order_detailsRepository = order_detailsRepository;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public Task<UpdateOrder_detailsResponseModel> Handle(UpdateOrder_DetailsRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateOrder_detailsResponseModel()
            {
                order_detail = UpdateOrder_details(request)
            });

        }

        private Order_DetailsRepresentationModel UpdateOrder_details (UpdateOrder_DetailsRequestModel request)
        {
            var currentOrder_deatils=_order_detailsRepository.GetAllQuery().Where(s=>s.order_deatils_id==request.order_detail.order_deatils_id).FirstOrDefault();   

            if(currentOrder_deatils!=null)
            {
                currentOrder_deatils.quantity = request.order_detail.quantity;
                currentOrder_deatils.sku_id=request.order_detail.sku_id;
                currentOrder_deatils.order_id=request.order_detail.order_id;
                currentOrder_deatils.order_date=request.order_detail.order_date;

                _order_detailsRepository.UpdateAsync(currentOrder_deatils).ConfigureAwait(false).GetAwaiter().GetResult();

                _unitOfWork.Commit();
            }

            return request.order_detail;
        }
    }
}
