﻿using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.UpdateOrder_details
{
    public class UpdateOrder_DetailsRequestModel:IRequest<UpdateOrder_detailsResponseModel>
    {
        public Order_DetailsRepresentationModel order_detail { get; set; }
    }
}
