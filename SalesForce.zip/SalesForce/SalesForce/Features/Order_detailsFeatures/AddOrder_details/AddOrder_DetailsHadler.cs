﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.AddOrder_details
{
    public class AddOrder_DetailsHadler : IRequestHandler<AddOrder_DetailsRequestModel, AddOrder_DetailsResponseModel>
    {

        private readonly IRepository<Order_deatils> _order_detailsRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public AddOrder_DetailsHadler(IRepository<Order_deatils> order_detailsRepository, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _order_detailsRepository = order_detailsRepository;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public Task<AddOrder_DetailsResponseModel> Handle(AddOrder_DetailsRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddOrder_DetailsResponseModel()
            {
                order_details = AddOrder_details(request)
            });
        }

        private Order_DetailsRepresentationModel AddOrder_details(AddOrder_DetailsRequestModel request)
        {
            var newOrder_deatils = _mapper.Map<Order_deatils>(request.order_details);

            newOrder_deatils.status = Core.Enum.EntityStatus.Active;
            
            _order_detailsRepository.AddAsync(newOrder_deatils).ConfigureAwait(false).GetAwaiter().GetResult();

            _unitOfWork.Commit();

            return _mapper.Map<Order_DetailsRepresentationModel>(newOrder_deatils);    
        }
    }
}
