﻿using MediatR;

namespace SalesForce.Features.Order_detailsFeatures.AddOrder_details
{
    public class AddOrder_DetailsRequestModel:IRequest<AddOrder_DetailsResponseModel>
    {
        public Order_DetailsRepresentationModel order_details { get; set; }
    }
}
