﻿using Core.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SalesForce.Features.Order_detailsFeatures
{
    public class Order_DetailsRepresentationModel
    {

        public int order_deatils_id { get; set; }

        public int quantity { get; set; }

        public DateTime order_date { get; set; }

        public int order_id { get; set; }

       
        public int sku_id { get; set; }

    }
}
