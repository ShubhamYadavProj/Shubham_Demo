﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using SalesForce.Features.CategoryFeatures;

namespace SalesForce.Features.Dsr_beat_map.AddDsr_beat_map
{
    public class AddDsr_beat_mapHandler:IRequestHandler<AddDsr_beat_mapRequestModel,AddDsr_beat_mapResopnseModel>
    {
        private readonly IRepository<Dsr_Beat_Map> dsr_repository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public AddDsr_beat_mapHandler(IRepository<Dsr_Beat_Map> dsr_repository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            this.dsr_repository = dsr_repository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddDsr_beat_mapResopnseModel> Handle(AddDsr_beat_mapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddDsr_beat_mapResopnseModel()
            {
                dbm= Dsr_beat_map(request)
            });
        }

        private Dsr_beat_mapReparationalModel Dsr_beat_map(AddDsr_beat_mapRequestModel request)
        {
           var newdsm=_mapper.Map<Dsr_Beat_Map>(request.dbm);
            newdsm.status = Core.Enum.EntityStatus.Active;
            dsr_repository.AddAsync(newdsm).ConfigureAwait(false).GetAwaiter().GetResult();
            _unitOfWork.Commit();

            return _mapper.Map<Dsr_beat_mapReparationalModel>(newdsm);
        }
    }
}
