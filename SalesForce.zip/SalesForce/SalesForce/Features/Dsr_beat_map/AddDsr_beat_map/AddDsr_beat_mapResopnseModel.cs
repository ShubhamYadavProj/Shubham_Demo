﻿namespace SalesForce.Features.Dsr_beat_map.AddDsr_beat_map
{
    public class AddDsr_beat_mapResopnseModel
    {
        public Dsr_beat_mapReparationalModel dbm {  get; set; }
    }
}
