﻿using Core.Base;

namespace SalesForce.Features.Dsr_beat_map
{
    public class Dsr_beat_mapReparationalModel
    {
        public int id { get; set; }
        public int beat_id { get; set; }
        public int employee_id { get; set; }
    }
}
