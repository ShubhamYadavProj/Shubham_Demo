﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.Dsr_beat_map
{
    public class Dsr_beat_mapMapper:Profile
    {
        public Dsr_beat_mapMapper() 
        {
            CreateMap<Dsr_Beat_Map, Dsr_beat_mapReparationalModel>()
                .ForMember(des => des.id, opt => opt.MapFrom(src => src.dsr_id))
                .ForMember(des => des.employee_id, opt => opt.MapFrom(src => src.employee_id))
                .ForMember(des => des.beat_id, opt => opt.MapFrom(src => src.beat_id));

            CreateMap<Dsr_beat_mapReparationalModel,Dsr_Beat_Map>()
                .ForMember(des => des.dsr_id, opt => opt.MapFrom(src => src.id))
                .ForMember(des => des.employee_id, opt => opt.MapFrom(src => src.employee_id))
                .ForMember(des => des.beat_id, opt => opt.MapFrom(src => src.beat_id));

        }
    }
}
