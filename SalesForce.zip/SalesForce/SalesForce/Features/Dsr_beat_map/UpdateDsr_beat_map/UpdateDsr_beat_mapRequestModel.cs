﻿using MediatR;
using SalesForce.Features.EmployeeFeatures.GetEmployeeById;

namespace SalesForce.Features.Dsr_beat_map.UpdateDsr_beat_map
{
    public class UpdateDsr_beat_mapRequestModel:IRequest<UpdateDsr_beat_mapResonseModel>
    {
        public Dsr_beat_mapReparationalModel model { get; set; }
    }
}
