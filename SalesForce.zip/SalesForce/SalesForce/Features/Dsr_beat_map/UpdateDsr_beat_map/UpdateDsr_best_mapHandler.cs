﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Dsr_beat_map.UpdateDsr_beat_map
{
    public class UpdateDsr_best_mapHandler:IRequestHandler<UpdateDsr_beat_mapRequestModel,UpdateDsr_beat_mapResonseModel>
    { 
        private readonly IMapper _mapper;
        private readonly IRepository<Dsr_Beat_Map> _Dsrrepository;
        private readonly IUnitOfWork _unitOfWork;

        public Task<UpdateDsr_beat_mapResonseModel> Handle(UpdateDsr_beat_mapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateDsr_beat_mapResonseModel()
            {
                model=DsrModel(request)
            });
        }

        private Dsr_beat_mapReparationalModel DsrModel(UpdateDsr_beat_mapRequestModel request)
        {
            var currentdsm = _Dsrrepository.GetAllQuery().Where(m => m.dsr_id == request.model.id).FirstOrDefault();
            if (currentdsm != null)
            {
                currentdsm.employee_id = request.model.employee_id;
                currentdsm.beat_id=request.model.beat_id;

                _Dsrrepository.UpdateAsync(currentdsm).ConfigureAwait(false).GetAwaiter().GetResult();

                _unitOfWork.Commit();


            }
            return request.model;
        }
    }
}
