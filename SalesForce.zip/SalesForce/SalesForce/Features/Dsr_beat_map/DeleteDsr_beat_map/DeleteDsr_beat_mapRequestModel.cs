﻿using MediatR;

namespace SalesForce.Features.Dsr_beat_map.DeleteDsr_beat_map
{
    public class DeleteDsr_beat_mapRequestModel:IRequest<DeleteDsr_beat_mapResponseModel>
    {
        public int id { get; set; }
    }
}
