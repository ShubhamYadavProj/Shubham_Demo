﻿namespace SalesForce.Features.Dsr_beat_map.DeleteDsr_beat_map
{
    public class DeleteDsr_beat_mapResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
