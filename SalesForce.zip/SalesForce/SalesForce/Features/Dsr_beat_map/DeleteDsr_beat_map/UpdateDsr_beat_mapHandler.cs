﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.Dsr_beat_map.DeleteDsr_beat_map
{
    public class UpdateDsr_beat_mapHandler:IRequestHandler<DeleteDsr_beat_mapRequestModel,DeleteDsr_beat_mapResponseModel>
    {
        private readonly IRepository<Dsr_Beat_Map> _Dsrrepository;
        private readonly IMapper mapper;
        private readonly IUnitOfWork unitOfWork;

        public UpdateDsr_beat_mapHandler(IRepository<Dsr_Beat_Map> dsrrepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Dsrrepository = dsrrepository;
            this.mapper = mapper;
            this.unitOfWork = unitOfWork;
        }

        public Task<DeleteDsr_beat_mapResponseModel> Handle(DeleteDsr_beat_mapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteDsr_beat_mapResponseModel()
            {
                IsDelete= DeleteDsr(request)
            });
        }

        private bool DeleteDsr(DeleteDsr_beat_mapRequestModel request)
        {
            var currentdsr = _Dsrrepository.GetAllQuery().Where(m => m.dsr_id == request.id).FirstOrDefault();
            if (currentdsr != null)
            {
                currentdsr.status = Core.Enum.EntityStatus.Inactive;
                _Dsrrepository.UpdateAsync(currentdsr).ConfigureAwait(false).GetAwaiter().GetResult();

            }

            return unitOfWork.Commit() > 0;
        }
    }
}
