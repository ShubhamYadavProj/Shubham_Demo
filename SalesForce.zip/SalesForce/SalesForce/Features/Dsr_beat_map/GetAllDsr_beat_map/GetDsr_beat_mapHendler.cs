﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using SalesForce.Features.EmployeebeatmapFeatures;
using SalesForce.Features.EmployeeFeatures;
using SalesForce.Features.RetailerFeatures;
using System.Data.Entity;

namespace SalesForce.Features.Dsr_beat_map.GetDsr_beat_map
{
    public class GetDsr_beat_mapHendler:IRequestHandler<GetDsr_beat_mapRequestModel,GetDsr_beat_mapResponseModel>
    {
        private readonly IRepository<Dsr_Beat_Map> _Dsr_beat_maprepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public GetDsr_beat_mapHendler(IRepository<Dsr_Beat_Map> dsr_beat_maprepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _Dsr_beat_maprepository = dsr_beat_maprepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<GetDsr_beat_mapResponseModel> Handle(GetDsr_beat_mapRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetDsr_beat_mapResponseModel()
            {
                 dsr_Beat_Maps=Dsr_beat_map(request)

            });
        }

        private List<Dsr_beat_mapReparationalModel> Dsr_beat_map(GetDsr_beat_mapRequestModel request)
        {
            return _Dsr_beat_maprepository.GetAllQuery().
                Where(s=> s.status==Core.Enum.EntityStatus.Active)
                .AsNoTracking()
                .ProjectTo<Dsr_beat_mapReparationalModel>(_mapper.ConfigurationProvider)
                .ToList();
        }
    }
    }

