﻿namespace SalesForce.Features.Dsr_beat_map.GetDsr_beat_map
{
    public class GetDsr_beat_mapResponseModel
    {
        public List<Dsr_beat_mapReparationalModel> dsr_Beat_Maps { get; set; }
    }
}
