﻿using MediatR;

namespace SalesForce.Features.Dsr_beat_map.GetDsr_beat_map
{
    public class GetDsr_beat_mapRequestModel:IRequest<GetDsr_beat_mapResponseModel>
    {
      
    }
}
