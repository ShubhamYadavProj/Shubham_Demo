﻿namespace SalesForce.Features.BeatFeatures
{
    public class BeatRepresentationModel
    {
        public int Beat_id { get; set; }

        public string Beat_name { get; set; }
    }
}
