﻿namespace SalesForce.Features.BeatFeatures.AddBeat
{
    public class AddBeatResponseModel
    {
        public BeatRepresentationModel Beat { get; set; }
    }
}
