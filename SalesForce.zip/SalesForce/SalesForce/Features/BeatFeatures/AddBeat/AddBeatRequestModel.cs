﻿using MediatR;

namespace SalesForce.Features.BeatFeatures.AddBeat
{
    public class AddBeatRequestModel:IRequest<AddBeatResponseModel>
    {
        public BeatRepresentationModel Beat { get; set; }
    }
}
