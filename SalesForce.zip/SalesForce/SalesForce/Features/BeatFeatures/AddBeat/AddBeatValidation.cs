﻿using FluentValidation;

namespace SalesForce.Features.BeatFeatures.AddBeat
{
    public class AddBeatValidation:AbstractValidator<AddBeatRequestModel>
    {

        public AddBeatValidation()
        {
            RuleFor(req => req.Beat.Beat_name)
             .NotNull()
             .WithMessage("Beat name can not be null!")
             .NotEmpty()
             .WithMessage("Beat name can not be empty!");

        }
    }
}
