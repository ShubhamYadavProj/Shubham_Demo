﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.BeatFeatures.AddBeat
{
    public class AddBeatHandler : IRequestHandler<AddBeatRequestModel, AddBeatResponseModel>
    {
        private readonly IRepository<Beat> _beatRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public AddBeatHandler(IRepository<Beat> beatRepository, IUnitOfWork unitOfWork, IMapper mapper)
        {
            this._beatRepository = beatRepository;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public Task<AddBeatResponseModel> Handle(AddBeatRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddBeatResponseModel()
            {
                Beat = AddBeat(request)
            });
        }

        private BeatRepresentationModel AddBeat(AddBeatRequestModel request)
        {
            var newBeat = _mapper.Map<Beat>(request.Beat);

            newBeat.status = Core.Enum.EntityStatus.Active;

            _beatRepository.AddAsync(newBeat).ConfigureAwait(false).GetAwaiter().GetResult();
            _unitOfWork.Commit();

            return _mapper.Map<BeatRepresentationModel>(newBeat);
        }
    }
}
