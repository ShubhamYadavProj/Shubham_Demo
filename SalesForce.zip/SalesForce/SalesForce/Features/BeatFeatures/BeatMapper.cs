﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.BeatFeatures
{
    public class BeatMapper:Profile
    {
        public BeatMapper()
        {
            CreateMap<Beat,BeatRepresentationModel>()
                .ForMember(dest=>dest.Beat_id,opt=>opt.MapFrom(src=>src.beat_id))
                 .ForMember(dest => dest.Beat_name, opt => opt.MapFrom(src => src.beat_name));


            CreateMap<BeatRepresentationModel, Beat>()
               .ForMember(dest => dest.beat_id, opt => opt.MapFrom(src => src.Beat_id))
                .ForMember(dest => dest.beat_name, opt => opt.MapFrom(src => src.Beat_name)); ;
        }
    }
}
