﻿namespace SalesForce.Features.BeatFeatures.DeleteBeat
{
    public class DeleteBeatResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
