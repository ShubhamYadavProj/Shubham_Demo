﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.BeatFeatures.DeleteBeat
{
    public class DeletebeatHandler : IRequestHandler<DeleteBeatRequestModel, DeleteBeatResponseModel>
    {
        private readonly IRepository<Beat> _beatRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeletebeatHandler(IRepository<Beat> beatRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _beatRepository = beatRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteBeatResponseModel> Handle(DeleteBeatRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteBeatResponseModel()
            {
                IsDelete = DeleteBeat(request)
            });
        }

        private bool DeleteBeat(DeleteBeatRequestModel request)
        {
            var CurrentBeat = _beatRepository.GetAllQuery().Where(s => s.beat_id == request.BeatID).FirstOrDefault();

            if (CurrentBeat != null)
            {
                CurrentBeat.status = Core.Enum.EntityStatus.Inactive;
                _beatRepository.UpdateAsync(CurrentBeat).ConfigureAwait(false).GetAwaiter().GetResult();
                
            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
