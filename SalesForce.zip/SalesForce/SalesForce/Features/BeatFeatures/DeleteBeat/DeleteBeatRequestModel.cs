﻿using MediatR;

namespace SalesForce.Features.BeatFeatures.DeleteBeat
{
    public class DeleteBeatRequestModel:IRequest<DeleteBeatResponseModel>
    {
        public int BeatID { get; set; }
    }
}
