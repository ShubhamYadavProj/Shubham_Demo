﻿using MediatR;

namespace SalesForce.Features.BeatFeatures.UpdateBeat
{
    public class UpdateBeatRequestModel:IRequest<UpdateBeatResponseModel>
    {
        public BeatRepresentationModel Beat { get; set; }
    }
}
