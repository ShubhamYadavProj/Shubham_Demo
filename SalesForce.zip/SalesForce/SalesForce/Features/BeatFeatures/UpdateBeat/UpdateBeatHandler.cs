﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.BeatFeatures.UpdateBeat
{
    public class UpdateBeatHandler : IRequestHandler<UpdateBeatRequestModel, UpdateBeatResponseModel>
    {
        private readonly IRepository<Beat> _beatRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateBeatHandler(IRepository<Beat> beatRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _beatRepository = beatRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<UpdateBeatResponseModel> Handle(UpdateBeatRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateBeatResponseModel()
            {
                Beat = UpdateBeat(request)
            });

        }

        private BeatRepresentationModel UpdateBeat(UpdateBeatRequestModel request)
        {
            var currentBeat=_beatRepository.GetAllQuery().Where(s=>s.beat_id==request.Beat.Beat_id).FirstOrDefault();

            if (currentBeat!=null)
            {
                currentBeat.beat_name = request.Beat.Beat_name;
                _beatRepository.UpdateAsync(currentBeat).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
            }

            return request.Beat;   
        }
    }
}
