﻿namespace SalesForce.Features.BeatFeatures.UpdateBeat
{
    public class UpdateBeatResponseModel
    {
        public BeatRepresentationModel Beat { get; set; }
    }
}
