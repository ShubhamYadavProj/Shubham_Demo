﻿using FluentValidation;

namespace SalesForce.Features.BeatFeatures.UpdateBeat
{
    public class UpdateValidation:AbstractValidator<UpdateBeatRequestModel>
    {
        public UpdateValidation()
        {
            RuleFor(req => req.Beat.Beat_name)
             .NotNull()
             .WithMessage("Beat name can not be null!")
             .NotEmpty()
             .WithMessage("Beat name can not be empty!");

        }
    }
}
