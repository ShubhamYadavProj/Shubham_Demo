﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.BeatFeatures.GetAllBeat
{
    public class GetAllBeatHandler : IRequestHandler<GetAllBeatRequestModel, GetAllBeatResponseModel>
    {
        private readonly IRepository<Beat> _Beatrepository;
        private readonly IMapper _mapper;

        public GetAllBeatHandler(IRepository<Beat> Beatrepository,IMapper mapper)
        {
            _Beatrepository= Beatrepository;
            _mapper=mapper;
        }

        public Task<GetAllBeatResponseModel> Handle(GetAllBeatRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllBeatResponseModel()
            {
                Beat = GetAllBeat()
            }) ;
        }

        private List<BeatRepresentationModel> GetAllBeat()
        {
            return _Beatrepository.GetAllQuery()
                                  .Where(s=>s.status==Core.Enum.EntityStatus.Active)
                                  .ProjectTo<BeatRepresentationModel>(_mapper.ConfigurationProvider)
                                  .ToList();
        }
    }
}
