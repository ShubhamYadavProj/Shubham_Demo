﻿using MediatR;

namespace SalesForce.Features.BeatFeatures.GetAllBeat
{
    public class GetAllBeatRequestModel:IRequest<GetAllBeatResponseModel>
    {

    }
}
