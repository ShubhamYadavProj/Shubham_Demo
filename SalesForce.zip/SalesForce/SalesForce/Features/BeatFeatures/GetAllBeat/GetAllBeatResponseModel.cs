﻿namespace SalesForce.Features.BeatFeatures.GetAllBeat
{
    public class GetAllBeatResponseModel
    {
        public List<BeatRepresentationModel> Beat { get; set; }
    }
}
