﻿namespace SalesForce.Features.UnitofworkFeatures
{
    public class UnitofmeasurmentRepresentationModel
    {

        public int uom_id { get; set; }

        public string uom_name { get; set; }

  //    public EntityStatus status { get; set; }

    }
}
