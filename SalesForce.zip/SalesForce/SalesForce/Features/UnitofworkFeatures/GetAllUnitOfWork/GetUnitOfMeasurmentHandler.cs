﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using SalesForce.Features.EmployeeFeatures;

namespace SalesForce.Features.UnitofworkFeatures.GetAllUnitOfWork
{
    public class GetUnitOfMeasurmentHandler : IRequestHandler<GetAllUnitOfMeasurmentRequestModel, GetAllUnitOfMeasurmentResponseModel>
    {

        private readonly IRepository<UnitOfMeasurment> _uowRepository;
        private readonly IMapper _mapper;

        public GetUnitOfMeasurmentHandler(IRepository<UnitOfMeasurment> repository,IMapper mapper)
        {
            _mapper= mapper;
            _uowRepository= repository;
        }
       
        public Task<GetAllUnitOfMeasurmentResponseModel> Handle(GetAllUnitOfMeasurmentRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllUnitOfMeasurmentResponseModel()
            {
                Unitofworks = GetAllUnitOfWork()
            }) ;
        }

        private List<UnitofmeasurmentRepresentationModel> GetAllUnitOfWork()
        {

            return _uowRepository.GetAllQuery().Where(s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<UnitofmeasurmentRepresentationModel>(_mapper.ConfigurationProvider).ToList();

            
        }
    }
}
