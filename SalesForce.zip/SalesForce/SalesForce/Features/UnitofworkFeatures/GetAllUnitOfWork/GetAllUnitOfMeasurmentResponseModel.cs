﻿namespace SalesForce.Features.UnitofworkFeatures.GetAllUnitOfWork
{
    public class GetAllUnitOfMeasurmentResponseModel
    {
        public List<UnitofmeasurmentRepresentationModel> Unitofworks { get; set; }
    }
}
