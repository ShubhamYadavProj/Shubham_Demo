﻿using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.GetAllUnitOfWork
{
    public class GetAllUnitOfMeasurmentRequestModel:IRequest<GetAllUnitOfMeasurmentResponseModel>
    {


    }
}
