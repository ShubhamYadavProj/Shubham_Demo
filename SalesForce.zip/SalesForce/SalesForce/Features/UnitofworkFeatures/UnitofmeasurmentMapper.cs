﻿using AutoMapper;
using Core.Entities;
using SalesForce.Features.EmployeeFeatures;

namespace SalesForce.Features.UnitofworkFeatures
{
    public class UnitofmeasurmentMapper:Profile
    {
        public UnitofmeasurmentMapper()
        {

            CreateMap<UnitOfMeasurment, UnitofmeasurmentRepresentationModel>()
                .ForMember(dest => dest.uom_id, opt => opt.MapFrom(src => src.unit_of_measurment_id))
                .ForMember(dest => dest.uom_name, opt => opt.MapFrom(src => src.name));
        //     .ForMember(dest => dest.status, opt => opt.Ignore());
                 


            CreateMap<UnitofmeasurmentRepresentationModel, UnitOfMeasurment>()
               .ForMember(dest => dest.unit_of_measurment_id, opt => opt.MapFrom(src => src.uom_id))
               .ForMember(dest => dest.name, opt => opt.MapFrom(src => src.uom_name))
             .ForMember(dest => dest.status, opt => opt.Ignore());
              


        }
    }
}
