﻿using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.AddUnitOfMesurment
{
    public class AddUnitOfMesurmentRequestModel:IRequest<AddUnitOfMeasurmentResponseModel>
    {

        public UnitofmeasurmentRepresentationModel uom { get; set; }

    }
}
