﻿namespace SalesForce.Features.UnitofworkFeatures.AddUnitOfMesurment
{
    public class AddUnitOfMeasurmentResponseModel
    {
        public UnitofmeasurmentRepresentationModel uom { get; set; }

    }
}
