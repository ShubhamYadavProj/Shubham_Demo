﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.AddUnitOfMesurment
{
    public class AddUnitOfMeasurmentHandler : IRequestHandler<AddUnitOfMesurmentRequestModel,AddUnitOfMeasurmentResponseModel>
    {

        private readonly IRepository<UnitOfMeasurment> _uomRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public AddUnitOfMeasurmentHandler(IRepository<UnitOfMeasurment> uomRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _uomRepository = uomRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddUnitOfMeasurmentResponseModel> Handle(AddUnitOfMesurmentRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddUnitOfMeasurmentResponseModel()
            {
                uom= AddUnitOfMesurment(request)
            });
        }

        private UnitofmeasurmentRepresentationModel AddUnitOfMesurment( AddUnitOfMesurmentRequestModel request)
        {
            var newUOM= _mapper.Map<UnitOfMeasurment>(request.uom);

            newUOM.status = Core.Enum.EntityStatus.Active;

            _uomRepository.AddAsync(newUOM).ConfigureAwait(false).GetAwaiter().GetResult(); 

            _unitOfWork.Commit();

            return _mapper.Map<UnitofmeasurmentRepresentationModel>(newUOM);
        }
    }
}
