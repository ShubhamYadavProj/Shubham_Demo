﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.DeleteUnitOfWork
{
    public class DeleteUnitOfWorkHandler : IRequestHandler<DeleteUnitOfWorkRequestModel, DeleteUnitOfWorkResponseModel>
    {
        private readonly IRepository<UnitOfMeasurment> _unitOfMeasurmentRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteUnitOfWorkHandler (IRepository<UnitOfMeasurment> unitOfMeasurmentRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _unitOfMeasurmentRepository = unitOfMeasurmentRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteUnitOfWorkResponseModel> Handle(DeleteUnitOfWorkRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteUnitOfWorkResponseModel()
            {
                IsDel = DeleteUnitOfWork(request)
            });
        }

        private bool DeleteUnitOfWork(DeleteUnitOfWorkRequestModel request)
        {
            var currentUoM = _unitOfMeasurmentRepository.GetAllQuery().Where(s => s.unit_of_measurment_id == request.UnitOfWorkId).FirstOrDefault();

            if (currentUoM != null)
            {
                currentUoM.status = Core.Enum.EntityStatus.Inactive;
                _unitOfMeasurmentRepository.UpdateAsync(currentUoM).ConfigureAwait(false).GetAwaiter().GetResult();

                
            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
