﻿namespace SalesForce.Features.UnitofworkFeatures.DeleteUnitOfWork
{
    public class DeleteUnitOfWorkResponseModel
    {
        public bool IsDel { get; set; }
    }
}
