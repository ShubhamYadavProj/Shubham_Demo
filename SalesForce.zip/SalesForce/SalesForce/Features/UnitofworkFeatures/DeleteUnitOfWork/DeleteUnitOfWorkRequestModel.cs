﻿using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.DeleteUnitOfWork
{
    public class DeleteUnitOfWorkRequestModel:IRequest<DeleteUnitOfWorkResponseModel>
    {
        public int UnitOfWorkId { get; set; } 
    }
}
