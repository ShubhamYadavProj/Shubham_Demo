﻿namespace SalesForce.Features.UnitofworkFeatures.UpdateUnitOfMeasurment
{
    public class UpdateUnitOfWorkResponseModel
    {
        public UnitofmeasurmentRepresentationModel uom { get; set; }
    }
}
