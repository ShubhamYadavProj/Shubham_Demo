﻿using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.UpdateUnitOfMeasurment
{
    public class UpdateUnitOfWorkRequestModel:IRequest<UpdateUnitOfWorkResponseModel>
    {
        public UnitofmeasurmentRepresentationModel uom { get; set; }
    }
}
