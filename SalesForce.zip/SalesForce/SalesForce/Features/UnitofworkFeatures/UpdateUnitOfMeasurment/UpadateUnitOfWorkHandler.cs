﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.UnitofworkFeatures.UpdateUnitOfMeasurment
{
    public class UpadateUnitOfWorkHandler : IRequestHandler<UpdateUnitOfWorkRequestModel, UpdateUnitOfWorkResponseModel>
    {

        private readonly IRepository<UnitOfMeasurment> _uomRepository;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        public UpadateUnitOfWorkHandler(IRepository<UnitOfMeasurment> uomRepository, IUnitOfWork unitOfWork, IMapper mapper)
        {
            _uomRepository = uomRepository;
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public Task<UpdateUnitOfWorkResponseModel> Handle(UpdateUnitOfWorkRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateUnitOfWorkResponseModel()
            {
                uom = UpdateUnitOfMeasurment(request)
            });
        }

        private UnitofmeasurmentRepresentationModel UpdateUnitOfMeasurment(UpdateUnitOfWorkRequestModel request)
        {
            var currentUOM=_uomRepository.GetAllQuery().Where(s=>s.unit_of_measurment_id==request.uom.uom_id).FirstOrDefault();

            if (currentUOM!=null)
            {
                currentUOM.name = request.uom.uom_name;
                _uomRepository.UpdateAsync(currentUOM).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
            }

            return _mapper.Map<UnitofmeasurmentRepresentationModel>(request.uom);

        }
    }
}
