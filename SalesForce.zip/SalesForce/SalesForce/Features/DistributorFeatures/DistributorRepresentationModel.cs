﻿namespace SalesForce.Features.DistributorFeatures
{
    public class DistributorRepresentationModel
    {

        public int distributor_id { get; set; }

        public string distributor_name { get; set;}


        public int city_id { get; set; }

        public int manager_id { get; set; }
    }
}
