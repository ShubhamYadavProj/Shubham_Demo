﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.DistributorFeatures
{
    public class DistributorMapper:Profile
    {
        public DistributorMapper()
        {
            CreateMap<Distributor,DistributorRepresentationModel>()
                .ForMember(dest=>dest.distributor_id,opt=>opt.MapFrom(src=>src.distributor_id))
                .ForMember(dest => dest.distributor_name, opt => opt.MapFrom(src => src.distributor_name))
                .ForMember(dest => dest.city_id, opt => opt.MapFrom(src => src.city_id))
                .ForMember(dest => dest.manager_id, opt => opt.MapFrom(src => src.manager_id));


            CreateMap<DistributorRepresentationModel,Distributor>()
              .ForMember(dest => dest.distributor_id, opt => opt.MapFrom(src => src.distributor_id))
              .ForMember(dest => dest.distributor_name, opt => opt.MapFrom(src => src.distributor_name))
              .ForMember(dest => dest.city_id, opt => opt.MapFrom(src => src.city_id))
              .ForMember(dest => dest.manager_id, opt => opt.MapFrom(src => src.manager_id));
        }


    }
}
