﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.DistributorFeatures.GelAllDistributor
{
    public class GetAllDistributorHandler : IRequestHandler<GetAllDistributorRequestModel, GetAllDistributorResponseModel>
    {
        private readonly IRepository<Distributor> _distributorRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public GetAllDistributorHandler(IRepository<Distributor> distributorRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _distributorRepository = distributorRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<GetAllDistributorResponseModel> Handle(GetAllDistributorRequestModel request, CancellationToken cancellationToken)
        {
           return Task.FromResult(new GetAllDistributorResponseModel()
           {
               distributors=GetAllDistributor()
           });
        }
        private List<DistributorRepresentationModel> GetAllDistributor()
        {
            return _distributorRepository.GetAllQuery().Where(s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<DistributorRepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
