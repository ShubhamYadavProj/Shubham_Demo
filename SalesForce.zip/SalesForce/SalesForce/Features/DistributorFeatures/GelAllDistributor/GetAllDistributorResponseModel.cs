﻿namespace SalesForce.Features.DistributorFeatures.GelAllDistributor
{
    public class GetAllDistributorResponseModel
    {
        public List<DistributorRepresentationModel> distributors { get; set; }
    }
}
