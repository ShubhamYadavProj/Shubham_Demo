﻿using MediatR;

namespace SalesForce.Features.DistributorFeatures.GelAllDistributor
{
    public class GetAllDistributorRequestModel:IRequest<GetAllDistributorResponseModel>
    {

    }
}
