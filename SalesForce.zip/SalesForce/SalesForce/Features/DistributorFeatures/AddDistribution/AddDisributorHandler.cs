﻿using Infastructure.Repository.Base;
using MediatR;
using Core.Entities;
using AutoMapper;

namespace SalesForce.Features.DistributorFeatures.AddDistribution
{
    public class AddDisributorHandler : IRequestHandler<AddDistributorRequestModel, AddDistributorResponseModel>
    {

        private readonly IRepository<Distributor> _distributorRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public AddDisributorHandler(IRepository<Distributor> distributorRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _distributorRepository = distributorRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddDistributorResponseModel> Handle(AddDistributorRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddDistributorResponseModel()
            {
                distributor = AddDistributor(request)

            }) ;
        }

        private DistributorRepresentationModel AddDistributor(AddDistributorRequestModel request)
        {
            var newDistributor=_mapper.Map<Distributor>(request.distributor);

            newDistributor.status = Core.Enum.EntityStatus.Active;

            _distributorRepository.AddAsync(newDistributor).ConfigureAwait(false).GetAwaiter().GetResult();

            _unitOfWork.Commit();

            return _mapper.Map<DistributorRepresentationModel>(newDistributor);
        }
    }
}
