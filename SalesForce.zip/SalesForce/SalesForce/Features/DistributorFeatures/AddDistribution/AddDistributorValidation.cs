﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;

namespace SalesForce.Features.DistributorFeatures.AddDistribution
{
    public class AddDistributorValidation:AbstractValidator<AddDistributorRequestModel>
    {

        public AddDistributorValidation(IRepository<Distributor> _repository)
        {
            RuleFor(req => req.distributor.distributor_name)
           .NotNull()
           .WithMessage("Distributor name can not be null!")
           .NotEmpty()
           .WithMessage("order name can not be empty!");


            RuleFor(req => req.distributor.city_id)
             .NotNull()
             .WithMessage("city can not be null!")
             .NotEmpty()
             .WithMessage("city can not be empty!");

        }
    }
}
