﻿namespace SalesForce.Features.DistributorFeatures.AddDistribution
{
    public class AddDistributorResponseModel
    {

        public DistributorRepresentationModel distributor { get; set; }
    }
}
