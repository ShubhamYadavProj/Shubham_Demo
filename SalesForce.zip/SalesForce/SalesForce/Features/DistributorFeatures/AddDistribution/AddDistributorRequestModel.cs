﻿using MediatR;

namespace SalesForce.Features.DistributorFeatures.AddDistribution
{
    public class AddDistributorRequestModel:IRequest<AddDistributorResponseModel>
    {

        public DistributorRepresentationModel distributor { get; set; }

    }
}
