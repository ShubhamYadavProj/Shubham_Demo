﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;

namespace SalesForce.Features.DistributorFeatures.UpdateDistributor
{
    public class UpdateDistributorValidation:AbstractValidator<UpdateDistributorRequestModel>
    {
        public UpdateDistributorValidation(IRepository<Distributor> _repository)
        {
            RuleFor(req => req.Distributor.distributor_name)
           .NotNull()
           .WithMessage("Distributor name can not be null!")
           .NotEmpty()
           .WithMessage("order name can not be empty!");


            RuleFor(req => req.Distributor.distributor_id)
             .NotNull()
             .WithMessage("city can not be null!")
             .NotEmpty()
             .WithMessage("city can not be empty!");

        }
    }
}
