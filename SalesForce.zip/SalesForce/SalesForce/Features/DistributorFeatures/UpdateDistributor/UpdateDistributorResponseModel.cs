﻿namespace SalesForce.Features.DistributorFeatures.UpdateDistributor
{
    public class UpdateDistributorResponseModel
    {

        public DistributorRepresentationModel Distributor { get; set; }
    }
}
