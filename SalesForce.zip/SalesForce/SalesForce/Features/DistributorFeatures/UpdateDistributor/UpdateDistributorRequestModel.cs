﻿using MediatR;

namespace SalesForce.Features.DistributorFeatures.UpdateDistributor
{
    public class UpdateDistributorRequestModel:IRequest<UpdateDistributorResponseModel>
    {
        public DistributorRepresentationModel Distributor { get; set; }
    }
}
