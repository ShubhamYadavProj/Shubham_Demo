﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.DistributorFeatures.UpdateDistributor
{
    public class UpdateDistributorHandler : IRequestHandler<UpdateDistributorRequestModel, UpdateDistributorResponseModel>
    {

        private readonly IRepository<Distributor> _distributorRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateDistributorHandler(IRepository<Distributor> distributorRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _distributorRepository = distributorRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }
        public Task<UpdateDistributorResponseModel> Handle(UpdateDistributorRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateDistributorResponseModel()
            {
                Distributor = UpdateDistributor(request)
            });
        }

        private DistributorRepresentationModel UpdateDistributor(UpdateDistributorRequestModel request)
        {

            var currentDistributor=_distributorRepository.GetAllQuery().Where(s=>s.distributor_id==request.Distributor.distributor_id).FirstOrDefault();

            if (currentDistributor!=null)
            {
                currentDistributor.distributor_name = request.Distributor.distributor_name;
                currentDistributor.city_id=request.Distributor.city_id;
                currentDistributor.manager_id=request.Distributor.manager_id;

                _distributorRepository.UpdateAsync(currentDistributor).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
            }

            return request.Distributor;
        }
    }
}
