﻿using MediatR;

namespace SalesForce.Features.DistributorFeatures.DeleteDistributor
{
    public class DeleteDistributorRequestModel:IRequest<DeleteDistributorResponseModel>
    {
        public int DistributorId { get; set; }
    }
}
