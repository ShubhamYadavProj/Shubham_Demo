﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.DistributorFeatures.DeleteDistributor
{
    public class DeleteDistributorHandler : IRequestHandler<DeleteDistributorRequestModel, DeleteDistributorResponseModel>
    {

        private readonly IRepository<Distributor> _distributorRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteDistributorHandler(IRepository<Distributor> distributorRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _distributorRepository = distributorRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }
        public Task<DeleteDistributorResponseModel> Handle(DeleteDistributorRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteDistributorResponseModel()
            {
                IsDelete = DeleteDistributor(request)
            }) ;
        }

        private bool DeleteDistributor(DeleteDistributorRequestModel request)
        {
            var currentDistributor=_distributorRepository.GetAllQuery().Where(s=>s.distributor_id==request.DistributorId).FirstOrDefault();

            if (currentDistributor!=null)
            {
                currentDistributor.status=Core.Enum.EntityStatus.Inactive; 
                _distributorRepository.UpdateAsync(currentDistributor).ConfigureAwait(false).GetAwaiter().GetResult();


            }
            return _unitOfWork.Commit() > 0;
        }
    }
}
