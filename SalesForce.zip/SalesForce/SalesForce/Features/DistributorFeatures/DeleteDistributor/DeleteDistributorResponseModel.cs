﻿namespace SalesForce.Features.DistributorFeatures.DeleteDistributor
{
    public class DeleteDistributorResponseModel
    {
        public bool IsDelete { get; set; }
    }
}
