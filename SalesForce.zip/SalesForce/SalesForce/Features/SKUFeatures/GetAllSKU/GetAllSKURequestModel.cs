﻿using MediatR;

namespace SalesForce.Features.SKUFeatures.GetAllSKU
{
    public class GetAllSKURequestModel:IRequest<GetAllSKUResponseModel>
    {

    }
}
