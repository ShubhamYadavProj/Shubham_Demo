﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.SKUFeatures.GetAllSKU
{
    public class GetAllSKUHandler : IRequestHandler<GetAllSKURequestModel, GetAllSKUResponseModel>
    {
        private readonly IMapper _mapper;
        private readonly IRepository<SKU> _skuRepository;

        public GetAllSKUHandler(IRepository<SKU> repository,IMapper mapper)
        {
                _skuRepository= repository;
            _mapper= mapper;
        }

        public Task<GetAllSKUResponseModel> Handle(GetAllSKURequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllSKUResponseModel()
            {
                SKU = GetAllSKU()
            });
        }

        private List<SKURepresentationModel> GetAllSKU ()
        {
            return _skuRepository.GetAllQuery().Where(s=>s.status==Core.Enum.EntityStatus.Active).ProjectTo<SKURepresentationModel>(_mapper.ConfigurationProvider).ToList();
        }
    }
}
