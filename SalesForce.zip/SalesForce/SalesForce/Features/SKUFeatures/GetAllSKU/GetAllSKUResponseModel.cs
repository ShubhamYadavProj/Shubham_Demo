﻿namespace SalesForce.Features.SKUFeatures.GetAllSKU
{
    public class GetAllSKUResponseModel
    {
     public  List<SKURepresentationModel> SKU { get; set; }
    }
}
