﻿using Core.Entities;
using Core.Enum;

namespace SalesForce.Features.SKUFeatures
{
    public class SKURepresentationModel
    {

        public int SKU_Id { get; set; }

        public string SKU_Name { get; set; }

        public float SKU_Price { get;set; }

      //  public EntityStatus status { get; set; }

        public int UOM_Id { get; set; }
        public int catrgory_Id { get; set; }

     //   public int category_name { get; set; }
     
       
    }
}
