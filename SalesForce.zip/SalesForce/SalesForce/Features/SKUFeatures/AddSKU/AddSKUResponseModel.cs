﻿namespace SalesForce.Features.SKUFeatures.AddSKU
{
    public class AddSKUResponseModel
    {
        public SKURepresentationModel SKUresponse { get; set; }
    }
}
