﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.SKUFeatures.AddSKU
{
    public class AddSKUHandler : IRequestHandler<AddSKURequestModel, AddSKUResponseModel>
    {
        private readonly IRepository<SKU> _skuRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public AddSKUHandler(IRepository<SKU> skuRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _skuRepository = skuRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddSKUResponseModel> Handle(AddSKURequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddSKUResponseModel()
            {
                SKUresponse = AddSKU(request)
            }) ;
        }

        private SKURepresentationModel AddSKU(AddSKURequestModel request)
        {
            var newSKU=_mapper.Map<SKU>(request.SKUrequest);

            newSKU.status = Core.Enum.EntityStatus.Active;

            _skuRepository.AddAsync(newSKU).ConfigureAwait(false).GetAwaiter().GetResult();

            _unitOfWork.Commit();

            return _mapper.Map<SKURepresentationModel>(newSKU);

        }
    }
}
