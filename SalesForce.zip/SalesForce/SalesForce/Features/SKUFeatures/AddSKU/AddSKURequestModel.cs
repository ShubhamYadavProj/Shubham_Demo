﻿using MediatR;

namespace SalesForce.Features.SKUFeatures.AddSKU
{
    public class AddSKURequestModel:IRequest<AddSKUResponseModel>
    {
        public SKURepresentationModel SKUrequest { get; set; }
    }
}
