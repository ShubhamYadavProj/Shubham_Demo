﻿using MediatR;

namespace SalesForce.Features.SKUFeatures.UpdateSKU
{
    public class UpdateSKURequestModel:IRequest<UpdateSKUResponseModel>
    {
        public SKURepresentationModel sku { get; set; }
    }
}
