﻿namespace SalesForce.Features.SKUFeatures.UpdateSKU
{
    public class UpdateSKUResponseModel
    {
        public SKURepresentationModel sku { get; set; }
    }
}
