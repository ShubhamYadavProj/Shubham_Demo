﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.SKUFeatures.UpdateSKU
{
    public class UpdateSKUHandler : IRequestHandler<UpdateSKURequestModel, UpdateSKUResponseModel>
    {

        private readonly IMapper _mapper;
        private readonly IRepository<SKU> _skuRepository;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateSKUHandler(IMapper mapper, IRepository<SKU> skuRepository, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _skuRepository = skuRepository;
            _unitOfWork = unitOfWork;
        }

        public Task<UpdateSKUResponseModel> Handle(UpdateSKURequestModel request, CancellationToken cancellationToken)
        {
               return  Task.FromResult(new UpdateSKUResponseModel()
               {
                   sku=UpdateSKU(request)
               });
        }

        private SKURepresentationModel UpdateSKU(UpdateSKURequestModel request)
        {
            var currentSKU=_skuRepository.GetAllQuery().Where(s=>s.sku_id==request.sku.SKU_Id).FirstOrDefault();

            if(currentSKU!=null)
            {
                currentSKU.sku_name = request.sku.SKU_Name;
                currentSKU.sku_price = request.sku.SKU_Price;
                currentSKU.unit_of_measurment_id = request.sku.UOM_Id;
                currentSKU.category_id = request.sku.catrgory_Id;

                _skuRepository.UpdateAsync(currentSKU).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
                   
            }
            return request.sku;
        }
    }
}
