﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.SKUFeatures.DeleteSKU
{
    public class DeleteSKUHandler : IRequestHandler<DeleteSKURequestModel, DeleteSKUResponseModel>
    {
        private readonly IRepository<SKU> _skuRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteSKUHandler(IRepository<SKU> skuRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _skuRepository = skuRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteSKUResponseModel> Handle(DeleteSKURequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteSKUResponseModel()
            {
                Isdelete = DeleteSKU(request)
            }) ;
        }


        private bool DeleteSKU(DeleteSKURequestModel request)
        {
            var currentSKU=_skuRepository.GetAllQuery().Where(s=>s.sku_id==request.SkuId).FirstOrDefault();

            if (currentSKU!=null)
            {
                currentSKU.status = Core.Enum.EntityStatus.Inactive;
                _skuRepository.UpdateAsync(currentSKU).ConfigureAwait(false).GetAwaiter().GetResult();
               
            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
