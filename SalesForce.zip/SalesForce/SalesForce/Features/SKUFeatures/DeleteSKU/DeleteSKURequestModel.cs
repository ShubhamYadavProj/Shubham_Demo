﻿using MediatR;

namespace SalesForce.Features.SKUFeatures.DeleteSKU
{
    public class DeleteSKURequestModel:IRequest<DeleteSKUResponseModel>
    {
        public int SkuId { get; set; }
    }
}
