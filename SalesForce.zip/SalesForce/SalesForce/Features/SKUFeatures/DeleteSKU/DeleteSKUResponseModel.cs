﻿namespace SalesForce.Features.SKUFeatures.DeleteSKU
{
    public class DeleteSKUResponseModel
    {
        public bool Isdelete { get; set; }  
    }
}
