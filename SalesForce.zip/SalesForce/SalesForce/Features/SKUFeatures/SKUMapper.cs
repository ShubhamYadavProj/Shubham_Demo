﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.SKUFeatures
{
    public class SKUMapper : Profile
    {

        public SKUMapper()
        {
            CreateMap<SKU, SKURepresentationModel>()
                .ForMember(dest => dest.SKU_Id, opt => opt.MapFrom(src => src.sku_id))
                .ForMember(dest => dest.SKU_Name, opt => opt.MapFrom(src => src.sku_name))
                 .ForMember(dest => dest.SKU_Price, opt => opt.MapFrom(src => src.sku_price))
                  .ForMember(dest => dest.UOM_Id, opt => opt.MapFrom(src => src.unit_of_measurment_id))
                   .ForMember(dest => dest.catrgory_Id, opt => opt.MapFrom(src => src.category_id));

                  // .ForMember(dest => dest.status, opt => opt.Ignore());



            CreateMap<SKURepresentationModel, SKU>()
              .ForMember(dest => dest.sku_id, opt => opt.MapFrom(src => src.SKU_Id))
              .ForMember(dest => dest.sku_name, opt => opt.MapFrom(src => src.SKU_Name))
               .ForMember(dest => dest.sku_price, opt => opt.MapFrom(src => src.SKU_Price))
                .ForMember(dest => dest.unit_of_measurment_id, opt => opt.MapFrom(src => src.UOM_Id))
                 .ForMember(dest => dest.category_id, opt => opt.MapFrom(src => src.catrgory_Id));
               //   .ForMember(dest => dest.status, opt => opt.Ignore()); 
        }
    }
}
