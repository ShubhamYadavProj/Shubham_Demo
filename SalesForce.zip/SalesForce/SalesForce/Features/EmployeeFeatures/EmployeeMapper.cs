﻿using AutoMapper;
using Core.Entities;

namespace SalesForce.Features.EmployeeFeatures
{
    public class EmployeeMapper:Profile
    {
        public EmployeeMapper()
        {
            CreateMap<Employee, EmployeeRepresentationModel>()
                .ForMember(dest=>dest.Emp_iD,opt=>opt.MapFrom(src=>src.employee_id))
                .ForMember(dest=>dest.Emp_name,opt=>opt.MapFrom(src=>src.employee_name))
                 .ForMember(dest => dest.Emp_email, opt => opt.MapFrom(src => src.employee_email))
                  .ForMember(dest => dest.Emp_phone, opt => opt.MapFrom(src => src.employee_phone))
                   .ForMember(dest => dest.Employee_type, opt => opt.MapFrom(src => src.employeeType))
                    .ForMember(dest => dest.Mng_id, opt => opt.MapFrom(src => src.manager_id));


            CreateMap<EmployeeRepresentationModel, Employee>()
                .ForMember(dest => dest.employee_id, opt => opt.MapFrom(src => src.Emp_iD))
                .ForMember(dest => dest.employee_name, opt => opt.MapFrom(src => src.Emp_name))
                 .ForMember(dest => dest.employee_email, opt => opt.MapFrom(src => src.Emp_email))
                  .ForMember(dest => dest.employee_phone, opt => opt.MapFrom(src => src.Emp_phone))
                   .ForMember(dest => dest.employeeType, opt => opt.MapFrom(src => src.Employee_type))
                    .ForMember(dest => dest.manager_id, opt => opt.MapFrom(src => src.Mng_id));




        }

    }
}
