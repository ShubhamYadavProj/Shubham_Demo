﻿using MediatR;

namespace SalesForce.Features.EmployeeFeatures.GetEmployeeById
{
    public class GetEmloyeeByIdRequestModel:IRequest<GetEmployeeByIdResponseModel>
    {
        public int EmployeeId { get; set; }
    }
}
