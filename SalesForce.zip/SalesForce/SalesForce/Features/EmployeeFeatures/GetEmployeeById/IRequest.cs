﻿namespace SalesForce.Features.EmployeeFeatures.GetEmployeeById
{
    public interface IRequest<T1, T2>
    {
    }
}