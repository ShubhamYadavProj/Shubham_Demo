﻿namespace SalesForce.Features.EmployeeFeatures.GetEmployeeById
{
    public class GetEmployeeByIdResponseModel
    {  
        public EmployeeRepresentationModel Employee { get; set; }
    }
}
