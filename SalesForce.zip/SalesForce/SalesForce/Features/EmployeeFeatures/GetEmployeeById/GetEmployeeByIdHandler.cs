﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeeFeatures.GetEmployeeById
{
    public class GetEmployeeByIdHandler : IRequestHandler<GetEmloyeeByIdRequestModel, GetEmployeeByIdResponseModel>
    {
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IMapper _mapper;

        public GetEmployeeByIdHandler(IRepository<Employee> employeeRepository, IMapper mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public Task<GetEmployeeByIdResponseModel> Handle(GetEmloyeeByIdRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetEmployeeByIdResponseModel()
            {
                Employee=GetEmployeeById(request)
            });
        }

        private EmployeeRepresentationModel GetEmployeeById(GetEmloyeeByIdRequestModel request)
        {
            return _employeeRepository.GetAllQuery().Where(s => s.employee_id == request.EmployeeId).ProjectTo<EmployeeRepresentationModel>(_mapper.ConfigurationProvider).FirstOrDefault();
        }
    }
}
