﻿using Core.Enum;

namespace SalesForce.Features.EmployeeFeatures
{
    public class EmployeeRepresentationModel
    {
        public int Emp_iD { get; set; }

        public string Emp_name { get; set; }

        public string Emp_email { get; set; }

        public string Emp_phone { get; set; }

        public int? Mng_id { get; set; }

        public EmployeeType Employee_type { get; set; }

      

    }
}
