﻿using MediatR;

namespace SalesForce.Features.EmployeeFeatures.UpdateEmployee
{
    public class UpdateEmployeeRequestModel:IRequest<UpdateEmployeeResponseModel>
    {
        public EmployeeRepresentationModel Employee { get; set; }
    }
}
