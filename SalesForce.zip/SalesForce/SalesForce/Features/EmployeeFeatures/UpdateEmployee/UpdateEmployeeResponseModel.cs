﻿namespace SalesForce.Features.EmployeeFeatures.UpdateEmployee
{
    public class UpdateEmployeeResponseModel
    {
        public EmployeeRepresentationModel Employee { get; set; }
    }
}
