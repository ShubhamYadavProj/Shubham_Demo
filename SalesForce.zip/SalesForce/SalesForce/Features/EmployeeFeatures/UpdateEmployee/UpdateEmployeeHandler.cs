﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeeFeatures.UpdateEmployee
{
    public class UpdateEmployeeHandler : IRequestHandler<UpdateEmployeeRequestModel, UpdateEmployeeResponseModel>
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IRepository<Employee> _employeeRepository;

        public UpdateEmployeeHandler(IMapper mapper,IUnitOfWork unitOfWork,IRepository<Employee> repository)
        {
            mapper = _mapper;
            _unitOfWork = unitOfWork;
            _employeeRepository= repository;
        }

        public Task<UpdateEmployeeResponseModel> Handle(UpdateEmployeeRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new UpdateEmployeeResponseModel()
            {
                Employee = UpdateEmployee(request)
            }) ;
        }

        private EmployeeRepresentationModel UpdateEmployee(UpdateEmployeeRequestModel request)
        {
            var currentEmployee=_employeeRepository.GetAllQuery().Where(s=>s.employee_id==request.Employee.Emp_iD).FirstOrDefault();

            if(currentEmployee!=null)
            {
                currentEmployee.employee_name=request.Employee.Emp_name;
                currentEmployee.employee_email=request.Employee.Emp_email;
                currentEmployee.employee_phone=request.Employee.Emp_phone;
                currentEmployee.employeeType = request.Employee.Employee_type;

                _employeeRepository.UpdateAsync(currentEmployee).ConfigureAwait(false).GetAwaiter().GetResult();
                _unitOfWork.Commit();
            }

            return request.Employee;
        }
    }
}
