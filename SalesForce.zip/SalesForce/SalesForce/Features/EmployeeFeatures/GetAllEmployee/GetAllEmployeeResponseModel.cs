﻿namespace SalesForce.Features.EmployeeFeatures.GetAllEmployee
{
    public class GetAllEmployeeResponseModel
    {
        public List<EmployeeRepresentationModel> Employees { get; set; }
    }
}
