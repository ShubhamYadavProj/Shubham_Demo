﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeeFeatures.GetAllEmployee
{
    public class GetAllEmployeeHandler : IRequestHandler<GetAllEmployeeRequestModel, GetAllEmployeeResponseModel>
    {
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IMapper _mapper;


        public GetAllEmployeeHandler(IRepository<Employee> employeeRepository, IMapper mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public Task<GetAllEmployeeResponseModel> Handle(GetAllEmployeeRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new GetAllEmployeeResponseModel()
            {
                Employees = GetAllEmployee()
            }); 
        }

        private List<EmployeeRepresentationModel> GetAllEmployee()
        {
            return _employeeRepository.GetAllQuery().Where (s=>s.status==Core.Enum.EntityStatus.Active)
                                      .ProjectTo<EmployeeRepresentationModel>(_mapper.ConfigurationProvider)
                                      .ToList();
        }
    }
}
