﻿using MediatR;

namespace SalesForce.Features.EmployeeFeatures.GetAllEmployee
{
    public class GetAllEmployeeRequestModel:IRequest<GetAllEmployeeResponseModel>
    {

    }
}
