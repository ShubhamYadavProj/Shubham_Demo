﻿using MediatR;

namespace SalesForce.Features.EmployeeFeatures.DeleteEmployee
{
    public class DeleteEmployeeRequestModel:IRequest<DeleteEmployeeResponseModel>
    {
        public int EmployeeId { get; set; }
    }
}
