﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeeFeatures.DeleteEmployee
{
    public class DeleteEmployeeHandler : IRequestHandler<DeleteEmployeeRequestModel, DeleteEmployeeResponseModel>
    {
        private readonly IMapper _mapper;
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteEmployeeHandler(IMapper mapper, IRepository<Employee> employeeRepository, IUnitOfWork unitOfWork)
        {
            _mapper = mapper;
            _employeeRepository = employeeRepository;
            _unitOfWork = unitOfWork;
        }

        public Task<DeleteEmployeeResponseModel> Handle(DeleteEmployeeRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new DeleteEmployeeResponseModel()
            {
                IsDeleted = DeleteEmployee(request)
            }) ;
        }

        private bool DeleteEmployee(DeleteEmployeeRequestModel request)
        {
            var currentEmployee=_employeeRepository.GetAllQuery().Where(s=>s.employee_id==request.EmployeeId).FirstOrDefault();

            if (currentEmployee!=null)
            {
                currentEmployee.status = Core.Enum.EntityStatus.Inactive;

                _employeeRepository.UpdateAsync(currentEmployee).ConfigureAwait(false).GetAwaiter().GetResult();

            }

            return _unitOfWork.Commit() > 0;
        }
    }
}
