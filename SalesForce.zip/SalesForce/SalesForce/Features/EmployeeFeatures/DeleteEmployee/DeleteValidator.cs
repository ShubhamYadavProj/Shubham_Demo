﻿using Core.Entities;
using FluentValidation;
using Infastructure.Repository.Base;
using System;

namespace SalesForce.Features.EmployeeFeatures.DeleteEmployee
{
    public class DeleteValidator:AbstractValidator<DeleteEmployeeRequestModel>
    {
        public DeleteValidator(IRepository<Employee> _repository)
        {
            RuleFor(req => req.EmployeeId)
               .NotNull()
               .WithMessage("EmployeeId can not be null!")
               .NotEmpty()
               .WithMessage("EmployeeId can not be empty!");


            RuleFor(req => req)
                .Custom((req, context) =>
                {
                    var EmployeeExist = _repository.GetAllQuery()
                                                     .Where(id => id.employee_id == req.EmployeeId)
                                                     .Where(s => s.status == Core.Enum.EntityStatus.Active)
                                                     .Any();
                    if (!EmployeeExist)
                    {
                        context.AddFailure("Employee does not exist");
                    }
                });
        }
    }
}
