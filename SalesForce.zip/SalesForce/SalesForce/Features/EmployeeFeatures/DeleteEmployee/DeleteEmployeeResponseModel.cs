﻿namespace SalesForce.Features.EmployeeFeatures.DeleteEmployee
{
    public class DeleteEmployeeResponseModel
    {
        public bool IsDeleted { get; set; }
    }
}
