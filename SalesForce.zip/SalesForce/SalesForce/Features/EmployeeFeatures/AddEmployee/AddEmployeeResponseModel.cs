﻿namespace SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures
{
    public class AddEmployeeResponseModel
    {
        public EmployeeRepresentationModel Employee { get; set; }
    }
}
