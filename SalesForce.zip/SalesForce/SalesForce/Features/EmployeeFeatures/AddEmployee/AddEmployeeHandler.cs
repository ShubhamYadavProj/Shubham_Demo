﻿using AutoMapper;
using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;

namespace SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures
{
    public class AddEmployeeHandler : IRequestHandler<AddEmployeeRequestModel, AddEmployeeResponseModel>
    {
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;


        public AddEmployeeHandler(IRepository<Employee> employeeRepository, IMapper mapper, IUnitOfWork unitOfWork)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
            _unitOfWork = unitOfWork;
        }

        public Task<AddEmployeeResponseModel> Handle(AddEmployeeRequestModel request, CancellationToken cancellationToken)
        {
            return Task.FromResult(new AddEmployeeResponseModel()
            {
                Employee = AddEmployee(request)
            }) ;
        }

        private EmployeeRepresentationModel AddEmployee(AddEmployeeRequestModel request)
        {
            var newEmp=_mapper.Map<Employee>(request.Employee);

            newEmp.status = Core.Enum.EntityStatus.Active;
          
            _employeeRepository.AddAsync(newEmp).ConfigureAwait(false).GetAwaiter().GetResult();

            _unitOfWork.Commit();

            return _mapper.Map<EmployeeRepresentationModel>(newEmp);




        }
    }
}
