﻿using Core.Entities;
using FluentValidation;
using FluentValidation.Validators;
using Infastructure.Repository.Base;
using SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures;

namespace SalesForce.Features.EmployeeFeatures.AddEmployee
{
    public class AddEmployeeValidation:AbstractValidator<AddEmployeeRequestModel>
    {

        public AddEmployeeValidation(IRepository<Employee> _employeeRepository)
        {
            RuleFor(req => req.Employee.Emp_name)
                .NotNull()
                .WithMessage("Employee name can not be null")
                .NotEmpty()
                .WithMessage("Employee name can not be null")
                .MaximumLength(20)
                .WithMessage("Employee name can not exceed more")
                .MinimumLength(2)
                .WithMessage("Employee name must be atleast 2 letter");

            RuleFor(req => req.Employee.Emp_phone)
            .NotNull()
            .WithMessage("Employee Mobile No can not be null")
            .NotEmpty()
            .WithMessage("Employee Mobile No can not be null")
            .MinimumLength(10)
            .WithMessage("Employee Mobile No Atleast 10 digit")
            .MaximumLength(10)
            .WithMessage("Employee Mobile No can not exceed 10 digit");

            RuleFor(req => req.Employee.Employee_type)
                .NotNull()
                .WithMessage("Employee type can not be empty")
                .NotEmpty()
                .WithMessage("Employee type can not be empty");

            //RuleFor(req => req.Employee.EmpEmail)
            //    .EmailAddress(EmailValidationMode.Net4xRegex)
            //    .WithMessage("Please enter a proper format email address");

            RuleFor(req => req)
                .Custom((req, context) =>
                {
                    var codeEmail = _employeeRepository.GetAllQuery().Where(a => a.employee_email == req.Employee.Emp_email)
                                                       .Where(a => a.status == Core.Enum.EntityStatus.Active).Any();


                    if (codeEmail)
                    {
                        context.AddFailure("Email address already exist");
                    }
                });
                
        }
    }
}

