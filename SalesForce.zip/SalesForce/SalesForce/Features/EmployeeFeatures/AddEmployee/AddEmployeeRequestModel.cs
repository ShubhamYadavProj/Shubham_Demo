﻿using MediatR;

namespace SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures
{
    public class AddEmployeeRequestModel:IRequest<AddEmployeeResponseModel>
    {
        public EmployeeRepresentationModel Employee { get; set; }
    }
}
