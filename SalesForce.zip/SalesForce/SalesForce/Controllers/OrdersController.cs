﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.DeleteBeat;
using SalesForce.Features.BeatFeatures.UpdateBeat;
using SalesForce.Features.OrderFeatures.AddOrder;
using SalesForce.Features.OrderFeatures.DeleteOrder;
using SalesForce.Features.OrderFeatures.GetAllOrders;
using SalesForce.Features.OrderFeatures.GetOrderDetailsById;
using SalesForce.Features.OrderFeatures.UpdateOrder;

namespace SalesForce.Controllers
{
    [Route("Order")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly IMediator _mediator;

        public OrdersController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        public async Task<ActionResult<AddOrderResponseModel>> AddOrder([FromBody] AddOrderRequestModel reqest)
        {
           var result=await _mediator.Send(reqest);   
            return Ok(result);
        }

        [HttpGet]
        [Route("GetAllOrders")]
        public async Task<ActionResult<GetAllOrdersResponseModel>> GetAllOrders([FromRoute] GetAllOrdersRequestModel reqest)
        {
            var result = await _mediator.Send(reqest);
            return Ok(result);
        }



        [Route("{order_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateOrderResponseModel>> UpdateOrder([FromBody] UpdateOrderRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{order_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteOrderResponseModel>> DeleteOrder([FromRoute] DeleteOrderRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{order_Id}")]
        [HttpGet]
        public async Task<ActionResult<GetOrderDetailsByIdResponseModel>> GetOrderById([FromRoute] GetOrderDetailsByIdRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


    }
}
