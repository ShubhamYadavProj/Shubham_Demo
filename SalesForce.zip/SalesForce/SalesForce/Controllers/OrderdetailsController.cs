﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.AddBeat;
using SalesForce.Features.BeatFeatures.DeleteBeat;
using SalesForce.Features.BeatFeatures.GetAllBeat;
using SalesForce.Features.BeatFeatures.UpdateBeat;
using SalesForce.Features.Order_detailsFeatures.AddOrder_details;
using SalesForce.Features.Order_detailsFeatures.DeleteOrder_details;
using SalesForce.Features.Order_detailsFeatures.GetAllOrder_details;
using SalesForce.Features.Order_detailsFeatures.UpdateOrder_details;
using SalesForce.Features.OrderFeatures.UpdateOrder;

namespace SalesForce.Controllers
{
    [Route("Order_details")]
    [ApiController]
    public class OrderdetailsController : ControllerBase
    {

        private IMediator _mediator;

        public OrderdetailsController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [Route("GetAllOrder_details")]
        [HttpGet]
        public async Task<ActionResult<GetAllOrder_detailsResponseModel>> GetAllOrder_details([FromRoute] GetAllOrder_deatilsRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [HttpPost]
        public async Task<ActionResult<AddOrder_DetailsResponseModel>> AddOrder_details([FromBody] AddOrder_DetailsRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{order_details_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteOrder_detailResponseModel>> DeleteOrder_details([FromRoute] DeleteOrder_detailRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{order_details_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateOrder_detailsResponseModel>> UpdateOrder_details([FromBody] UpdateOrder_DetailsRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
    }
}
