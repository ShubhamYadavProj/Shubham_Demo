﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.CategoryFeatures.GetAllCategory;
using SalesForce.Features.StateFeatures.GetAllState;

namespace SalesForce.Controllers
{
    [Route("State")]
    [ApiController]
    public class StatesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public StatesController(IMediator mediator)
        {
            _mediator= mediator;
        }

        [Route("GetAllState")]
        [HttpGet]
        public async Task<ActionResult<GetAllStateResponseModel>> GetAllState([FromRoute] GetAllStateRequestModel    request)
        {
            var result= await _mediator.Send(request);
            return Ok(result);
        }
    }
}
