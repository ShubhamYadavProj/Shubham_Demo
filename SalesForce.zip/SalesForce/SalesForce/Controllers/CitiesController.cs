﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.CityFeatures.GetAllCity;
using SalesForce.Features.StateFeatures.GetAllState;

namespace SalesForce.Controllers
{
    [Route("City")]
    [ApiController]
    public class CitiesController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CitiesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Route("{StateID}")]
        [HttpGet]
        public async Task<ActionResult<GetAllCityResponseModel>> GetAllState([FromRoute] GetAllCityRequestModel request)
        {
            var result = await _mediator.Send(request);
            return Ok(result);
        }
    }
}
