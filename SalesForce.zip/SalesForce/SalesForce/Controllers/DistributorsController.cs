﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.AddBeat;
using SalesForce.Features.BeatFeatures.DeleteBeat;
using SalesForce.Features.BeatFeatures.GetAllBeat;
using SalesForce.Features.BeatFeatures.UpdateBeat;
using SalesForce.Features.DistributorFeatures.AddDistribution;
using SalesForce.Features.DistributorFeatures.DeleteDistributor;
using SalesForce.Features.DistributorFeatures.GelAllDistributor;
using SalesForce.Features.DistributorFeatures.UpdateDistributor;

namespace SalesForce.Controllers
{
    [Route("Distributor")]
    [ApiController]
    public class DistributorsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public DistributorsController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [HttpPost]
        public async Task<ActionResult<AddDistributorResponseModel>> AddDistributor([FromBody] AddDistributorRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("GetAllDistributors")]
        [HttpGet]
        public async Task<ActionResult<GetAllDistributorResponseModel>> GetAllDistributors([FromRoute] GetAllDistributorRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Distributor_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteDistributorResponseModel>> DeleteBeat([FromRoute] DeleteDistributorRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Distributor_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateDistributorResponseModel>> UpdateBeat([FromBody] UpdateDistributorRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
    }
}
