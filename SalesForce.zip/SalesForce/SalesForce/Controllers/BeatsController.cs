﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.AddBeat;
using SalesForce.Features.BeatFeatures.DeleteBeat;
using SalesForce.Features.BeatFeatures.GetAllBeat;
using SalesForce.Features.BeatFeatures.UpdateBeat;
using SalesForce.Features.CategoryFeatures.GetAllCategory;

namespace SalesForce.Controllers
{
    [Route("Beat")]
    [ApiController]
    public class BeatsController : ControllerBase
    {
        private IMediator _mediator;

        public BeatsController(IMediator mediator)
        {
                _mediator= mediator;
        }


        [Route("GetAllBeat")]
        [HttpGet]
        public async Task<ActionResult<GetAllBeatResponseModel>> GetAllBeat([FromRoute] GetAllBeatRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

       
        [HttpPost]
        public async Task<ActionResult<AddBeatResponseModel>> AddBeat([FromBody] AddBeatRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{Beat_ID}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteBeatResponseModel>> DeleteBeat([FromRoute] DeleteBeatRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{Beat_ID}")]
        [HttpPut]
        public async Task<ActionResult<UpdateBeatResponseModel>> UpdateBeat([FromBody] UpdateBeatRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

    }
}
