﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.AddBeat;
using SalesForce.Features.BeatFeatures.GetAllBeat;
using SalesForce.Features.CategoryFeatures.DeleteCategory;
using SalesForce.Features.CategoryFeatures.UpdateCategory;
using SalesForce.Features.UnitofworkFeatures.AddUnitOfMesurment;
using SalesForce.Features.UnitofworkFeatures.DeleteUnitOfWork;
using SalesForce.Features.UnitofworkFeatures.GetAllUnitOfWork;
using SalesForce.Features.UnitofworkFeatures.UpdateUnitOfMeasurment;

namespace SalesForce.Controllers
{
    [Route("UnitOfWork")]
    [ApiController]
    public class UnitOfMeasurmentsController : ControllerBase
    {
        private readonly IMediator _mediator;

        public UnitOfMeasurmentsController(IMediator mediator)
        {
            _mediator= mediator;
        }

        [Route("GetAllUnitOfWork")]
        [HttpGet]
        public async Task<ActionResult<GetAllUnitOfMeasurmentResponseModel>> GetAllunitOfWork([FromRoute] GetAllUnitOfMeasurmentRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [HttpPost]
        public async Task<ActionResult<AddUnitOfMeasurmentResponseModel>> AddunitOfWork([FromBody] AddUnitOfMesurmentRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{UnitOfWork_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateUnitOfWorkResponseModel>> UpdateUnitOfMeasurment([FromBody] UpdateUnitOfWorkRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }



        [Route("{UnitOfWork_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteUnitOfWorkResponseModel>> DeleteCategory([FromRoute] DeleteUnitOfWorkRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

    }
}
