﻿using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.CategoryFeatures.AddCategory;
using SalesForce.Features.CategoryFeatures.GetAllCategory;
using SalesForce.Features.EmployeeFeatures.AddEmployee;
using SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures;
using SalesForce.Features.EmployeeFeatures.DeleteEmployee;
using SalesForce.Features.EmployeeFeatures.GetAllEmployee;
using SalesForce.Features.EmployeeFeatures.GetEmployeeById;
using SalesForce.Features.EmployeeFeatures.UpdateEmployee;
using SalesForce.Features.OrderFeatures.GetOrderDetailsById;

namespace SalesForce.Controllers
{
    [Route("Employee")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {

        private readonly IMediator _mediator;
        private readonly IRepository<Employee> _employeeRepository;

        public EmployeesController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Route("GetAllEmployee")]
        [HttpGet]
        [Authorize]

        public async Task<ActionResult<GetAllEmployeeResponseModel>> GetAllEmployee([FromRoute] GetAllEmployeeRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [HttpPost]
        public async Task<ActionResult<AddEmployeeResponseModel>> AddEmployee([FromBody] AddEmployeeRequestModel request)
        {
           

            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Employee_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateEmployeeResponseModel>> UpdateEmployee([FromBody] UpdateEmployeeRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }



        [Route("{Employee_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteEmployeeResponseModel>> DeleteEmployee([FromRoute] DeleteEmployeeRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Employee_Id}")]
        [HttpGet]
        public async Task<ActionResult<GetEmployeeByIdResponseModel>> GetEmployeeById([FromRoute] GetEmloyeeByIdRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
    }
}
