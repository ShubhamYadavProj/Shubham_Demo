﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.CategoryFeatures.AddCategory;
using SalesForce.Features.CategoryFeatures.DeleteCategory;
using SalesForce.Features.CategoryFeatures.GetAllCategory;
using SalesForce.Features.CategoryFeatures.UpdateCategory;
using SalesForce.Features.EmployeeFeatures.UpdateEmployee;

namespace SalesForce.Controllers
{
    [Route("Category")]
    [ApiController]
    public class CategorysController : ControllerBase
    {
        private IMediator _mediator;

        public CategorysController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [Route("GetAllCategory")]
        [HttpGet]
        public async Task<ActionResult<GetAllCategoryResponseModel>> GetAllCategory([FromRoute] GetAllCategoryRequestModel request)
        {
            var result=await _mediator.Send(request);

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<AddCategoryResponseModel>> AddCategory([FromBody] AddCategoryRequestModel request)
        {
            var result=await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Category_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteCategoryResponseModel>> DeleteCategory([FromRoute] DeleteCategoryRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }



        [Route("{Category_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateCategoryResponseModel>> UpdateCategory([FromBody] UpdateCategoryRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
    }
}
