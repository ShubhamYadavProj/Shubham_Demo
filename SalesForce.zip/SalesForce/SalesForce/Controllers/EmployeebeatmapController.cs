﻿using Core.Entities;
using Infastructure.Repository.Base;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.EmployeebeatmapFeatures.AddEmployeebeatmap;
using SalesForce.Features.EmployeebeatmapFeatures.DeleteEmployeebeatmap;
using SalesForce.Features.EmployeebeatmapFeatures.GetAllEmployeebeatmap;
using SalesForce.Features.EmployeebeatmapFeatures.UpdateEmployeebeatmap;
using SalesForce.Features.EmployeeFeatures.AddEmployeeFeatures;
using SalesForce.Features.EmployeeFeatures.GetEmployeeById;

namespace SalesForce.Controllers
{
    [Route("EmployeeBeatMap")]
    [ApiController]
    public class EmployeebeatmapController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IRepository<Employee> _employeeRepository;
        public EmployeebeatmapController(IMediator mediator, IRepository<Employee> employeeRepository)
        {
            _mediator = mediator;
            _employeeRepository = employeeRepository;
        }
        [Route("GetAllEmpbeatmap")]
        [HttpGet]
        public  async Task<ActionResult<GetAllEmployeebeatmapResponseModel>>GetAllEmpbeatmap([FromRoute] GetAllEmployeebeatmapRequestModel model)
        {
            var result = await _mediator.Send(model);

            return Ok(result);
        }
        [Route("Addempbeatmap")]
        [HttpPost]        
        public async Task<ActionResult<AddEmployeebeatmapResponseModel>> Addempbeatmap([FromBody] AddEmployeebeatmapRequestModel  request)
        {


            var result = await _mediator.Send(request);

            return Ok(result);
        }
        [Route("{id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteEmployeebeatmapResponseModel>> DeleteEmpbeatmap_ById([FromRoute] DeleteEmployeebeatmapRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
        [Route("updateEmpbeatmap_ById")]
        [HttpPut]
        public async Task<ActionResult<UpdateEmployeebeatmapResponseModel>> updateEmpbeatmap_ById([FromBody] UpdateEmployeebeatmapRequestModel request)
        {
            var result= await _mediator.Send(request);
            return Ok(result);
        }
       
    }
}
