﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.CategoryFeatures.DeleteCategory;
using SalesForce.Features.Dsr_beat_map.AddDsr_beat_map;
using SalesForce.Features.Dsr_beat_map.DeleteDsr_beat_map;
using SalesForce.Features.Dsr_beat_map.GetDsr_beat_map;
using SalesForce.Features.Dsr_beat_map.UpdateDsr_beat_map;
using SalesForce.Features.EmployeeFeatures.GetEmployeeById;

namespace SalesForce.Controllers
{
    [Route("Dsrbeatmap")]
    public class DsrbeatmapController : Controller
    {
        private readonly IMediator _mediator;
        public DsrbeatmapController(IMediator mediator)
        {
            _mediator = mediator;
        }
        [Route("GetAllDsrbeatmap")]
        [HttpGet]
        public async Task<ActionResult<GetDsr_beat_mapResponseModel>> GetAllDsrbeatmap([FromRoute] GetDsr_beat_mapRequestModel model)
        {
            var result = await _mediator.Send(model);

            return Ok(result);
        }
        [HttpPost]
        public async Task<ActionResult<AddDsr_beat_mapResopnseModel>> AddDsrbeatmap([FromBody] AddDsr_beat_mapRequestModel model)
        {
            var result = await _mediator.Send(model);
            return Ok(result);
        }
        [Route("{id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateDsr_beat_mapResonseModel>> Updatdsrbeatmap([FromBody] UpdateDsr_beat_mapRequestModel model)
        {
            var result = await _mediator.Send(model);
            return Ok(result);
        }
        [Route("{id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteDsr_beat_mapResponseModel>> DeleteDsr([FromRoute] DeleteDsr_beat_mapRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);



        }
    }
}
