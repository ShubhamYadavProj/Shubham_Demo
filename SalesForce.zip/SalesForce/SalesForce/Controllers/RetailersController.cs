﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.RetailerFeatures.AddRetailer;
using SalesForce.Features.RetailerFeatures.DeleteRetailer;
using SalesForce.Features.RetailerFeatures.GetAllRetailerByBeatId;
using SalesForce.Features.RetailerFeatures.GetAllRetailers;
using SalesForce.Features.RetailerFeatures.GetAllRetailersByDsr;
using SalesForce.Features.RetailerFeatures.UpdateRetailer;

namespace SalesForce.Controllers
{
    [Route("Retailer")]
    [ApiController]
    public class RetailersController : ControllerBase
    {
        private readonly IMediator _mediator;

        public RetailersController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [Route("GetAllRetailers")]
        [HttpGet]
        public async Task<ActionResult<GetAllRetailersResponseModel>> GetAllRetailers([FromRoute] GetAllRetailersRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<AddRetailerResponseModel>>AddRetailer([FromBody] AddRetailerRequestModel request)
        {
            var result= await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{retailer_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteRetailerResponseModel>> DeleteRetailer([FromRoute] DeleteRetailerRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{retailer_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateRetailerResponseModel>> UpdateRetailer([FromBody] UpdateRetailerRequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }
       
        [Route("GetAllRetailerByBeatId/{id}")]
        [HttpGet]
        public  async Task<ActionResult<GetAllRetailerByBeatIdResponseModel>> GetAllRetailerByBeatId([FromRoute] GetAllRetailerByBeatIdRequsetModel model)
        {
            var result = await _mediator.Send(model);
            return Ok(result);
        }
        [Route("GetAllRetailerByDsr/{id}")]
        [HttpGet]
        public async Task<ActionResult<GetAllRetailerByDsrResponseModel>> GetAllRetailerByDsr([FromRoute] GetAllRetailersByDsrRequestModel model)
        {
            var result= await _mediator.Send(model);
            return Ok(result);
        }
    }
}
