﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SalesForce.Features.BeatFeatures.AddBeat;
using SalesForce.Features.SKUFeatures.AddSKU;
using SalesForce.Features.SKUFeatures.DeleteSKU;
using SalesForce.Features.SKUFeatures.GetAllSKU;
using SalesForce.Features.SKUFeatures.UpdateSKU;

namespace SalesForce.Controllers
{
    [Route("SKU")]
    [ApiController]
    public class SKUController : ControllerBase
    {

        private readonly IMediator _mediator;


        public SKUController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [Route("GetAllStockUnit")]
        [HttpGet]
        public async Task<ActionResult<GetAllSKUResponseModel>> GetAllStockUnit([FromRoute] GetAllSKURequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [HttpPost]
        public async Task<ActionResult<AddSKUResponseModel>> AddStockUnit([FromBody] AddSKURequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

        [Route("{Sku_Id}")]
        [HttpPut]
        public async Task<ActionResult<UpdateSKUResponseModel>> UpdateStockUnit([FromBody] UpdateSKURequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }


        [Route("{Sku_Id}")]
        [HttpDelete]
        public async Task<ActionResult<DeleteSKUResponseModel>> DeleteStockUnit([FromRoute] DeleteSKURequestModel request)
        {
            var result = await _mediator.Send(request);

            return Ok(result);
        }

    }
}
