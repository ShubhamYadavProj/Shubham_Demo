using AutoMapper;
using Core.Entities;
using Infastructure.Data;
using Infastructure.Repository.Base;
using Infrastructure;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SalesForce.Features.BeatFeatures.AddBeat;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// REGISTERED AUTOMAPPER SERVICE

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

// builder.Services.AddAutoMapper(typeof(Employee));
builder.Services.AddMediatR(typeof(AddBeatHandler));

builder.Services.AddScoped(typeof(IRepository<>), typeof(Repository<>));

builder.Services.AddScoped(typeof(IUnitOfWork), typeof(UnitOfWork));


//builder.Services.AddDbContext<DataContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("connection")));
builder.Services.AddDbContext<DataContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("connection"),
        sqlServerOptions => sqlServerOptions.MigrationsAssembly("SalesForce")
    )
);

//Add Identity middleware for UserManager dependency creation
builder.Services.AddIdentity<User, Role>()
    .AddEntityFrameworkStores<DataContext>()
    .AddUserManager<UserManager<User>>()
    .AddRoleManager<RoleManager<Role>>();

//services.AddAuthentication(IdentityServerAuthenticationDefaults.AuthenticationScheme)
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddIdentityServerAuthentication(options =>
{
    // base-address of your identityserver
    options.Authority = builder.Configuration.GetConnectionString("IdentityServerUrl");
    // options.RequireHttpsMetadata = false;

    // name of the API resource
    options.ApiName = builder.Configuration.GetConnectionString("APIResource");

});

// AuthorizationPolicy in Claim
builder.Services.AddSingleton<IAuthorizationPolicyProvider, CustomPolicyProvider>();


var app = builder.Build();

// Configure the HTTP request pipeline.
app.UseDeveloperExceptionPage();

app.UseSwagger();

app.UseSwaggerUI(c =>
{
    if (app.Environment.IsDevelopment())
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "SalesFore v1");
    }
});

app.UseHttpsRedirection();

app.UseRouting();

app.UseCors("corsapp");

app.UseAuthentication();

app.UseAuthorization();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
});

app.Run();
