﻿using Core.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Infastructure.Data
{
    public class DataContext :IdentityDbContext<User, Role, string, IdentityUserClaim<string>, UserRole, IdentityUserLogin<string>, UserRolesClaim,
        IdentityUserToken<string>>
    {

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public DbSet<User> AspNetUsers { get; set; }

        public DbSet<Role> AspNetRoles { get; set; }

        public DbSet<UserRole> AspNetuserRoles { get; set; }

         public DbSet<Category> catageroys { get; set; }

        public DbSet<Retailer> retailers { get; set; }

        public DbSet<Beat> beats { get; set; }

        public DbSet<City> cities { get; set; }

        public DbSet<State> states { get; set; }

        public DbSet<Distributor> distributors { get; set; }

        public DbSet<Dsr_Beat_Map> dsr_Beat_Maps { get; set; }

        public DbSet<Employee> employees { get; set; }

        public DbSet<Order> orders { get; set; }

        public DbSet<Order_deatils> order_details { get; set; }

        public DbSet<SKU> sku { get; set; }

        public DbSet<UnitOfMeasurment> unitofmeasurments { get; set; }
        public DbSet<Employeebeatmap> employeebeatmap { get; set;}


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasDefaultSchema("dbo");
            base.OnModelCreating(modelBuilder);


            //modelBuilder.Entity<>()
            //   .HasOne(o => o.Department).WithMany().HasForeignKey(o => o.deptId);

        }
    }
}
