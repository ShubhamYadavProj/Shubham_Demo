﻿using Core.Enum;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace Infrastructure
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, Inherited = false)]
    public class HasPermissionAttribute : AuthorizeAttribute
    {
        public HasPermissionAttribute(params Permissions[] permissions) : base(string.Join(",", permissions))
        { }
    }

    public class CustomPolicyProvider : DefaultAuthorizationPolicyProvider
    {
        public CustomPolicyProvider(IOptions<AuthorizationOptions> options) : base(options)
        {
        }

        public override Task<AuthorizationPolicy> GetPolicyAsync(string policyName)
        {
            var enumNames = policyName.Split(",");

            List<string> values = new List<string>();

            foreach (var Name in enumNames)
            {
                var enumName = (Permissions)Enum.Parse(typeof(Permissions), Name);
                var enumValue = (int)enumName;
                values.Add(enumValue.ToString());

            }

            var policy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().RequireClaim("Permission", values).Build();

            return Task.FromResult(policy);
        }

    }

}
