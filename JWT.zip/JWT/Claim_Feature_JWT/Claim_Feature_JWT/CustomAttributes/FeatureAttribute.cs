﻿using Claim_Feature_JWT.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Claim_Feature_JWT.CustomAttributes
{
    public class FeatureAttribute : Attribute, IActionFilter
    {

        public string[] _features { get; }
        public FeatureAttribute(params string[] features)
        {
            _features = features;
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            var user = context.HttpContext.User;
            if (user != null)
            {
                var hasFeature = _features.Any(feature => user.HasClaim(CustomClaims.Feature, feature));
                if (!hasFeature)
                {
                    context.Result = new ForbidResult();
                }
            }
            else
            {
                context.Result = new ForbidResult();
            }
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            throw new NotImplementedException();
        }
    }
}
