﻿using Microsoft.AspNetCore.Authorization;

namespace Claim_Feature_JWT.CustomAttributes
{
    public sealed class HasPermissionAttribute : AuthorizeAttribute
    {
        public HasPermissionAttribute(string permissions)
           : base(policy: permissions)
        {
        }
    }
}
