﻿using Microsoft.EntityFrameworkCore;

namespace Claim_Feature_JWT.Context
{
    public class ApplicationDbContext:DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options):base(options)
        {
            
        }   
        
    }
}
