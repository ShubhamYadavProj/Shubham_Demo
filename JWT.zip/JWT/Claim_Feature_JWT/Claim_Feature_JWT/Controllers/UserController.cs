﻿using Claim_Feature_JWT.Authorization;
using Claim_Feature_JWT.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Claim_Feature_JWT.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private IConfiguration _config;

        public UserController(IConfiguration config)
        {
            _config = config;
        }


        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<GetTokenResponseModel>> getToken([FromBody] GetTokenRequestModel request)
        {
            if (AuthenticateUser(request))
            {
                var tokenString = GenerateJSONWebToken(_config["Jwt:Key"], _config["Jwt:Issuer"]);


                return Ok(new GetTokenResponseModel()
                {
                    token = tokenString
                });
            }
            return Ok(new GetTokenResponseModel()
            {
                status = 500,
                message = "Invalid Credentials"
            });
        }

        private string GenerateJSONWebToken(string Key, string Issuer)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Key));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, ""),
                new Claim(JwtRegisteredClaimNames.Email, ""),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(CustomClaims.Role, "Admin"),
                new Claim(CustomClaims.Feature, "Feature1")
            };


            var token = new JwtSecurityToken(Issuer,
                Issuer,
                claims,
                expires: DateTime.Now.AddHours(24),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private bool AuthenticateUser(GetTokenRequestModel request)
        {

            if (request.client_id.Equals(_config["Client:client_id"]) && request.client_secrets.Equals(_config["Client:client_secrets"]))
            {
                return true;
            }
            return false;
        }

    }
}
