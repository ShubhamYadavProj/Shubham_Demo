﻿namespace Claim_Feature_JWT.Model
{
    public class GetTokenResponseModel: BaseResponseModel
    {
        public string token { get; set; }   
    }
}
