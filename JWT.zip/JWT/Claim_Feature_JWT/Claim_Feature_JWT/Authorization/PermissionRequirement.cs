﻿using Microsoft.AspNetCore.Authorization;

namespace Claim_Feature_JWT.Authorization
{
    public class PermissionRequirement: IAuthorizationRequirement
    {
        public PermissionRequirement(string permission)
        {
            Permission = permission;
        }

        public string Permission { get; }
    }
}
