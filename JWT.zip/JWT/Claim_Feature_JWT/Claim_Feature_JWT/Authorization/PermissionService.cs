﻿
using System.Collections.Generic;

namespace Claim_Feature_JWT.Authorization
{
    public class PermissionService : IPermission
    {
        public async Task<HashSet<string>> GetPermissionsAsync(string UserId)
        {
           HashSet<string> hashSet = new HashSet<string>();
            //Load from Database
            //Cahce time 30
            hashSet.Add("WeatherForecast");
            return  hashSet;
        }
    }
}
