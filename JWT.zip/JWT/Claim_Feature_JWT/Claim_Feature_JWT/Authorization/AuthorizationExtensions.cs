﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;

namespace Claim_Feature_JWT.Authorization
{
    public static class AuthorizationExtensions
    {
        internal static IServiceCollection AddAuthorizationInternal(this IServiceCollection services)
        {
            services.AddTransient<IClaimsTransformation, CustomClaimsTransformation>();

            services.AddTransient<IAuthorizationHandler, PermissionAuthorizationHandler>();

            services.AddTransient<IAuthorizationPolicyProvider, PermissionAuthorizationPolicyProvider>();


            services.AddTransient<IPermission, PermissionService>();



            return services;
        }
    }
}
