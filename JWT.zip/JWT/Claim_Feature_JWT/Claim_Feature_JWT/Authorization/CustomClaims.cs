﻿namespace Claim_Feature_JWT.Authorization
{
    public class CustomClaims
    {
        public const string Sub = "sub";
        public const string Permission = "permission";
        public static string Role = "role";
        public static string Feature = "feature";
    }
}
