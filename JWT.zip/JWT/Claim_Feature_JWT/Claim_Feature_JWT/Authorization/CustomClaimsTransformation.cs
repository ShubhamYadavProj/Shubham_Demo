﻿using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;

namespace Claim_Feature_JWT.Authorization
{
    public class CustomClaimsTransformation(IServiceScopeFactory serviceScopeFactory) : IClaimsTransformation
    {
        public async Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            if (principal.HasClaim(c => c.Type == CustomClaims.Sub))
            {
                return principal;
            }

            using IServiceScope scope = serviceScopeFactory.CreateScope();

            IPermission permissionService = scope.ServiceProvider.GetRequiredService<IPermission>();

            string identityId = principal.GetIdentityId();

            HashSet<string> result = await permissionService.GetPermissionsAsync(identityId);

            var claimsIdentity = new ClaimsIdentity();

            //claimsIdentity.AddClaim(new Claim(CustomClaims.Sub, result.Value.UserId.ToString()));

            if (result != null)
            {
                foreach (string permission in result)
                {
                    claimsIdentity.AddClaim(new Claim(CustomClaims.Permission, permission));
                }
            }

            principal.AddIdentity(claimsIdentity);

            return principal;
        }
    }
}
