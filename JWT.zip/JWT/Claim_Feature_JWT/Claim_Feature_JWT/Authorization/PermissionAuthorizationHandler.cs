﻿using Microsoft.AspNetCore.Authorization;

namespace Claim_Feature_JWT.Authorization
{
    public class PermissionAuthorizationHandler: AuthorizationHandler<PermissionRequirement>
    {
        protected override Task HandleRequirementAsync(
       AuthorizationHandlerContext context,
       PermissionRequirement requirement)
        {
            HashSet<string> permissions = context.User.GetPermissions();

            if (permissions.Contains(requirement.Permission))
            {
                context.Succeed(requirement);
            }

            return Task.CompletedTask;
        }
    }
}
