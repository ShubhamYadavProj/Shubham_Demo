﻿namespace Claim_Feature_JWT.Authorization
{
    public interface IPermission
    {
        Task<HashSet<string>> GetPermissionsAsync(string UserId);
    }
}
