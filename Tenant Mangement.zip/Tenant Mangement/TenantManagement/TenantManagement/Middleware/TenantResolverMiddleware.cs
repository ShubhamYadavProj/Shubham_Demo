﻿using TenantManagement.Service;

namespace TenantManagement.Middleware
{
    public class TenantResolverMiddleware
    {

        private readonly RequestDelegate _next;
        public TenantResolverMiddleware(RequestDelegate next)
        {
            _next = next;
        }
        public async Task InvokeAsync(HttpContext context, ITenantService currentTenantService)
        {
            context.Request.Headers.TryGetValue("X-Tenant-Id", out var tenantFromHeader); // Tenant Id from incoming request header

            if (!string.IsNullOrEmpty(tenantFromHeader))
            {
                Guid tenantId = Guid.Parse(tenantFromHeader);

                await currentTenantService.SetTenant(tenantId);
            }

            await _next(context);
        }

        //public static class TenantMiddleware
        //{
        //    public static IApplicationBuilder UseTenant(this IApplicationBuilder app)
        //    {
        //        return app.UseMiddleware<TenantResolverMiddleware>();
        //    }
        //}
    }
}
