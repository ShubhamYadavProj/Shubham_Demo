﻿using Microsoft.EntityFrameworkCore;
using TenantManagement.Models;
using TenantManagement.Service;

namespace TenantManagement.Context
{
    public class ApplicationDbContext:DbContext
    {
        private ITenantService _tenantService;
        public Guid? CurrentTenantId { get; set; }
        public string? CurrentTenantConnectionString { get; set; }


        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options, ITenantService tenantService) : base(options)
        {
            _tenantService = tenantService;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            CurrentTenantId = _tenantService.TenantId;

            CurrentTenantConnectionString = _tenantService.ConnectionString;

            if (!string.IsNullOrEmpty(CurrentTenantConnectionString))
            {
                optionsBuilder.UseSqlServer(CurrentTenantConnectionString);
            }
        }

        public DbSet<Brand> Brands { get; set; }

        public DbSet<Tenant> Tenants { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Brand>(x =>
            {
                x.HasKey(x => x.Id);
                x.HasQueryFilter(x => x.TenantId == CurrentTenantId);
            });
        }

        public override int SaveChanges()
        {
            foreach (var entry in ChangeTracker.Entries<MetaFieldswithTenant>().ToList())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                    case EntityState.Modified:
                        entry.Entity.TenantId = CurrentTenantId;
                        break;
                }
            }
            var result = base.SaveChanges();
            return result;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var entry in ChangeTracker.Entries<MetaFieldswithTenant>().ToList())
            {
                switch (entry.State)
                {
                    case EntityState.Added:
                    case EntityState.Modified:
                        entry.Entity.TenantId = CurrentTenantId;
                        break;
                }
            }
            return await base.SaveChangesAsync(cancellationToken);
        }
    }
}
