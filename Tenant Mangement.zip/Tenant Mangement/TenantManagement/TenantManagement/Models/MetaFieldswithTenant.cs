﻿namespace TenantManagement.Models
{
    public class MetaFieldswithTenant
    {
        public Guid? TenantId { get; set; }
    }
}
