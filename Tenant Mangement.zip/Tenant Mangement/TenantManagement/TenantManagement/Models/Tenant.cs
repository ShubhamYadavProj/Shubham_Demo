﻿using System.ComponentModel.DataAnnotations;

namespace TenantManagement.Models
{
    public class Tenant
    {
        [Key]
        public Guid Id { get; set; }
        public required bool Isolate { get; set; }
        public required string Name { get; set; }
        public string? ConnectionString { get; set; }
    }
}
