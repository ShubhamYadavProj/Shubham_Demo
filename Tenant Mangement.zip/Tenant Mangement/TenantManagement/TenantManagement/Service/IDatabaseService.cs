﻿namespace TenantManagement.Service
{
    public interface IDatabaseService
    {
        public Task<string> GetConnectionString(string dbName);

        public Task<string?> GetRootConnectionString();
    }
}
