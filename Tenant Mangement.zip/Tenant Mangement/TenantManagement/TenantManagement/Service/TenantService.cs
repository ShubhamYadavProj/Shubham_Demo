﻿
using TenantManagement.Context;
using TenantManagement.Models;

namespace TenantManagement.Service
{
    public class TenantService:ITenantService
    {


        public Guid? TenantId { get; set; }
        public string? ConnectionString { get; set; }   
        private TenantDbContext _context;

        public TenantService(TenantDbContext context)
        {
            _context = context;
        }

        public Task<bool> SetTenant(Guid tenantId)
        {
            Tenant? tenant = GetTenant(tenantId);

            if (tenant != null)
            {
                TenantId = tenant.Id;
                ConnectionString = tenant.ConnectionString;
                return Task.FromResult(true);
            }
            else
            {
                throw new Exception($"Tenant '{tenantId}' is not active or does not exist.");
            }
        }

        public Tenant? GetTenant(Guid tenantId)
        {
            return _context.Tenants.FirstOrDefault(x => x.Id == tenantId);
        }
    }
}
