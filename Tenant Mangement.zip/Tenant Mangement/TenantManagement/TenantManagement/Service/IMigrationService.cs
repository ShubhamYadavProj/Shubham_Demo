﻿namespace TenantManagement.Service
{
    public interface IMigrationService
    {
        public Task<bool> Migrate(string connectionString, string? rootConnectionString);
    }
}
