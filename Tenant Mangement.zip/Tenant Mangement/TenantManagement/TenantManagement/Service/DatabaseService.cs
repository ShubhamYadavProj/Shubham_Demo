﻿
using Microsoft.EntityFrameworkCore;
using TenantManagement.Context;

namespace TenantManagement.Service
{
    public class DatabaseService : IDatabaseService
    {
        private readonly ApplicationDbContext _context;

        public DatabaseService(ApplicationDbContext context)
        {
           _context = context;
        }
        public Task<string> GetConnectionString(string dbName)
        {
            //New DB required
            string connectionString = $"Server=.;Initial Catalog={dbName};TrustServerCertificate=True;Trusted_Connection=True;";
            return Task.FromResult(connectionString);
        }

        public Task<string?> GetRootConnectionString()
        {
            return Task.FromResult(_context.Database.GetConnectionString());
        }
    }
}
