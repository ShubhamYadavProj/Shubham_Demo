﻿namespace TenantManagement.Service
{
    public interface ITenantService
    {
        public Guid? TenantId { get; set; }
        public string? ConnectionString { get; set; }
        public Task<bool> SetTenant(Guid tenant);
    }
}
