﻿
using Microsoft.EntityFrameworkCore;
using TenantManagement.Context;

namespace TenantManagement.Service
{
    public class MigrationService : IMigrationService
    {
        private readonly ApplicationDbContext _context;

        public MigrationService(ApplicationDbContext context)
        {
            _context = context;
        }
        public async Task<bool> Migrate(string connectionString, string? rootConnectionString)
        {
            try
            {
                if (!string.IsNullOrEmpty(rootConnectionString))
                {
                    _context.Database.SetConnectionString(connectionString);

                    bool isDbCreated = await _context.Database.EnsureCreatedAsync();

                   // _context.Database.SetConnectionString(rootConnectionString);

                    return isDbCreated;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }
    }
}
