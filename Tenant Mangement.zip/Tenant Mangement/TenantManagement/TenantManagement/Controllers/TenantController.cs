﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using TenantManagement.Context;
using TenantManagement.Models;
using TenantManagement.Service;

namespace TenantManagement.Controllers
{

    [Route("api")]
    [ApiController]
    public class TenantController : ControllerBase
    {
        private readonly IDatabaseService _databaseService;
        private readonly IMigrationService _migrationService;   
        private readonly ApplicationDbContext _context;


        public TenantController(IDatabaseService databaseService,IMigrationService migrationService,ApplicationDbContext context)
        {
            _context = context;
            _databaseService = databaseService; 
            _migrationService = migrationService;   
        }


        [HttpPost("tenant")]
        public async Task<Tenant> AddTenant([FromBody] Tenant tenant)
        {
            if (tenant.Isolate)
            {
                string? rootConnectionString = await _databaseService.GetRootConnectionString();

                tenant.ConnectionString = await _databaseService.GetConnectionString(tenant.Name);

                await _migrationService.Migrate(tenant.ConnectionString, rootConnectionString);
            }

            EntityEntry<Tenant> addedTenant = await _context.Tenants.AddAsync(tenant);

            await _context.SaveChangesAsync();

            return addedTenant.Entity;
        }
    }
}
