﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TenantManagement.Context;
using TenantManagement.Models;

namespace TenantManagement.Controllers
{
   
    [ApiController]
    [Route("api")]
    public class BrandController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public BrandController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("brands")]
        public IEnumerable<Brand> GetBrands()
        {
            return _context.Brands;
        }

        [HttpPost("brand")]
        public async Task<Brand?> AddBrand([FromBody] Brand brand)
        {
            var addedBrand = await _context.AddAsync(brand);
            await _context.SaveChangesAsync();
            return addedBrand?.Entity;
        }

    }
}
